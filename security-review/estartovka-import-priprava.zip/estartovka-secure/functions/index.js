'use strict';
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {setGlobalOptions}=require('firebase-functions/v2');
const {initializeApp}=require('firebase-admin/app');
const {getDatabase}=require('firebase-admin/database');
const {randomInt}=require('node:crypto');
const validate=require('./security');
const imports=require('./imports');
const {runtimeOptions}=require('./emulator-config');
const {updateExisting}=require('./existing-transaction');
const app=initializeApp(runtimeOptions(process.env));
const db=getDatabase(app);
setGlobalOptions({region:'europe-west1'});

function callable(handler) {
  return onCall({cors:true},async request=>{
    if (!request.auth) throw new HttpsError('unauthenticated','Musíte být přihlášeni.');
    if (request.auth.token.email_verified !== true) throw new HttpsError('permission-denied','Ověřte svůj e-mail a obnovte přihlášení.');
    if (!request.data || typeof request.data !== 'object' || Array.isArray(request.data)) throw new HttpsError('invalid-argument','Neplatný požadavek.');
    try {return await handler(request);} catch(error) {
      if (error instanceof validate.ValidationError) throw new HttpsError('invalid-argument',error.message);
      throw error;
    }
  });
}
async function authorized(request,adminOnly=false) {
  const airport=validate.airportId(request.data.airportId);
  const user=(await db.ref(`users/${request.auth.uid}`).get()).val();
  if (!user || !(user.role==='superadmin' || (user.airportId===airport && (user.role==='admin' || (!adminOnly && user.role==='starter'))))) throw new HttpsError('permission-denied','Nemáte oprávnění pro toto letiště.');
  if (!(await db.ref(`airports/${airport}`).get()).exists()) throw new HttpsError('not-found','Letiště neexistuje.');
  return {airport,user,actor:user.fullName || request.auth.token.email || request.auth.uid};
}
function log(state,key,request,action,flightId=null) {
  state.auditLogs=state.auditLogs || {};
  state.auditLogs[key]={id:Date.now(),timestamp:new Date().toISOString(),user:request.auth.uid,type:action,details:action+(flightId ? ' – let '+flightId : ''),flightId};
}
// Registration writes a guest profile through protected RTDB rules.
// No Auth provisioning trigger or custom role claims are required here.
exports.createFlight=callable(async request=>{
  const {airport,actor}=await authorized(request);
  const flight={...validate.createFlight(request.data.flightData),id:randomInt(1,281474976710655),createdBy:actor,endedBy:null};
  const root=db.ref(`airportData/${airport}`);
  const key=root.child('activeFlights').push().key;
  const auditKey=root.child('auditLogs').push().key;
  await root.transaction(state=>{
    state=state || {};state.activeFlights=state.activeFlights || {};
    state.activeFlights[key]=flight;log(state,auditKey,request,'Odstartování',flight.id);return state;
  });
  return {success:true,id:flight.id};
});
exports.landFlight=callable(async request=>{
  const {airport,actor}=await authorized(request);
  const id=validate.flightId(request.data.flightId);
  const type=request.data.landingType;
  if (!['tow','glider'].includes(type)) throw new HttpsError('invalid-argument','Neplatný typ přistání.');
  const root=db.ref(`airportData/${airport}`),auditKey=root.child('auditLogs').push().key;
  const now=Date.now();
  const result=await updateExisting(root,state=>{
    if (!state) return;
    const entry=Object.entries(state.activeFlights || {}).find(([,f])=>f.id===id);
    if (!entry) return; // A completed flight is never resurrected by a stale request.
    const [key,old]=entry;
    if (old.imported) throw new HttpsError('failed-precondition','Přistání převzatého letu zaznamenává zdroj.');
    const flight=validate.land(old,type,now);
    const finished=imports.finished(flight);
    if (finished) {
      flight.endedBy=actor;state.completedFlights=state.completedFlights || {};
      state.completedFlights[key]=flight;delete state.activeFlights[key];
    } else state.activeFlights[key]=flight;
    log(state,auditKey,request,type==='tow'?'Přistání vlečné':'Přistání větroně',id);return state;
  });
  if (!result) throw new HttpsError('not-found','Let již není aktivní.');
  return {success:true};
});
exports.deleteFlight=callable(async request=>{
  const {airport}=await authorized(request,true),id=validate.flightId(request.data.flightId);
  const root=db.ref(`airportData/${airport}`),auditKey=root.child('auditLogs').push().key;
  const result=await updateExisting(root,state=>{
    if (!state) return;
    let found=false;
    for (const status of ['activeFlights','completedFlights']) {
      for (const [key,flight] of Object.entries(state[status] || {})) if (flight.id===id) {
        if (flight.imported) {state.importTombstones=state.importTombstones || {};state.importTombstones[key]={deletedAt:new Date().toISOString(),deletedBy:request.auth.uid};}
        delete state[status][key];found=true;
      }
    }
    if (!found) return;
    log(state,auditKey,request,'Smazání letu',id);return state;
  });
  if (!result) throw new HttpsError('not-found','Let neexistuje.');
  return {success:true};
});

exports.editFlight=callable(async request=>{
  const {airport,actor}=await authorized(request,true);
  const id=validate.flightId(request.data.flightId);
  const edits=validate.edits(request.data.edits);
  const root=db.ref(`airportData/${airport}`),auditKey=root.child('auditLogs').push().key;
  const result=await updateExisting(root,state=>{
    if (!state) return;
    const active=Object.entries(state.activeFlights || {}).find(([,f])=>f.id===id);
    const completed=Object.entries(state.completedFlights || {}).find(([,f])=>f.id===id);
    const entry=active || completed;
    if (!entry) return;
    const [key,old]=entry;
    if (old.imported) throw new HttpsError('failed-precondition','Časy převzatého letu spravuje zdroj. Použijte doplnění posádky a úlohy.');
    const flight=validate.editFlight(old,edits);
    const finished=imports.finished(flight);
    state.activeFlights=state.activeFlights || {};
    state.completedFlights=state.completedFlights || {};
    delete state.activeFlights[key]; delete state.completedFlights[key];
    if (finished) {flight.endedBy=actor;state.completedFlights[key]=flight;}
    else {flight.endedBy=null;state.activeFlights[key]=flight;}
    log(state,auditKey,request,'Úprava letu',id);return state;
  });
  if (!result) throw new HttpsError('not-found','Let neexistuje.');
  return {success:true};
});
exports.deleteAirport=callable(async request=>{
  const airport=validate.airportId(request.data.airportId);
  const profile=(await db.ref('users/'+request.auth.uid).get()).val();
  if (profile?.role!=='superadmin') throw new HttpsError('permission-denied','Vyžadována role superadmin.');
  // Check membership and removal atomically to avoid dangling user affiliations.
  const result=await updateExisting(db.ref(),state=>{
    if (!state?.airports?.[airport]) return;
    if (Object.values(state.users || {}).some(user=>user.airportId===airport)) {
      throw new HttpsError('failed-precondition','Nejprve přesuňte členy tohoto letiště.');
    }
    // Recheck privilege within the transaction, including concurrent role changes.
    if (state.users?.[request.auth.uid]?.role!=='superadmin') throw new HttpsError('permission-denied','Oprávnění se změnilo.');
    delete state.airports[airport];
    if (state.airportData) delete state.airportData[airport];
    return state;
  });
  if (!result) throw new HttpsError('not-found','Letiště neexistuje.');
  return {success:true};
});

// Source settings are private airport data and can only be changed through this
// authorized endpoint. API activation awaits a verified provider adapter.
exports.saveFlightSource=callable(async request=>{
  const {airport}=await authorized(request,true);
  const config=imports.source(request.data.url);
  const root=db.ref(`airportData/${airport}`),auditKey=root.child('auditLogs').push().key;
  await root.transaction(state=>{
    state=state || {};
    state.flightSource=config?{...config,status:'awaiting-api',updatedAt:new Date().toISOString(),updatedBy:request.auth.uid}:null;
    log(state,auditKey,request,config?'Nastavení zdroje letů':'Odpojení zdroje letů');
    return state;
  });
  return {success:true,status:config?'awaiting-api':'disabled'};
});
exports.completeFlightDetails=callable(async request=>{
  const {airport,actor}=await authorized(request);
  const id=validate.flightId(request.data.flightId),details=imports.details(request.data.details);
  const root=db.ref(`airportData/${airport}`),auditKey=root.child('auditLogs').push().key;
  const now=new Date().toISOString();
  const result=await updateExisting(root,state=>{
    if (!state) return;
    for (const status of ['activeFlights','completedFlights']) {
      const entry=Object.entries(state[status] || {}).find(([,f])=>f.id===id);
      if (!entry) continue;
      const [key,flight]=entry;
      if (!flight.imported) throw new HttpsError('failed-precondition','Tento formulář je určen převzatým letům.');
      state[status][key]={...flight,...details,detailsComplete:true,detailsCompletedBy:actor,detailsCompletedAt:now};
      log(state,auditKey,request,'Doplnění posádky a úlohy',id);
      return state;
    }
  });
  if (!result) throw new HttpsError('not-found','Let neexistuje.');
  return {success:true};
});
