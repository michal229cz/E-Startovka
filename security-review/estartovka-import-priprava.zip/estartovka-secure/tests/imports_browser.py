import asyncio,functools,threading
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
async def main():
 server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'public')))
 threading.Thread(target=server.serve_forever,daemon=True).start()
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium');page=await browser.new_page();errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.route('**/app.js',lambda route:route.fulfill(path=str(ROOT/'tests/app-mock.js'),content_type='text/javascript'))
  await page.goto(f'http://127.0.0.1:{server.server_port}');await page.wait_for_function('window.__mock')
  await page.evaluate('''() => {
   const m=window.__mock,s=m.fixture.airportData.lkst;
   s.flightSource={provider:'ibisek',location:'LKST',url:'https://logbook.ibisek.com/loc/LKST',status:'awaiting-api'};
   s.activeFlights.imported={id:201,aircraft:'OK-IMPORT',pilot:'-',task:'-',launchType:'Neurčeno',takeoffTime:new Date().toISOString(),imported:{provider:'ibisek',externalId:'1'},detailsComplete:false};
   s.completedFlights.imported={id:202,aircraft:'OK-OLD',pilot:'-',task:'-',launchType:'Neurčeno',takeoffTime:'2025-01-01T10:00:00.000Z',gliderLandingTime:'2025-01-01T11:00:00.000Z',imported:{provider:'ibisek',externalId:'2'},detailsComplete:false};
   m.login('starter');
  }''')
  async def choose():
   await page.wait_for_function('document.querySelectorAll("#airports-grid button:enabled").length>0')
   await page.locator('#airports-grid button:enabled').first.click()
   await page.wait_for_function('!document.getElementById("app-shell").hidden')
  await choose();await page.wait_for_function('document.getElementById("flight-details-queue").textContent.includes("OK-OLD")')
  assert 'K doplnění: 2' in await page.locator('#flight-details-queue').inner_text()
  # Imported flight has no manual landing button; manual flight still has one.
  assert await page.locator('[data-action-click="landGliderFlight"][data-arg-0="201"]').count()==0
  assert await page.locator('[data-action-click="landGliderFlight"][data-arg-0="101"]').count()==1
  await page.locator('#active-flights-list [data-action-click="openFlightDetails"]').click()
  await page.locator('#details-pilot').fill('Pilot <img src=x onerror=alert(1)>')
  await page.locator('#details-task').fill('Úloha 3')
  assert await page.locator('#details-launch').input_value()==''
  await page.locator('#flight-details-form button[type="submit"]').click()
  assert await page.evaluate('window.__mock.calls.filter(c=>c.name==="completeFlightDetails").length')==0
  await page.locator('#details-launch').select_option('Aerovlek')
  assert await page.locator('#details-tow-fields').is_visible()
  await page.locator('#details-tow-aircraft').fill('OK-T')
  await page.locator('#details-tow-pilot').fill('Tow pilot')
  await page.locator('#flight-details-form button[type="submit"]').click()
  await page.wait_for_function('document.getElementById("flight-details-modal").classList.contains("hidden")')
  call=await page.evaluate('window.__mock.calls.find(c=>c.name==="completeFlightDetails")')
  assert call['data']['airportId']=='lkst' and call['data']['flightId']==201
  assert call['data']['details']['task']=='Úloha 3' and 'takeoffTime' not in call['data']['details']
  print('PASS imported active/old completed queue, required fields, tow metadata and callable payload')
  await page.evaluate('''() => {const s=window.__mock.fixture.airportData.lkst;Object.assign(s.activeFlights.imported,{detailsComplete:true,pilot:'<script>bad()</script>',task:'Úloha 3'});window.__mock.emit('airportData/lkst/activeFlights');}''')
  await page.wait_for_function('document.getElementById("flight-details-queue").textContent.includes("K doplnění: 1")')
  assert await page.locator('#active-flights-list script').count()==0
  assert 'Doplněno' in await page.locator('#active-flights-list').inner_text()
  await page.evaluate('window.__mock.logout();window.__mock.login("admin")');await choose()
  await page.locator('#open-fleet-modal-btn').click()
  assert await page.locator('#flight-source-url').input_value()=='https://logbook.ibisek.com/loc/LKST'
  assert 'čeká na ověření API' in await page.locator('#flight-source-status').inner_text()
  await page.locator('#flight-source-url').fill('https://logbook.ibisek.com/loc/LKBR')
  await page.locator('#flight-source-form button[type="submit"]').click()
  await page.wait_for_function('window.__mock.calls.some(c=>c.name==="saveFlightSource")')
  source=await page.evaluate('window.__mock.calls.find(c=>c.name==="saveFlightSource").data')
  assert source=={'airportId':'lkst','url':'https://logbook.ibisek.com/loc/LKBR'}
  print('PASS source settings show pending API status and call scoped backend')
  await page.locator('[data-action-click="closeFleetModal"]').first.click()
  await page.evaluate('window.openFlightDetails(201)')
  await page.evaluate('window.__mock.logout()')
  assert await page.locator('#flight-details-modal').is_hidden()
  assert await page.locator('#flight-details-queue').is_hidden()
  assert await page.locator('#details-pilot').input_value()==''
  assert await page.locator('#flight-source-url').input_value()==''
  assert not errors,errors
  print('PASS logout removes import source, queue, modal and entered crew; no JavaScript errors')
  await browser.close()
 server.shutdown()
asyncio.run(main())
