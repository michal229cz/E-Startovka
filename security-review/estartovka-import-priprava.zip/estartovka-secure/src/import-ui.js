import {html} from 'lit-html';

export function installImportUI({getAirport,getFlights,canWrite,isAdmin,getSource,saveSource,saveDetails,setContent,formatTime}) {
    const el=id=>document.getElementById(id);
    const sourceForm=el('flight-source-form'),detailsForm=el('flight-details-form');
    const modal=el('flight-details-modal');
    let editingAirport=null,sourceDirty=false,sourceBusy=false,detailsBusy=false,generation=0;
    const clean=value=>value && value!=='-' ? value : '';
    const find=id=>getFlights().find(f=>f.id===id);
    function badge(f) {
        if (!f.imported) return '';
        return html`<span class="inline-block text-xs font-bold px-2 py-1 rounded-lg ${f.detailsComplete ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'}">${f.detailsComplete ? 'Doplněno' : 'K doplnění'}</span>
            ${canWrite() ? html`<button type="button" data-action-click="openFlightDetails" data-arg-0="${f.id}" data-arg-0-type="number" class="text-xs font-bold text-blue-700 underline p-1">${f.detailsComplete ? 'Upravit údaje' : 'Doplnit let'}</button>` : ''}`;
    }
    function renderQueue() {
        const pending=getFlights().filter(f=>f.imported && !f.detailsComplete).sort((a,b)=>b.takeoffTime.localeCompare(a.takeoffTime));
        const panel=el('flight-details-queue');panel.hidden=!pending.length;
        setContent(panel, pending.length ? html`<details><summary class="cursor-pointer font-bold text-sm text-amber-900">K doplnění: ${pending.length} letů</summary>
          <p class="text-xs text-slate-500 my-2">Všechny převzaté lety bez pilota a úlohy, včetně starších dní.</p>
          <div class="space-y-2 max-h-64 overflow-y-auto">${pending.map(f=>html`<div class="flex flex-wrap items-center gap-2 border-t border-slate-100 pt-2 text-sm"><strong>${f.aircraft}</strong><span>${f.takeoffTime.slice(0,10)} ${formatTime(f.takeoffTime)} UTC</span>${badge(f)}</div>`)}</div>
        </details>` : '');
    }
    function renderSource(reset=false) {
        const source=getSource();
        if (reset || !sourceDirty) {el('flight-source-url').value=source?.url || '';sourceDirty=false;}
        // This release stores a source but cannot yet fetch an undocumented API.
        el('flight-source-status').textContent=source ? 'Zdroj uložen. Automatické načítání čeká na ověření API Ibisek.' : 'Zdroj není nastaven. Lety zatím zadávejte ručně.';
    }
    sourceForm.addEventListener('input',()=>{sourceDirty=true;});
    sourceForm.addEventListener('submit',async event=>{
        event.preventDefault();if (!isAdmin() || sourceBusy) return;
        const airportId=getAirport(),epoch=generation;
        const submit=sourceForm.querySelector('button[type="submit"]');
        sourceBusy=true;submit.disabled=true;
        try {
            await saveSource({airportId,url:el('flight-source-url').value.trim()});
            if (epoch!==generation || getAirport()!==airportId) return;
            sourceDirty=false;
            el('flight-source-status').textContent=el('flight-source-url').value.trim() ? 'Zdroj uložen. Automatické načítání čeká na ověření API Ibisek.' : 'Zdroj odpojen.';
        } catch(error) {if(epoch===generation)el('flight-source-status').textContent='Zdroj se nepodařilo uložit: '+error.message;}
        finally {if(epoch===generation){sourceBusy=false;submit.disabled=false;}}
    });
    function toggleTow() {
        const aero=el('details-launch').value==='Aerovlek';
        el('details-tow-fields').hidden=!aero;
        el('details-tow-aircraft').required=aero;el('details-tow-pilot').required=aero;
    }
    el('details-launch').addEventListener('change',toggleTow);
    window.openFlightDetails=function(id) {
        if (!canWrite()) return;
        const f=find(id);if(!f?.imported) return;
        editingAirport=getAirport();detailsForm.reset();
        el('details-flight-id').value=f.id;
        el('details-flight-label').textContent=`${f.aircraft} · ${f.takeoffTime.slice(0,10)} · ${formatTime(f.takeoffTime)} UTC`;
        for (const [name,field] of Object.entries({pilot:'pilot',copilot:'copilot',task:'task',launch:'launchType','tow-aircraft':'towAircraft','tow-pilot':'towPilot'})) el('details-'+name).value=clean(f[field]);
        toggleTow();el('details-error').textContent='';modal.classList.remove('hidden');el('details-pilot').focus();
    };
    window.closeFlightDetails=function() {modal.classList.add('hidden');detailsForm.reset();editingAirport=null;};
    detailsForm.addEventListener('submit',async event=>{
        event.preventDefault();if(!canWrite() || editingAirport!==getAirport() || detailsBusy) return;
        const flightId=Number(el('details-flight-id').value),f=find(flightId);if(!f?.imported) return;
        const airportId=editingAirport,epoch=generation,submit=detailsForm.querySelector('button[type="submit"]');
        detailsBusy=true;submit.disabled=true;
        try {
            await saveDetails({airportId,flightId,details:{pilot:el('details-pilot').value.trim(),copilot:el('details-copilot').value.trim(),task:el('details-task').value.trim(),launchType:el('details-launch').value,towAircraft:el('details-tow-aircraft').value.trim(),towPilot:el('details-tow-pilot').value.trim()}});
            if(epoch===generation && editingAirport===airportId && Number(el('details-flight-id').value)===flightId)window.closeFlightDetails();
        } catch(error) {if(epoch===generation)el('details-error').textContent='Údaje se nepodařilo uložit: '+error.message;}
        finally {if(epoch===generation){detailsBusy=false;submit.disabled=false;}}
    });
    function clear() {
        generation++;sourceDirty=false;sourceBusy=false;detailsBusy=false;
        window.closeFlightDetails();sourceForm.reset();
        el('flight-source-status').textContent='';el('details-flight-label').textContent='';el('details-error').textContent='';
        sourceForm.querySelector('button[type="submit"]').disabled=false;detailsForm.querySelector('button[type="submit"]').disabled=false;
        el('flight-details-queue').hidden=true;setContent(el('flight-details-queue'),'');
    }
    return {badge,renderQueue,renderSource,clear};
}
