'use strict';
// Pure validation shared by callable functions; no trust in client-side checks.
class ValidationError extends Error {}
function airportId(value) {
  if (typeof value !== 'string' || !/^[a-z0-9_-]{1,64}$/i.test(value)) throw new ValidationError('Neplatné ID letiště.');
  return value;
}
function text(value, required=false) {
  if (value == null && !required) return '-';
  if (typeof value !== 'string' || value.trim().length > 120 || (required && !value.trim()) || /[\u0000-\u001f]/.test(value)) throw new ValidationError('Neplatný text.');
  return value.trim() || '-';
}
function createFlight(data, now=Date.now()) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new ValidationError('Neplatný let.');
  if (!['Aerovlek', 'Naviják', 'Vlastní motor'].includes(data.launchType)) throw new ValidationError('Neplatný typ startu.');
  const aero = data.launchType === 'Aerovlek';
  // Explicit field selection: never accept role, identity, landing state, or ID from the client.
  return {aircraft:text(data.aircraft,true),pilot:text(data.pilot,true),copilot:text(data.copilot),task:text(data.task),launchType:data.launchType,takeoffTime:new Date(now).toISOString(),towAircraft:aero?text(data.towAircraft,true):null,towPilot:aero?text(data.towPilot,true):null,towLandingTime:null,towDuration:'-',gliderLandingTime:null,gliderDuration:'-'};
}
function flightId(value) {
  if (!Number.isSafeInteger(value) || value <= 0) throw new ValidationError('Neplatné ID letu.');
  return value;
}
function land(flight,type,now=Date.now()) {
  if (!['tow','glider'].includes(type) || (type==='tow' && flight.launchType!=='Aerovlek')) throw new ValidationError('Neplatný typ přistání.');
  const field=type==='tow'?'towLandingTime':'gliderLandingTime';
  if (flight[field]) return {...flight}; // Idempotent retry, never overwrite a recorded landing.
  const start=Date.parse(flight.takeoffTime);
  if (!Number.isFinite(start) || start>now) throw new ValidationError('Neplatný čas vzletu.');
  const minutes=Math.round((now-start)/60000);
  return {...flight,[field]:new Date(now).toISOString(),[type==='tow'?'towDuration':'gliderDuration']:String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0')};
}
module.exports={ValidationError,airportId,createFlight,flightId,land,text};

function timestamp(value) {
  if (typeof value!=='string') throw new ValidationError('Neplatný čas.');
  const ms=Date.parse(value);
  if (!Number.isFinite(ms) || ms<0 || ms>Date.now()+5000 || new Date(ms).toISOString()!==value) throw new ValidationError('Neplatný čas.');
  return value;
}
function edits(value) {
  if (!value || typeof value!=='object' || Array.isArray(value) || Object.keys(value).some(key=>!['task','takeoffTime','towLandingTime','gliderLandingTime'].includes(key))) throw new ValidationError('Neplatná úprava letu.');
  return {task:text(value.task),takeoffTime:timestamp(value.takeoffTime),towLandingTime:value.towLandingTime==null?null:timestamp(value.towLandingTime),gliderLandingTime:value.gliderLandingTime==null?null:timestamp(value.gliderLandingTime)};
}
function editFlight(old,value) {
  const flight={...old,...value};
  if (flight.launchType!=='Aerovlek' && flight.towLandingTime) throw new ValidationError('Let nemá vlečnou.');
  for (const [type,field] of [['tow','towLandingTime'],['glider','gliderLandingTime']]) {
    const duration=type==='tow'?'towDuration':'gliderDuration';
    flight[duration]='-';
    if (flight[field]) {
      const end=Date.parse(flight[field]);
      if (end<Date.parse(flight.takeoffTime)) throw new ValidationError('Přistání nesmí předcházet vzletu.');
      const copy={...flight,[field]:null};
      flight[duration]=land(copy,type,end)[duration];
    }
  }
  return flight;
}
module.exports.edits=edits;module.exports.editFlight=editFlight;
