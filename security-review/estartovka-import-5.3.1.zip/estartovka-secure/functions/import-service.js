'use strict';
const {randomUUID}=require('node:crypto');
const {HttpsError}=require('firebase-functions/v2/https');
const {updateExisting}=require('./existing-transaction');
const ibisek=require('./ibisek');
const imports=require('./imports');
async function runImport({db,airport,html,date,scheduled=false,fetchHTML=ibisek.fetchHTML,now=Date.now(),recheck=async()=>{}}) {
  const root=db.ref(`airportData/${airport}`),sourceRef=root.child('flightSource');
  const config=(await sourceRef.get()).val();
  if(!config?.url || !config.revision)throw new HttpsError('failed-precondition','Nejprve uložte zdroj letů ve správě letiště.');
  const canonical=imports.source(config.url);
  if(!canonical || canonical.location!==config.location || config.provider!=='ibisek')throw new HttpsError('failed-precondition','Neplatná konfigurace zdroje.');
  if(scheduled && config.enabled!==true)return {skipped:true};
  const fromFile=html!==undefined;
  if(!fromFile && config.nextAttemptAfter>now)return {skipped:true,reason:'cooldown'};
  const token=randomUUID();
  const claimed=await updateExisting(sourceRef,current=>{
    if(!current || current.revision!==config.revision || (scheduled && current.enabled!==true) || current.lease?.until>now || (!fromFile && current.nextAttemptAfter>now))return;
    return {...current,lease:{token,until:now+240000},lastAttemptAt:new Date(now).toISOString(),...(!fromFile?{nextAttemptAfter:now+300000}:{})};
  });
  if(!claimed)throw new HttpsError('aborted','Import právě probíhá nebo se změnilo nastavení.');
  try {
    let batches;
    if(fromFile) {
      batches=[ibisek.parseHTML(html,{location:canonical.location,date,now})];
    } else {
      const today=ibisek.day(new Date(now).toISOString().slice(0,10));
      batches=[];
      for(const d of [today.subtract({days:1}),today]) {
        const date=d.toString();
        batches.push(ibisek.parseHTML(await fetchHTML(canonical.location,date),{location:canonical.location,date,now,requireUTC:true}));
      }
    }
    await recheck();
    const auditKey=root.child('auditLogs').push().key;
    const count=batches.reduce((sum,b)=>sum+b.records.length,0);
    const committed=await updateExisting(root,state=>{
      if(!state || state.flightSource?.revision!==config.revision || state.flightSource?.lease?.token!==token) return;
      state=ibisek.applyBatch(state,canonical,batches,now);
      const s=state.flightSource;
      delete s.lease;delete s.lastError;
      s.status='ready';s.lastSuccessAt=new Date(now).toISOString();s.lastImportCount=count;s.lastImportMode=fromFile?'file':'online';
      state.auditLogs=state.auditLogs || {};
      state.auditLogs[auditKey]={id:now,timestamp:new Date(now).toISOString(),user:'import',type:'Import letů',details:`${canonical.location}: ${count} záznamů (${fromFile?'HTML soubor':'online'})`,flightId:null};
      return state;
    });
    if(!committed)throw new HttpsError('aborted','Nastavení zdroje se změnilo. Import nebyl uložen.');
    return {success:true,count};
  } catch(error) {
    await updateExisting(sourceRef,current=>{
      if(current?.revision!==config.revision || current?.lease?.token!==token)return;
      delete current.lease;current.status='error';current.lastError=String(error.message || 'Import se nezdařil.').slice(0,250);return current;
    });
    if(error instanceof HttpsError || error instanceof require('./security').ValidationError)throw error;
    throw new HttpsError('unavailable','Zdroj se nepodařilo načíst. Zkontrolujte stav importu ve správě letiště.');
  }
}
module.exports={runImport};
