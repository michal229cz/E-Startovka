'use strict';
// Source adapters must produce this internal record format. This is NOT the
// undocumented Ibisek API format. No external URL is fetched by this module.
const {createHash}=require('node:crypto');
const v=require('./security');
function source(value) {
  if (value==='') return null;
  if (typeof value!=='string' || value.length>2048) throw new v.ValidationError('Neplatná adresa zdroje.');
  let url;try {url=new URL(value);} catch {throw new v.ValidationError('Zadejte HTTPS adresu logbooku.');}
  if (url.protocol!=='https:' || url.hostname!=='logbook.ibisek.com' || url.port || url.username || url.password || url.search || url.hash || !/^\/(?:csv\/)?loc\/[A-Z0-9]{4}(?:\/\d{4}-\d{2}-\d{2})?\/?$/.test(url.pathname)) throw new v.ValidationError('Podporovaná adresa má tvar https://logbook.ibisek.com/loc/LKST.');
  const location=url.pathname.match(/\/loc\/([A-Z0-9]{4})/)[1];
  return {provider:'ibisek',location,url:'https://logbook.ibisek.com/loc/'+location};
}
function instant(value,now) {
  if (typeof value!=='string') throw new v.ValidationError('Zdroj neobsahuje úplné datum a čas.');
  const ms=Date.parse(value);
  if (!Number.isFinite(ms) || ms<0 || ms>now+5000 || new Date(ms).toISOString()!==value) throw new v.ValidationError('Neplatný čas zdroje.');
  return value;
}
function normalize(records,now=Date.now()) {
  if (!Array.isArray(records) || records.length>5000) throw new v.ValidationError('Neplatná nebo příliš velká dávka letů.');
  const ids=new Set();
  return records.map(r=>{
    if (!r || typeof r!=='object' || Array.isArray(r) || typeof r.externalId!=='string' || !r.externalId.trim() || r.externalId.length>200 || /[\u0000-\u001f]/.test(r.externalId) || ids.has(r.externalId)) throw new v.ValidationError('Chybějící nebo duplicitní ID zdrojového letu.');
    ids.add(r.externalId);
    const takeoffTime=instant(r.takeoffTime,now);
    const gliderLandingTime=r.landingTime==null?null:instant(r.landingTime,now);
    if (gliderLandingTime && gliderLandingTime<takeoffTime) throw new v.ValidationError('Přistání předchází vzletu.');
    return {externalId:r.externalId,aircraft:v.text(r.aircraft,true),takeoffTime,gliderLandingTime};
  });
}
function keyFor(config,externalId) {
  return 'import_'+createHash('sha256').update(JSON.stringify([config.provider,config.location,externalId])).digest('hex');
}
function finished(f) {return Boolean(f.gliderLandingTime && (f.imported || f.launchType!=='Aerovlek' || f.towLandingTime));}
function reconcile(state,config,records,now=Date.now()) {
  // Validate the complete response BEFORE changing any record. An absent record
  // is never interpreted as a landing or deletion (feeds can be paginated).
  const batch=normalize(records,now);
  state=state || {};state.activeFlights=state.activeFlights || {};state.completedFlights=state.completedFlights || {};
  for (const r of batch) {
    const key=keyFor(config,r.externalId);
    if (state.importTombstones?.[key]) continue;
    const old=state.activeFlights[key] || state.completedFlights[key];
    const id=old?.id || parseInt(key.slice(7,19),16) || 1;
    if (!old && [...Object.entries(state.activeFlights),...Object.entries(state.completedFlights)].some(([k,f])=>k!==key && f.id===id)) throw new v.ValidationError('Kolize ID letu.');
    if (!old && [...Object.values(state.activeFlights),...Object.values(state.completedFlights)].some(f=>!f.imported && String(f.aircraft).replace(/\s*\(.*\)/,'').trim()===r.aircraft && Math.abs(Date.parse(f.takeoffTime)-Date.parse(r.takeoffTime))<60000)) throw new v.ValidationError('Pro tento čas už existuje ručně zadaný let. Je potřeba kontrola před importem.');
    // Only mechanical fields belong to the source. Never replace entered crew,
    // task, launch method, or the completion stamp during a source correction.
    let flight={id,pilot:'-',copilot:'-',task:'-',launchType:'Neurčeno',towAircraft:null,towPilot:'-',towLandingTime:null,towDuration:'-',createdBy:'Automatický import',endedBy:null,detailsComplete:false,...old,...r};
    delete flight.externalId;
    flight.imported={provider:config.provider,location:config.location,externalId:r.externalId};
    flight.sourceUpdatedAt=new Date(now).toISOString();
    flight.gliderDuration='-';
    if (r.gliderLandingTime) flight.gliderDuration=v.land({...flight,gliderLandingTime:null},'glider',Date.parse(r.gliderLandingTime)).gliderDuration;
    delete state.activeFlights[key];delete state.completedFlights[key];
    if (finished(flight)) {flight.endedBy=old?.endedBy || 'Automatický import';state.completedFlights[key]=flight;}
    else {flight.endedBy=null;state.activeFlights[key]=flight;}
  }
  return state;
}
function details(data) {
  const fields=['pilot','copilot','task','launchType','towAircraft','towPilot'];
  if (!data || typeof data!=='object' || Array.isArray(data) || Object.keys(data).some(k=>!fields.includes(k))) throw new v.ValidationError('Neplatné údaje letu.');
  const required=value=>{const t=v.text(value,true);if(t==='-')throw new v.ValidationError('Vyplňte pilota, úlohu a způsob startu.');return t;};
  if (!['Aerovlek','Naviják','Vlastní motor'].includes(data.launchType)) throw new v.ValidationError('Vyberte způsob startu.');
  return {pilot:required(data.pilot),copilot:v.text(data.copilot),task:required(data.task),launchType:data.launchType,towAircraft:data.launchType==='Aerovlek'?required(data.towAircraft):null,towPilot:data.launchType==='Aerovlek'?required(data.towPilot):'-'};
}
module.exports={source,normalize,keyFor,reconcile,details,finished};
