"""Actual Auth/Functions/RTDB emulator import regression. Run after seed:emulator."""
from pathlib import Path
from integration_emulator import sign_in,denied,success,state,request,BASE,PROJECT

def main():
 request(BASE+':9000/airportData/lkst.json?ns='+PROJECT+'-default-rtdb',token='owner',method='DELETE')
 admin,starter,guest,other=[sign_in(r) for r in ['admin','starter','guest','other']]
 html=(Path(__file__).parent/'fixtures/ibisek-lkst-2026-10-17.html').read_text()
 config={'airportId':'lkst','url':'https://logbook.ibisek.com/loc/LKST/2026-10-17','enabled':False}
 for token in [starter,guest,other]:denied('saveFlightSource',config,token)
 success('saveFlightSource',config,admin)
 payload={'airportId':'lkst','date':'2026-10-17','html':html}
 for token in [starter,guest,other]:denied('importFlightHTML',payload,token)
 result=success('importFlightHTML',payload,admin)
 assert result['count']==9,result
 flights=state('airportData/lkst/completedFlights');f=min(flights.values(),key=lambda f:f['takeoffTime'])
 assert f['takeoffTime']=='2026-10-17T08:53:00.000Z',f
 assert not f['detailsComplete']
 success('completeFlightDetails',{'airportId':'lkst','flightId':f['id'],'details':{'pilot':'Actual import pilot','task':'Úloha 3','launchType':'Naviják'}},starter)
 success('importFlightHTML',payload,admin)
 flights=state('airportData/lkst/completedFlights');assert len(flights)==9
 assert next(x for x in flights.values() if x['id']==f['id'])['pilot']=='Actual import pilot'
 print('PASS real emulator upload: 9 flights; correct UTC conversion; starter completes details; reimport preserves crew and count')
 success('deleteFlight',{'airportId':'lkst','flightId':f['id']},admin)
 success('importFlightHTML',payload,admin)
 assert len(state('airportData/lkst/completedFlights'))==8
 assert state('airportData/lkst/flightSource')['lastImportMode']=='file'
 print('PASS real emulator deletion tombstone prevents imported flight returning')
if __name__=='__main__':main()
