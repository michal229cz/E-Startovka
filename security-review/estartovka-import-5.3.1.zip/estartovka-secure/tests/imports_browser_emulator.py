"""Real browser/SDK against local emulators only. Run after seed:emulator."""
import asyncio
from pathlib import Path
from urllib.parse import urlparse
from playwright.async_api import async_playwright
from integration_emulator import request,BASE,PROJECT
ROOT=Path(__file__).resolve().parents[1]
async def main():
 request(BASE+':9000/airportData/other.json?ns='+PROJECT+'-default-rtdb',token='owner',method='DELETE')
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium');page=await browser.new_page();errors=[];external=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  async def local(route):
   if urlparse(route.request.url).hostname!='127.0.0.1':external.append(route.request.url);await route.abort()
   else:await route.continue_()
  await page.route('**/*',local)
  await page.goto('http://127.0.0.1:5000');await page.locator('#auth-email').fill('demo-superadmin@example.test');await page.locator('#auth-password').fill('DemoOnly-2026!');await page.locator('#auth-form button[type="submit"]').click()
  await page.locator('#airports-grid button').filter(has_text='OTHER').click()
  await page.locator('#open-fleet-modal-btn').click()
  await page.locator('#flight-source-url').fill('https://logbook.ibisek.com/loc/LKST/2026-10-17')
  await page.locator('#flight-source-form button[type="submit"]').click()
  await page.wait_for_function('() => document.getElementById("flight-source-url").value==="https://logbook.ibisek.com/loc/LKST"')
  await page.locator('#flight-import-date').fill('2026-10-17')
  await page.locator('#flight-import-file').set_input_files(str(ROOT/'tests/fixtures/ibisek-lkst-2026-10-17.html'))
  await page.locator('#flight-source-upload').click()
  await page.wait_for_function('() => document.getElementById("flight-source-status").textContent.includes("9")')
  await page.locator('[data-action-click="closeFleetModal"]').first.click()
  await page.wait_for_function('() => document.getElementById("flight-details-queue").textContent.includes("K doplnění: 9")')
  await page.locator('#flight-details-queue summary').click()
  await page.locator('#flight-details-queue [data-action-click="openFlightDetails"]').first.click()
  await page.locator('#details-pilot').fill('Pilot z browser testu')
  await page.locator('#details-task').fill('Úloha 3')
  await page.locator('#details-launch').select_option('Naviják')
  await page.locator('#flight-details-form button[type="submit"]').click()
  await page.wait_for_function('() => document.getElementById("flight-details-modal").classList.contains("hidden")')
  await page.wait_for_function('() => document.getElementById("flight-details-queue").textContent.includes("K doplnění: 8")')
  await page.locator('#tab-history-btn').click()
  await page.wait_for_function('() => document.getElementById("history-days-container").textContent.includes("Pilot z browser testu")')
  assert not errors,errors;assert not external,external
  print('PASS real browser: source saved; file/date selection uploads nine flights; queue counts down after crew completion; history shows pilot')
  await page.locator('#open-fleet-modal-btn').click();await page.locator('#flight-source-upload').click()
  await page.wait_for_function('() => document.getElementById("flight-source-status").textContent.includes("Import dokončen")')
  await page.locator('[data-action-click="closeFleetModal"]').first.click()
  assert 'K doplnění: 8' in await page.locator('#flight-details-queue').inner_text()
  assert 'Pilot z browser testu' in await page.locator('#history-days-container').inner_text()
  print('PASS real browser reimport preserves entered crew and does not duplicate flights')
  await browser.close()
asyncio.run(main())
