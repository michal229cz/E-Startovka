const {test}=require('node:test');const assert=require('node:assert/strict');
const imports=require('../functions/imports');
const config=imports.source('https://logbook.ibisek.com/loc/LKST');
const now=Date.now();const start=new Date(now-3600000).toISOString(),end=new Date(now-60000).toISOString();
const record={externalId:'source-1',aircraft:'OK-1',takeoffTime:start,landingTime:null};
test('source URLs are canonical allowlisted locations without credentials or arbitrary API paths',()=>{
 assert.deepEqual(config,{provider:'ibisek',location:'LKST',url:'https://logbook.ibisek.com/loc/LKST'});
 assert.equal(imports.source(''),null);
 for(const u of ['https://127.0.0.1/loc/LKST','http://logbook.ibisek.com/loc/LKST','https://logbook.ibisek.com.evil.test/loc/LKST','https://u:p@logbook.ibisek.com/loc/LKST','https://logbook.ibisek.com/loc/LKST?token=secret','https://logbook.ibisek.com/api','https://logbook.ibisek.com/loc/LKST#token',null])assert.throws(()=>imports.source(u));
});
test('source batch requires stable IDs, explicit ISO dates and consistent chronology',()=>{
 for(const batch of [{},[record,record],[{...record,externalId:''}],[{...record,takeoffTime:'12:00'}],[{...record,landingTime:new Date(now-7200000).toISOString()}],[{...record,takeoffTime:new Date(now+60000).toISOString()}]])assert.throws(()=>imports.normalize(batch,now));
});
test('retry produces one active record, with required human metadata still missing',()=>{
 let s=imports.reconcile(null,config,[record],now);s=imports.reconcile(s,config,[record],now);
 const flights=Object.values(s.activeFlights);assert.equal(flights.length,1);assert.equal(Object.keys(s.completedFlights).length,0);
 assert.equal(flights[0].pilot,'-');assert.equal(flights[0].detailsComplete,false);assert.equal(flights[0].task,'-');assert.ok(Number.isSafeInteger(flights[0].id));
});
test('source landing and corrections preserve manually completed metadata',()=>{
 let s=imports.reconcile(null,config,[record],now);const key=imports.keyFor(config,record.externalId),id=s.activeFlights[key].id;
 Object.assign(s.activeFlights[key],{pilot:'Pilot',copilot:'Instructor',task:'Úloha 3',launchType:'Aerovlek',towAircraft:'OK-T',towPilot:'Vlekař',detailsComplete:true,detailsCompletedBy:'Starter',detailsCompletedAt:start});
 s=imports.reconcile(s,config,[{...record,landingTime:end,pilot:'Overwrite',task:'Overwrite',detailsComplete:false}],now);
 assert.equal(Object.keys(s.activeFlights).length,0);const f=s.completedFlights[key];
 assert.equal(f.id,id);assert.equal(f.pilot,'Pilot');assert.equal(f.task,'Úloha 3');assert.equal(f.copilot,'Instructor');assert.equal(f.detailsComplete,true);assert.equal(f.gliderDuration,'00:59');assert.equal(f.towAircraft,'OK-T');
 s=imports.reconcile(s,config,[{...record,takeoffTime:new Date(now-7200000).toISOString(),landingTime:end}],now);
 assert.equal(s.completedFlights[key].gliderDuration,'01:59');assert.equal(s.completedFlights[key].detailsCompletedBy,'Starter');
});
test('landing is recorded before details have been entered and later source reopen preserves details',()=>{
 let s=imports.reconcile(null,config,[{...record,landingTime:end}],now),key=imports.keyFor(config,record.externalId);
 assert.equal(s.completedFlights[key].detailsComplete,false);
 s.completedFlights[key].pilot='Pilot';s=imports.reconcile(s,config,[record],now);
 assert.equal(s.activeFlights[key].pilot,'Pilot');assert.equal(s.activeFlights[key].endedBy,null);assert.equal(Object.keys(s.completedFlights).length,0);
});
test('empty/partial source responses do not delete flights or infer a landing',()=>{
 let s=imports.reconcile(null,config,[record],now);s=imports.reconcile(s,config,[],now);
 assert.equal(Object.keys(s.activeFlights).length,1);assert.equal(Object.values(s.activeFlights)[0].gliderLandingTime,null);
});
test('same external ID from different locations stays distinct, deleted imports stay deleted',()=>{
 let s=imports.reconcile(null,config,[record],now);s=imports.reconcile(s,imports.source('https://logbook.ibisek.com/loc/LKBR'),[record],now);assert.equal(Object.keys(s.activeFlights).length,2);
 const key=imports.keyFor(config,record.externalId);delete s.activeFlights[key];s.importTombstones={[key]:{deletedAt:end}};
 s=imports.reconcile(s,config,[record],now);assert.equal(s.activeFlights[key],undefined);assert.equal(Object.keys(s.activeFlights).length,1);
});
test('invalid batch leaves prior state intact',()=>{
 const state=imports.reconcile(null,config,[record],now),before=structuredClone(state);
 assert.throws(()=>imports.reconcile(state,config,[{...record,externalId:'new'},{...record,externalId:'bad',landingTime:'invalid'}],now));assert.deepEqual(state,before);
});
test('human completion requires pilot, task, launch and tow metadata where applicable; source fields cannot be injected',()=>{
 const details={pilot:'Pilot',copilot:'',task:'Úloha 3',launchType:'Naviják'};
 assert.equal(imports.details(details).copilot,'-');
 for(const bad of [{...details,pilot:''},{...details,task:'-'},{...details,launchType:'Neurčeno'},{...details,launchType:'Aerovlek'},{...details,takeoffTime:start},{...details,detailsComplete:true}])assert.throws(()=>imports.details(bad));
 assert.equal(imports.details({...details,launchType:'Aerovlek',towAircraft:'OK-T',towPilot:'Tow'}).towPilot,'Tow');
});
