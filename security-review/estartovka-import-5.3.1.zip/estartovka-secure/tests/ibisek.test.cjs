const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const ibisek=require('../functions/ibisek'),imports=require('../functions/imports');
const html=fs.readFileSync(__dirname+'/fixtures/ibisek-lkst-2026-10-17.html','utf8');
const options={location:'LKST',date:'2026-10-17'};
const config=imports.source('https://logbook.ibisek.com/loc/LKST');
test('actual supplied HTML yields nine paired flights and converts Prague daylight time correctly',()=>{
 const result=ibisek.parseHTML(html,options);assert.equal(result.records.length,9);assert.equal(result.zone,'Europe/Prague');assert.equal(result.records[0].takeoffTime,'2026-10-17T08:53:00.000Z');assert.equal(result.records[0].landingTime,'2026-10-17T08:59:00.000Z');assert.ok(result.records.every(r=>r.aircraft==='OK-4704' && r.landingTime));
});
test('source settings normalize dated and CSV links into a fixed location',()=>{
 assert.deepEqual(imports.source('https://logbook.ibisek.com/loc/LKST/2026-10-17'),config);
 assert.deepEqual(imports.source('https://logbook.ibisek.com/csv/loc/LKST/2026-10-17'),config);
});
test('wrong day, wrong airport, missing timezone and changed layout fail closed',()=>{
 for(const [input,opts] of [[html,{...options,date:'2026-10-18'}],[html,{...options,location:'LKBR'}],[html.replace('Europe/Prague','Unknown/Zone'),options],[html.replace('Vaše časová zóna','Other zone'),options],[html.replace('Doba letu','Other header'),options],['<html>Access denied</html>',options]])assert.throws(()=>ibisek.parseHTML(input,opts));
 assert.throws(()=>ibisek.parseHTML(html,{...options,requireUTC:true}),/UTC/);
});
test('no HTML scripts are evaluated, UTC declaration is honored, and source size is bounded',()=>{
 globalThis.__ibisekExecuted=false;
 const result=ibisek.parseHTML(html.replace('Europe/Prague','UTC')+'<script>globalThis.__ibisekExecuted=true</script>',{...options,requireUTC:true});
 assert.equal(result.records[0].takeoffTime,'2026-10-17T10:53:00.000Z');assert.equal(globalThis.__ibisekExecuted,false);
 assert.throws(()=>ibisek.parseHTML('x'.repeat(ibisek.MAX_BYTES+1),options));
});
test('departures become active when no paired landing exists; arrivals are not guessed',()=>{
 const cheerio=require('../functions/node_modules/cheerio'),$=cheerio.load(html);
 $('.sitebody .table').last().children('.row:not(.header)').first().remove();
 const result=ibisek.parseHTML($.html(),options);assert.equal(result.records.length,9);assert.equal(result.records[0].landingTime,null);
});
test('ambiguous local daylight-saving times stop import instead of guessing an hour',()=>{
 const modified=html.replaceAll('2026-10-17','2026-10-25').replaceAll('17.10.','25.10.').replaceAll('10:53','02:30');
 assert.throws(()=>ibisek.parseHTML(modified,{...options,date:'2026-10-25'}),/nejednoznačný/);
});
test('changed departure time is quarantined rather than duplicated or overwriting pilot',()=>{
 const batch=ibisek.parseHTML(html,options);let state=ibisek.applyBatch(null,config,[batch]);
 const before=structuredClone(state);const changed=structuredClone(batch);
 changed.records[0].externalId='new-id';changed.records[0].takeoffTime='2026-10-17T08:54:00.000Z';
 assert.throws(()=>ibisek.applyBatch(state,config,[changed]),/duplicita/);assert.deepEqual(state,before);
});
test('live fetch only constructs the fixed HTTPS host, requests UTC and rejects errors, redirects, oversized and non-HTML responses',async()=>{
 let request;
 const mock=async(url,opts)=>{request={url,opts};return new Response('<html></html>',{headers:{'content-type':'text/html'}})};
 assert.equal(await ibisek.fetchHTML('LKST','2026-10-17',mock),'<html></html>');
 assert.equal(request.url,'https://logbook.ibisek.com/loc/LKST/2026-10-17');assert.equal(request.opts.redirect,'error');assert.equal(request.opts.headers.Cookie,'browser_timezone=UTC');
 await assert.rejects(ibisek.fetchHTML('../secret','2026-10-17',mock));
 for(const response of [new Response('Forbidden',{status:403}),new Response('text',{headers:{'content-type':'text/plain'}}),new Response('x'.repeat(ibisek.MAX_BYTES+1),{headers:{'content-type':'text/html'}})])await assert.rejects(ibisek.fetchHTML('LKST','2026-10-17',async()=>response));
});

test('a partial paired-flight table does not reopen a previously landed aircraft',()=>{
 const batch=ibisek.parseHTML(html,options);let state=ibisek.applyBatch(null,config,[batch]);
 const partial=structuredClone(batch);partial.records[0].landingTime=null;
 state=ibisek.applyBatch(state,config,[partial]);assert.equal(Object.keys(state.completedFlights).length,9);assert.equal(Object.keys(state.activeFlights).length,0);
});
test('manual record collision prevents creation of an imported duplicate',()=>{
 const batch=ibisek.parseHTML(html,options);
 const state={activeFlights:{manual:{id:1,aircraft:'OK-4704 (Blaník)',takeoffTime:batch.records[0].takeoffTime}},completedFlights:{}};
 assert.throws(()=>ibisek.applyBatch(state,config,[batch]),/ručně/);
});
