const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs'),vm=require('node:vm');
const validation=require('../functions/security.js');
function harness(){
 const store={airports:{lkst:{icao:'LKST'},other:{icao:'OTHER'},empty:{icao:'EMPTY'}},users:{starter:{role:'starter',airportId:'lkst',fullName:'Starter'},admin:{role:'admin',airportId:'lkst',fullName:'Admin'},guest:{role:'guest',airportId:'lkst'},superadmin:{role:'superadmin',airportId:'lkst'},other:{role:'admin',airportId:'other'}},airportData:{lkst:{activeFlights:{},completedFlights:{}}}};
 const copy=value=>value==null?null:structuredClone(value);
 const get=path=>path.split('/').filter(Boolean).reduce((v,k)=>v?.[k],store) ?? null;
 const set=(path,value)=>{if(!path){for(const k of Object.keys(store))delete store[k];Object.assign(store,value);return;}const parts=path.split('/').filter(Boolean),last=parts.pop();let at=store;for(const k of parts)at=at[k]??={};at[last]=value;};
 let serial=0,queue=Promise.resolve();
 function ref(path=''){return {get:async()=>({val:()=>copy(get(path)),exists:()=>get(path)!==null}),child:key=>ref(path?path+'/'+key:key),push:()=>({key:'key'+ ++serial}),transaction(updater){const task=queue.then(()=>{const result=updater(copy(get(path)));if(result===undefined)return {committed:false};set(path,result);return {committed:true};});queue=task.catch(()=>{});return task;}};}
 class HttpsError extends Error {constructor(code,message){super(message);this.code=code;}}
 const exports={};
 const requireMock=name=>{
  if(name==='firebase-functions/v2/https')return {onCall:(_,handler)=>handler,HttpsError};
  if(name==='firebase-functions/v2/scheduler')return {onSchedule:(_,handler)=>handler};
  if(name==='./import-service')return require('../functions/import-service');
  if(name==='./ibisek')return require('../functions/ibisek');
  if(name==='firebase-functions/v2')return {setGlobalOptions(){}};
  if(name==='firebase-admin/app')return {initializeApp(){}};
  if(name==='firebase-admin/database')return {getDatabase:()=>({ref})};
  if(name==='./security')return validation;
  if(name==='./imports')return require('../functions/imports');
  if(name==='./emulator-config')return require('../functions/emulator-config');
  if(name==='./existing-transaction')return require('../functions/existing-transaction');
  return require(name);
 };
 vm.runInNewContext(fs.readFileSync(__dirname+'/../functions/index.js','utf8'),{require:requireMock,exports,console,Date,process:{env:{}}},{filename:'index.js'});
 function request(uid,data,verified=true){return {auth:uid?{uid,token:{email_verified:verified,email:uid+'@test.invalid'}}:null,data};}
 const payload={aircraft:'OK-1',pilot:'Pilot',launchType:'Naviják',takeoffTime:'1900',id:1,createdBy:'Superadmin',gliderLandingTime:'fake'};
 return {store,exports,request,payload,db:{ref}};
}
function rejected(promise,code){return assert.rejects(promise,error=>error.code===code);}
test('callables require authentication and verified email',async()=>{const h=harness();for(const name of ['createFlight','landFlight','deleteFlight','editFlight','deleteAirport','saveFlightSource','completeFlightDetails','syncFlightSource','importFlightHTML']){await rejected(h.exports[name](h.request(null,{})),'unauthenticated');await rejected(h.exports[name](h.request('starter',{},false)),'permission-denied')}});
test('guest and foreign airport roles cannot create flights',async()=>{const h=harness();for(const uid of ['guest','other'])await rejected(h.exports.createFlight(h.request(uid,{airportId:'lkst',flightData:h.payload})),'permission-denied');await rejected(h.exports.createFlight(h.request('superadmin',{airportId:'../users',flightData:h.payload})),'invalid-argument')});
test('creation strips client identity/time/state and creates audit atomically',async()=>{const h=harness();await h.exports.createFlight(h.request('starter',{airportId:'lkst',flightData:h.payload}));const data=h.store.airportData.lkst,flight=Object.values(data.activeFlights)[0];assert.equal(flight.createdBy,'Starter');assert.equal(flight.gliderLandingTime,null);assert.ok(flight.id!==1 && Number.isSafeInteger(flight.id));assert.ok(Date.parse(flight.takeoffTime)>Date.now()-5000);assert.equal(Object.values(data.auditLogs)[0].flightId,flight.id)});
test('concurrent tow and glider landings preserve both records, complete once',async()=>{const h=harness();h.store.airportData.lkst.activeFlights.flight={id:77,launchType:'Aerovlek',takeoffTime:new Date(Date.now()-120000).toISOString()};await Promise.all(['tow','glider'].map(landingType=>h.exports.landFlight(h.request('starter',{airportId:'lkst',flightId:77,landingType,landingTime:'1900',duration:'99:99'}))));const data=h.store.airportData.lkst;assert.equal(Object.keys(data.activeFlights).length,0);assert.equal(Object.keys(data.completedFlights).length,1);const f=data.completedFlights.flight;assert.ok(f.towLandingTime && f.gliderLandingTime);assert.equal(f.towDuration,'00:02');assert.equal(f.gliderDuration,'00:02');await rejected(h.exports.landFlight(h.request('starter',{airportId:'lkst',flightId:77,landingType:'glider'})),'not-found');assert.equal(Object.keys(data.completedFlights).length,1)});
test('deletion requires administrator of correct airport',async()=>{const h=harness();h.store.airportData.lkst.activeFlights.flight={id:77};for(const uid of ['starter','other'])await rejected(h.exports.deleteFlight(h.request(uid,{airportId:'lkst',flightId:77})),'permission-denied');await h.exports.deleteFlight(h.request('admin',{airportId:'lkst',flightId:77}));assert.equal(h.store.airportData.lkst.activeFlights.flight,undefined)});
test('admin edit validates chronology and transitions atomically',async()=>{const h=harness();const start=new Date(Date.now()-120000).toISOString(),end=new Date(Date.now()-60000).toISOString();h.store.airportData.lkst.activeFlights.flight={id:77,launchType:'Naviják',takeoffTime:start};const data={airportId:'lkst',flightId:77,edits:{task:'Task',takeoffTime:start,gliderLandingTime:end,towLandingTime:null}};await rejected(h.exports.editFlight(h.request('starter',data)),'permission-denied');await rejected(h.exports.editFlight(h.request('admin',{...data,edits:{...data.edits,createdBy:'Fake'}})),'invalid-argument');await rejected(h.exports.editFlight(h.request('admin',{...data,edits:{...data.edits,takeoffTime:end,gliderLandingTime:start}})),'invalid-argument');await h.exports.editFlight(h.request('admin',data));assert.ok(h.store.airportData.lkst.completedFlights.flight);assert.equal(h.store.airportData.lkst.activeFlights.flight,undefined);await h.exports.editFlight(h.request('admin',{...data,edits:{...data.edits,gliderLandingTime:null}}));assert.ok(h.store.airportData.lkst.activeFlights.flight);assert.equal(h.store.airportData.lkst.completedFlights.flight,undefined)});
test('airport removal requires superadmin and no assigned members',async()=>{const h=harness();await rejected(h.exports.deleteAirport(h.request('admin',{airportId:'empty'})),'permission-denied');await rejected(h.exports.deleteAirport(h.request('superadmin',{airportId:'lkst'})),'failed-precondition');await h.exports.deleteAirport(h.request('superadmin',{airportId:'empty'}));assert.equal(h.store.airports.empty,undefined);assert.ok(h.store.airports.lkst)});

test('deployment exposes only the required callable functions',()=>{
 const h=harness();
 assert.deepEqual(Object.keys(h.exports).sort(),['completeFlightDetails','createFlight','deleteAirport','deleteFlight','editFlight','importFlightHTML','landFlight','saveFlightSource','syncAirportFlights','syncFlightSource']);
});

test('source configuration is scoped to airport admins and uses opt-in auto fetching',async()=>{
 const h=harness();const data={airportId:'lkst',url:'https://logbook.ibisek.com/loc/LKST'};
 for(const uid of ['starter','guest','other'])await rejected(h.exports.saveFlightSource(h.request(uid,data)),'permission-denied');
 await rejected(h.exports.saveFlightSource(h.request('admin',{...data,url:'https://localhost/secret'})),'invalid-argument');
 await h.exports.saveFlightSource(h.request('admin',data));assert.equal(h.store.airportData.lkst.flightSource.location,'LKST');assert.equal(h.store.airportData.lkst.flightSource.status,'configured');
 await h.exports.saveFlightSource(h.request('admin',{...data,url:''}));assert.equal(h.store.airportData.lkst.flightSource,null);
});
test('starter can complete imported metadata without modifying aircraft or source times',async()=>{
 const h=harness();const s=h.store.airportData.lkst;const start=new Date(Date.now()-100000).toISOString();
 s.completedFlights.imported={id:88,aircraft:'OK-I',takeoffTime:start,gliderLandingTime:start,imported:{provider:'ibisek',externalId:'1'},detailsComplete:false};
 const data={airportId:'lkst',flightId:88,details:{pilot:'Pilot',copilot:'Instructor',task:'Úloha 3',launchType:'Naviják'}};
 for(const uid of ['guest','other'])await rejected(h.exports.completeFlightDetails(h.request(uid,data)),'permission-denied');
 await rejected(h.exports.completeFlightDetails(h.request('starter',{...data,details:{...data.details,takeoffTime:'fake'}})),'invalid-argument');
 await h.exports.completeFlightDetails(h.request('starter',data));// Read the committed state, not the stale pre-transaction reference.
 const updated=h.store.airportData.lkst.completedFlights.imported;
 assert.equal(updated.pilot,'Pilot');assert.equal(updated.detailsComplete,true);assert.equal(updated.takeoffTime,start);assert.equal(updated.aircraft,'OK-I');assert.equal(updated.detailsCompletedBy,'Starter');
 assert.equal(Object.values(h.store.airportData.lkst.auditLogs)[0].flightId,88);
});
test('imported flights cannot be manually landed or have source times changed; deletion creates tombstone',async()=>{
 const h=harness();const start=new Date(Date.now()-100000).toISOString();h.store.airportData.lkst.activeFlights.import_key={id:88,takeoffTime:start,imported:{externalId:'1'}};
 await rejected(h.exports.landFlight(h.request('starter',{airportId:'lkst',flightId:88,landingType:'glider'})),'failed-precondition');
 await rejected(h.exports.editFlight(h.request('admin',{airportId:'lkst',flightId:88,edits:{task:'Task',takeoffTime:start,gliderLandingTime:null,towLandingTime:null}})),'failed-precondition');
 await h.exports.deleteFlight(h.request('admin',{airportId:'lkst',flightId:88}));assert.equal(h.store.airportData.lkst.activeFlights.import_key,undefined);assert.equal(h.store.airportData.lkst.importTombstones.import_key.deletedBy,'admin');
});

test('HTML upload imports the supplied real nine-flight page, repeats safely, and keeps entered crew',async()=>{
 const h=harness(),html=fs.readFileSync(__dirname+'/fixtures/ibisek-lkst-2026-10-17.html','utf8');
 const data={airportId:'lkst',date:'2026-10-17',html};
 for(const uid of ['starter','guest','other'])await rejected(h.exports.importFlightHTML(h.request(uid,data)),'permission-denied');
 await h.exports.saveFlightSource(h.request('admin',{airportId:'lkst',url:'https://logbook.ibisek.com/loc/LKST'}));
 await h.exports.importFlightHTML(h.request('admin',data));
 let state=h.store.airportData.lkst;
 assert.equal(Object.values(state.completedFlights).length,9);assert.equal(state.flightSource.lastImportCount,9);assert.equal(state.flightSource.lastImportMode,'file');
 const f=Object.values(state.completedFlights)[0];
 await h.exports.completeFlightDetails(h.request('starter',{airportId:'lkst',flightId:f.id,details:{pilot:'Pilot',task:'Úloha 3',launchType:'Naviják'}}));
 await h.exports.importFlightHTML(h.request('admin',data));
 state=h.store.airportData.lkst;assert.equal(Object.values(state.completedFlights).length,9);assert.equal(Object.values(state.completedFlights).find(x=>x.id===f.id).pilot,'Pilot');
 assert.equal(state.flightSource.lease,undefined);assert.equal(state.flightSource.enabled,false);
});
test('malformed HTML upload reports failure and releases its lease',async()=>{
 const h=harness();await h.exports.saveFlightSource(h.request('admin',{airportId:'lkst',url:'https://logbook.ibisek.com/loc/LKST'}));
 await rejected(h.exports.importFlightHTML(h.request('admin',{airportId:'lkst',date:'2026-10-17',html:'<html>error</html>'})),'invalid-argument');
 assert.equal(h.store.airportData.lkst.flightSource.status,'error');assert.equal(h.store.airportData.lkst.flightSource.lease,undefined);
 assert.equal(Object.keys(h.store.airportData.lkst.completedFlights).length,0);
});

test('source change during online fetch cannot commit stale flights or touch the new config',async()=>{
 const h=harness();await h.exports.saveFlightSource(h.request('admin',{airportId:'lkst',url:'https://logbook.ibisek.com/loc/LKST'}));
 const original=fs.readFileSync(__dirname+'/fixtures/ibisek-lkst-2026-10-17.html','utf8').replace('Europe/Prague','UTC');
 const {runImport}=require('../functions/import-service');
 await rejected(runImport({db:h.db,airport:'lkst',now:Date.parse('2026-10-17T20:00:00.000Z'),fetchHTML:async(location,date)=>original.replaceAll('2026-10-17',date).replaceAll('17.10.',date.endsWith('16')?'16.10.':'17.10.'),recheck:async()=>{h.store.airportData.lkst.flightSource={url:'https://logbook.ibisek.com/loc/LKBR',revision:'new-config'};}}),'aborted');
 assert.equal(Object.keys(h.store.airportData.lkst.completedFlights).length,0);assert.equal(h.store.airportData.lkst.flightSource.revision,'new-config');assert.equal(h.store.airportData.lkst.flightSource.status,undefined);
});
test('online service imports two UTC days once, honors cooldown, and respects the auto-import switch',async()=>{
 const h=harness();await h.exports.saveFlightSource(h.request('admin',{airportId:'lkst',url:'https://logbook.ibisek.com/loc/LKST'}));
 const original=fs.readFileSync(__dirname+'/fixtures/ibisek-lkst-2026-10-17.html','utf8').replace('Europe/Prague','UTC'),{runImport}=require('../functions/import-service');let calls=0;
 const options={db:h.db,airport:'lkst',now:Date.parse('2026-10-17T20:00:00.000Z'),fetchHTML:async(location,date)=>{calls++;return original.replaceAll('2026-10-17',date).replaceAll('17.10.',date.endsWith('16')?'16.10.':'17.10.');}};
 assert.equal((await runImport({...options,scheduled:true})).skipped,true);assert.equal(calls,0);
 assert.equal((await runImport(options)).count,18);assert.equal(calls,2);assert.equal(Object.values(h.store.airportData.lkst.completedFlights).length,18);
 assert.equal((await runImport(options)).reason,'cooldown');assert.equal(calls,2);
});

test('online session timezone hint stays server-only and is not accepted from an HTML upload caller',async()=>{
 const h=harness();await h.exports.saveFlightSource(h.request('admin',{airportId:'lkst',url:'https://logbook.ibisek.com/loc/LKST'}));
 const original=fs.readFileSync(__dirname+'/fixtures/ibisek-lkst-2026-10-17.html','utf8').replace(/Vaše časová zóna je zřejmě[\s\S]*?zóny\./,'');
 await rejected(h.exports.importFlightHTML(h.request('admin',{airportId:'lkst',date:'2026-10-17',html:original,sessionTimezone:'UTC'})),'invalid-argument');
 const {runImport}=require('../functions/import-service');
 const result=await runImport({db:h.db,airport:'lkst',now:Date.parse('2026-10-17T20:00:00.000Z'),fetchHTML:async(location,date)=>({html:original.replaceAll('2026-10-17',date).replaceAll('17.10.',date.endsWith('16')?'16.10.':'17.10.'),sessionTimezone:'UTC'})});
 assert.equal(result.count,18);const flights=Object.values(h.store.airportData.lkst.completedFlights);assert.equal(Math.min(...flights.map(f=>Date.parse(f.takeoffTime))),Date.parse('2026-10-16T10:53:00.000Z'));
});
