const {readFileSync}=require('node:fs');
const {test,before,after}=require('node:test');
const {initializeTestEnvironment,assertFails,assertSucceeds}=require('@firebase/rules-unit-testing');
const {ref,get,set,update,query,orderByChild,equalTo}=require('firebase/database');
let env;
const profile=(role,airportId='lkst')=>({email:'test@example.org',fullName:'Test',role,airportId});
const db=(uid,verified=true)=>env.authenticatedContext(uid,{email:'test@example.org',email_verified:verified}).database();
before(async()=>{
 env=await initializeTestEnvironment({projectId:'demo-estartovka-security',database:{host:'127.0.0.1',port:9000,rules:readFileSync(__dirname+'/../database.rules.json','utf8')}});
 await env.withSecurityRulesDisabled(async c=>set(ref(c.database()),{airports:{lkst:{name:'A',icao:'LKST'},other:{name:'B',icao:'OTHER'}},users:{starter:profile('starter'),guest:profile('guest'),admin:profile('admin'),otherAdmin:profile('admin','other'),superadmin:profile('superadmin')},airportData:{lkst:{activeFlights:{one:{id:1,pilot:'Private'}},auditLogs:{one:'test'}},other:{activeFlights:{one:{id:2}}}}}));
});
after(async()=>env?.cleanup());
test('anonymous cannot read flights or users',async()=>{let d=env.unauthenticatedContext().database();await assertFails(get(ref(d,'airportData/lkst')));await assertFails(get(ref(d,'users')))});
test('starter reads own airport only',async()=>{await assertSucceeds(get(ref(db('starter'),'airportData/lkst')));await assertFails(get(ref(db('starter'),'airportData/other')))});
test('guest and unverified member cannot read flights',async()=>{await assertFails(get(ref(db('guest'),'airportData/lkst')));await assertFails(get(ref(db('starter',false),'airportData/lkst')))});
test('self promotion forbidden',async()=>assertFails(set(ref(db('guest'),'users/guest/role'),'superadmin')));
test('self airport change forbidden',async()=>assertFails(set(ref(db('starter'),'users/starter/airportId'),'other')));
test('new account must be guest',async()=>{await assertFails(set(ref(db('new'),'users/new'),profile('admin')));await assertSucceeds(set(ref(db('new'),'users/new'),profile('guest')))});
test('admin cannot promote itself or create superadmin',async()=>{await assertFails(set(ref(db('admin'),'users/admin/role'),'superadmin'));await assertFails(set(ref(db('admin'),'users/guest/role'),'admin'))});
test('admin cannot edit another airport member',async()=>assertFails(set(ref(db('otherAdmin'),'users/starter/fullName'),'Changed')));
test('admin can approve own airport guest',async()=>assertSucceeds(set(ref(db('admin'),'users/guest/role'),'starter')));
test('flight and audit writes require trusted backend even for admin',async()=>{for(const uid of ['starter','admin','superadmin'])for(const node of ['activeFlights','completedFlights','auditLogs'])await assertFails(set(ref(db(uid),`airportData/lkst/${node}/injected`),{id:99}))});
test('fleet writes require own airport admin',async()=>{await assertFails(set(ref(db('starter'),'airportData/lkst/customGliders'),['X']));await assertFails(set(ref(db('otherAdmin'),'airportData/lkst/customGliders'),['X']));await assertSucceeds(set(ref(db('admin'),'airportData/lkst/customGliders'),['X']))});
test('airport creation requires superadmin',async()=>{await assertFails(set(ref(db('starter'),'airports/new'),{name:'New',icao:'NEW'}));await assertSucceeds(set(ref(db('superadmin'),'airports/new'),{name:'New',icao:'NEW'}))});
test('users directory requires scoped admin query',async()=>{await assertFails(get(ref(db('starter'),'users')));await assertFails(get(ref(db('admin'),'users')));await assertSucceeds(get(query(ref(db('admin'),'users'),orderByChild('airportId'),equalTo('lkst'))));await assertFails(get(query(ref(db('admin'),'users'),orderByChild('airportId'),equalTo('other'))))});
test('own profile can be read and renamed, unknown fields forbidden',async()=>{await assertSucceeds(get(ref(db('starter'),'users/starter')));await assertSucceeds(set(ref(db('starter'),'users/starter/fullName'),'New Name'));await assertFails(update(ref(db('starter'),'users/starter'),{unexpected:true}))});
test('atomic role escalation and flight injection forbidden',async()=>assertFails(update(ref(db('starter')),{ 'users/starter/role':'superadmin','airportData/lkst/activeFlights/hack':{id:100}})));
test('superadmin can save and clear a safe HTTPS airport logo',async()=>{
 const path=ref(db('superadmin'),'airports/lkst/logoUrl');
 await assertSucceeds(set(path,'https://example.test/logo.png'));
 await assertSucceeds(set(path,''));
});
test('airport logo writes remain forbidden for other roles and unsafe URLs',async()=>{
 for(const uid of ['starter','admin','guest'])await assertFails(set(ref(db(uid),'airports/lkst/logoUrl'),'https://example.test/logo.png'));
 await assertFails(set(ref(db('superadmin'),'airports/lkst/logoUrl'),'javascript:alert(1)'));
});
test('superadmin can save a PNG data logo without opening SVG, HTML or excessive data writes',async()=>{
 const png=JSON.parse(readFileSync(__dirname+'/logo-data.json','utf8'));
 const path=ref(db('superadmin'),'airports/lkst/logoUrl');
 await assertSucceeds(set(path,png));
 for(const value of ['data:image/svg+xml;base64,PHN2Zz4=','data:text/html;base64,PHNjcmlwdD4=','data:image/png;base64,iVBORw0KGgo'+'A'.repeat(350000)])await assertFails(set(path,value));
});

test('clients cannot configure import sources or erase tombstones directly',async()=>{for(const uid of ['starter','admin','superadmin'])for(const node of ['flightSource','importTombstones','importSnapshots'])await assertFails(set(ref(db(uid),`airportData/lkst/${node}`),{injected:true}))});
