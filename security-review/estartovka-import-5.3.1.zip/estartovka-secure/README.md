# E-Startovka – import Ibisek v5.3.1

Každé letiště má vlastní zdroj ve správě letiště. Převzaté lety vyžadují doplnění pilota, úlohy a způsobu startu. Podporované je načítání tabulek Ibisek, import uloženého HTML a volitelná synchronizace po pěti minutách.

**Import dodaného HTML z LKST je ověřený. Online spojení s Ibisek ze skutečného Firebase zatím není ověřené.** Podrobné použití, nasazení, výsledky testů a omezení jsou v [IMPORT-LETU.md](IMPORT-LETU.md). Žádná změna z tohoto chatu nebyla nasazena do živého Firebase.

Přenášejte celý balíček, včetně složky functions a lockfilů. Závislosti backendu nově zahrnují bezpečný HTML parser a časové převody. Starší hotfix obsahující jediný functions/index.js není aktualizací pro tuto verzi.

Původní ochrany zůstávají: přihlášení před výběrem letiště, zamčená nepřístupná letiště, provoz jen pro schválené členy, serverová autorizace změn letů, audit, chráněné role a podpora omezených PNG log. Místní demo konfigurace a produkční Hosting jsou oddělené.
