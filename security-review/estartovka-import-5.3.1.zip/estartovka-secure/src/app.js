import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/database';
import 'firebase/compat/functions';
import {html, render} from 'lit-html';
import {createIcons, icons} from 'lucide';
import {safeImageURL, csvCell, MAX_LOGO_BYTES} from './security-ui.js';
import {installImportUI} from './import-ui.js';
const lucide = {createIcons: () => createIcons({icons})};
function setContent(element, value) {
    const fragment = document.createDocumentFragment();
    render(value, fragment);
    element.replaceChildren(fragment);
}

                        // ==========================================
                        // 1. FIREBASE CONFIG & INITIALIZATION
                        // ==========================================
                        const firebaseConfig = window.ESTARTOVKA_CONFIG.firebase;

                        firebase.initializeApp(firebaseConfig);
if (window.ESTARTOVKA_CONFIG.useEmulators) {
    firebase.auth().useEmulator('http://127.0.0.1:9099');
    firebase.database().useEmulator('127.0.0.1', 9000);
    firebase.app().functions('europe-west1').useEmulator('127.0.0.1', 5001);
}
                        const database = firebase.database();
                        const auth = firebase.auth();
                        const functions = firebase.app().functions("europe-west1");

                        const createFlightCallable = functions.httpsCallable("createFlight");
                        const landFlightCallable = functions.httpsCallable("landFlight");
                        const deleteFlightCallable = functions.httpsCallable("deleteFlight");
const editFlightCallable = functions.httpsCallable('editFlight');
const deleteAirportCallable = functions.httpsCallable('deleteAirport');

                        const defaultGliders = ["OK-4704 (L-13 Blaník)", "OK-5602 (VSO-10)"];
                        const defaultTows = ["OK-DUO 79 (Airlony Skyline)"];
                        const defaultTowPilots = ["Petr Novák"];

                        let airportsList = {};
                        let currentAirportId = null;

                        let activeFlights = [];
                        let completedFlights = [];
                        let auditLogs = [];
                        let customGliders = [];
                        let customTows = [];
                        let customTowPilots = [];
                        let allUsersMap = {};
let authEpoch = 0, airportGeneration = 0;
let airportSubscriptions = [], directorySubscription = null, profileSubscription = null;
let catalogSubscription = null, catalogGeneration = 0, airportsReady = false;
let flightSource = null;


                        let currentUser = null;
                        let currentUserData = null;

                        let currentTab = 'today';
                        let flightToDeleteId = null;
                        let airportToDeleteId = null;
                        let currentRandomCode = "";
                        let currentAirportRandomCode = "";
                        let isRegisterMode = false;
                        let isPasswordResetMode = false;

                        let lastResendTimestamp = 0;
                        let resendIntervalTimer = null;

                        let lastTowPilot = '';
localStorage.removeItem('startovka_last_tow_pilot');

                        const aircraftSelect = document.getElementById('aircraft-select');
                        const towAircraftSelect = document.getElementById('tow-aircraft-select');
                        const towPilotSelect = document.getElementById('tow-pilot-select');
                        const startForm = document.getElementById('start-form');
                        const activeFlightsContainer = document.getElementById('active-flights-list');
                        const noActiveFlightsEl = document.getElementById('no-active-flights');
                        const todayTableBody = document.getElementById('today-completed-flights-table');
                        const noTodayCompletedEl = document.getElementById('no-today-completed-flights');
                        const activeCountBadge = document.getElementById('active-count');
                        const towDetailsSection = document.getElementById('tow-details-section');
                        const launchTypeRadios = document.querySelectorAll('input[name="launch-type"]');

                        const fleetModal = document.getElementById('fleet-modal');
                        const addAircraftForm = document.getElementById('add-aircraft-form');
                        const modalGlidersList = document.getElementById('modal-gliders-list');
                        const modalTowsList = document.getElementById('modal-tows-list');
                        const modalTowPilotsList = document.getElementById('modal-tow-pilots-list');
                        const adminUsersList = document.getElementById('admin-users-list');

                        const superAdminModal = document.getElementById('superadmin-modal');
                        const createAirportForm = document.getElementById('create-airport-form');
                        const superadminUsersList = document.getElementById('superadmin-users-list');
                        const superadminAirportsList = document.getElementById('superadmin-airports-list');
                        const deleteAirportModal = document.getElementById('delete-airport-modal');

                        const editModal = document.getElementById('edit-modal');
                        const editFlightForm = document.getElementById('edit-flight-form');

                        const authModal = document.getElementById('auth-modal');
                        const authForm = document.getElementById('auth-form');
                        const authActionBtnText = document.getElementById('auth-btn-text');
                        const userRoleBadge = document.getElementById('user-role-badge');
                        const viewerWarningBanner = document.getElementById('viewer-warning-banner');
                        const viewerBannerText = document.getElementById('viewer-banner-text');
                        const formDisabledOverlay = document.getElementById('form-disabled-overlay');
                        const formDisabledText = document.getElementById('form-disabled-text');
                        const authErrorMsg = document.getElementById('auth-error-msg');
                        const authSuccessMsg = document.getElementById('auth-success-msg');
                        const resendContainer = document.getElementById('resend-container');
                        const resendBtn = document.getElementById('resend-btn');

                        const openFleetModalBtn = document.getElementById('open-fleet-modal-btn');
                        const openSuperadminBtn = document.getElementById('open-superadmin-btn');
                        const airportSelectorModal = document.getElementById('airport-selector-modal');

                        // ==========================================
                        // 2. KONTROLA A POSLECH LETIŠŤ V DB
                        // ==========================================
const importUI = installImportUI({
    getAirport: () => currentAirportId,
    getFlights: () => [...activeFlights, ...completedFlights],
    canWrite: () => userHasWritePermissionForCurrentAirport(),
    isAdmin: () => userIsAdminForCurrentAirport(),
    getSource: () => flightSource,
    saveSource: functions.httpsCallable('saveFlightSource'),
    saveDetails: functions.httpsCallable('completeFlightDetails'),
    syncSource: functions.httpsCallable('syncFlightSource'),
    importHTML: functions.httpsCallable('importFlightHTML'),
    setContent, formatTime: value => formatTime(value)
});
                        function updateCurrentAirportLabel() {
                            const label = document.getElementById('current-airport-label');
                            const logoContainer = document.getElementById('header-logo-container');

                            // Logo se nyní zobrazuje POUZE při vybírání letišť, v hlavičce zůstává výchozí ikona E-Startovky
                            setContent(logoContainer, html`<i data-lucide="plane-takeoff" class="w-6 h-6 text-white"></i>`);
                            logoContainer.className = "p-2 bg-blue-600 rounded-xl shadow-md flex items-center justify-center overflow-hidden w-10 h-10 shrink-0";

                            if (currentAirportId && airportsList[currentAirportId]) {
                                const ap = airportsList[currentAirportId];
                                label.textContent = `${ap.name} (${ap.icao})`;
                            } else {
                                label.textContent = "Vyberte letiště";
                            }
                            lucide.createIcons();
                        }

                        window.openAirportSelector = function() {
    if (!currentUser?.emailVerified || !currentUserData) { openAuthModal(); return; }
    document.getElementById('airport-selector-description').textContent = ['starter', 'admin', 'superadmin'].includes(currentUserData.role) ? 'Vyberte letiště. Zamčená letiště nejsou pro váš účet přístupná.' : 'Členství čeká na schválení. Letiště zatím nelze otevřít.';
    document.getElementById('selector-superadmin-btn').hidden = currentUserData.role !== 'superadmin';
    renderAirportGrid();
    document.getElementById('app-shell').hidden = true;
    authModal.classList.add('hidden');
    document.getElementById('membership-gate').classList.add('hidden');
    airportSelectorModal.classList.remove('hidden');
};

                        window.closeAirportSelector = function() {
                            if (!currentAirportId) return;
                            airportSelectorModal.classList.add('hidden');
                        };

                        function getSortedAirportsArray() {
                            return Object.keys(airportsList)
                                .map(id => ({ ...airportsList[id], id }))
                                .sort((a, b) => {
                                    const orderA = a.order !== undefined ? Number(a.order) : 0;
                                    const orderB = b.order !== undefined ? Number(b.order) : 0;
                                    if (orderA !== orderB) return orderA - orderB;
                                    return a.id.localeCompare(b.id);
                                });
                        }

                        function renderAirportGrid() {
                            const grid = document.getElementById('airports-grid');
                            setContent(grid, '');

                            if (!currentUser?.emailVerified || !currentUserData) return;
                            const sorted = getSortedAirportsArray();
                            sorted.forEach(ap => {
                                const card = document.createElement('button');
                                card.type = "button";
                                card.className = "btn-touch w-full bg-white hover:bg-blue-50 text-slate-900 p-4 rounded-2xl shadow-xl border-2 border-transparent hover:border-blue-300 transition flex items-center justify-between text-left group";
                                const allowed = canReadAirport(ap.id);
                                card.disabled = !allowed;
                                card.setAttribute('aria-disabled', String(!allowed));
                                if (!allowed) card.classList.add('opacity-60', 'cursor-not-allowed');
                                card.onclick = () => { if (allowed) selectAirport(ap.id, true); };

                                let logoHtml = html`
                                    <div class="p-3 bg-blue-100 text-blue-600 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition shrink-0 flex items-center justify-center w-12 h-12">
                                        <i data-lucide="plane" class="w-6 h-6"></i>
                                    </div>
                                `;
                                if (safeImageURL(ap.logoUrl)) {
                                    logoHtml = html`
                                        <div class="p-1 bg-white rounded-xl border border-slate-200 shrink-0 flex items-center justify-center w-12 h-12 overflow-hidden shadow-sm">
                                            <img src="${safeImageURL(ap.logoUrl)}" alt="Logo" class="w-full h-full object-contain">
                                        </div>
                                    `;
                                }

                                setContent(card, html`
                                    <div class="flex items-center space-x-4">
                                        ${logoHtml}
                                        <div>
                                            <div class="font-black text-lg text-slate-900 tracking-wide">${ap.icao}</div>
                                            <div class="text-xs font-semibold text-slate-600">${ap.name}</div>
                                            ${allowed ? '' : html`<div class="text-xs font-bold text-slate-500 mt-1">Bez oprávnění</div>`}
                                        </div>
                                    </div>
                                    <div class="p-2 bg-slate-100 rounded-xl text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition">
                                        <i data-lucide="${allowed ? 'chevron-right' : 'lock'}" class="w-5 h-5"></i>
                                    </div>
                                `);
                                grid.appendChild(card);
                            });
                            lucide.createIcons();
                        }

                        function selectAirport(id, closeModal = true) {
    if (!currentUser?.emailVerified || !currentUserData) { openAuthModal(); return; }
    if (!Object.prototype.hasOwnProperty.call(airportsList, id) || !canReadAirport(id)) return;
    detachAirportListeners(); clearPrivateData();
    currentAirportId = id;
    updateCurrentAirportLabel();
    if (closeModal) closeAirportSelector();
    authModal.classList.add('hidden');
    document.getElementById('membership-gate').classList.add('hidden');
    document.getElementById('app-shell').hidden = false;
    document.getElementById('auth-close-btn').hidden = false;
    attachAirportListeners(id);
    subscribeDirectory(authEpoch);
    updatePilotsDatalist(); updateUIForPermissions();
}

                        function attachAirportListeners(id) {
    detachAirportListeners();
    if (!canReadAirport(id)) return;
                            privateListen(id, 'flightSource', snapshot => { flightSource = snapshot.val(); importUI.renderSource(false); });
                            privateListen(id, 'activeFlights', (snapshot) => {
                                const val = snapshot.val();
                                activeFlights = val ? (Array.isArray(val) ? val.filter(Boolean) : Object.values(val)) : [];
                                importUI.renderQueue();
                                if (currentTab === 'today') renderTodayView();
                            });

                            privateListen(id, 'completedFlights', (snapshot) => {
                                const val = snapshot.val();
                                completedFlights = val ? (Array.isArray(val) ? val.filter(Boolean) : Object.values(val)) : [];
                                importUI.renderQueue();
                                if (currentTab === 'today') renderTodayCompletedFlights();
                                else if (currentTab === 'history') applyHistoryFilters();
                            });

                            privateListen(id, 'auditLogs', (snapshot) => {
                                const val = snapshot.val();
                                auditLogs = val ? (Array.isArray(val) ? val.filter(Boolean) : Object.values(val)) : [];
                                if (currentTab === 'logs') applyLogFilters();
                            });

                            privateListen(id, 'customGliders', (snapshot) => {
                                const val = snapshot.val();
                                if (val === null) {
                                    customGliders = [...defaultGliders];
                                } else {
                                    customGliders = Array.isArray(val) ? val : Object.values(val);
                                }
                                populateAircraftSelects();
                                if (!fleetModal.classList.contains('hidden')) renderFleetLists();
                            });

                            privateListen(id, 'customTows', (snapshot) => {
                                const val = snapshot.val();
                                if (val === null) {
                                    customTows = [...defaultTows];
                                } else {
                                    customTows = Array.isArray(val) ? val : Object.values(val);
                                }
                                populateAircraftSelects();
                                if (!fleetModal.classList.contains('hidden')) renderFleetLists();
                            });

                            privateListen(id, 'customTowPilots', (snapshot) => {
                                const val = snapshot.val();
                                if (val === null) {
                                    customTowPilots = [...defaultTowPilots];
                                } else {
                                    customTowPilots = Array.isArray(val) ? val : Object.values(val);
                                }
                                populateTowPilotSelect();
                                if (!fleetModal.classList.contains('hidden')) renderFleetLists();
                            });
                        }

                        function saveData() {
    if (!userIsAdminForCurrentAirport()) return;
    return database.ref('airportData/' + currentAirportId).update({
        customGliders, customTows, customTowPilots
    }).catch(error => alert('Flotilu se nepodařilo uložit: ' + error.message));
}

                        function logAction() { /* Flight audit is generated by the server. */ }

                        function updatePilotsDatalist() {
                            const datalist = document.getElementById('pilots-list');
                            setContent(datalist, '');

                            if (allUsersMap && currentAirportId) {
                                const usersArray = Object.values(allUsersMap)
                                    .filter(u => (u.airportId === currentAirportId || u.role === 'superadmin') && u.role !== 'guest')
                                    .sort((a, b) => (a.fullName || '').localeCompare(b.fullName || ''));

                                usersArray.forEach(u => {
                                    if (u.fullName) {
                                        const option = document.createElement('option');
                                        option.value = u.fullName;
                                        datalist.appendChild(option);
                                    }
                                });
                            }
                        }

                        // ==========================================
                        // 3. AUTH & OPRAVNĚNÍ
                        // ==========================================
                        auth.onAuthStateChanged(async (user) => {
    const epoch = ++authEpoch;
    const hadSession = !!currentUser;
    detachIdentity();
    detachAirportListeners();
    currentUser = null;
    currentUserData = null;
    currentAirportId = null;
    clearPrivateData();
    updateCurrentAirportLabel(); updateUIForPermissions();
    showLoginGate();
    if (!user) {
        if (hadSession) openAuthModal();
        return;
    }
    try {
        await user.reload();
        if (epoch !== authEpoch || !user.emailVerified) return;
        await user.getIdToken(true);
        if (epoch !== authEpoch) return;
        currentUser = user;
        const ref = database.ref('users/' + user.uid);
        const callback = snapshot => {
            if (epoch !== authEpoch) return;
            detachAirportListeners();
            detachDirectory();
            clearPrivateData();
            currentUserData = snapshot.val();
            updateUIForPermissions();
            if (!currentUserData) {
                showMembershipGate('Profil není dokončený. Kontaktujte správce svého letiště.');
                return;
            }
            subscribeDirectory(epoch);
            if (!catalogSubscription) startAirportCatalog(epoch);
            if (!canReadAirport(currentAirportId)) currentAirportId = null;
            if (currentAirportId && airportsReady) selectAirport(currentAirportId);
            else routeAfterLogin();
            const pilotInput = document.getElementById('pilot-name');
            if (pilotInput) pilotInput.value = currentUserData.fullName || '';
        };
        profileSubscription = {ref, callback};
        ref.on('value', callback, error => {
            if (epoch !== authEpoch) return;
            detachAirportListeners(); detachDirectory(); clearPrivateData();
            currentUserData = null; updateUIForPermissions();
            showMembershipGate('Profil nelze načíst. Zkuste se přihlásit znovu.');
        });
    } catch (error) {
        if (epoch !== authEpoch) return;
        detachIdentity(); detachAirportListeners();
        currentUser = null; currentUserData = null;
        clearPrivateData(); updateUIForPermissions(); showLoginGate();
        authErrorMsg.textContent = 'Přihlášení nelze ověřit: ' + error.message;
        authErrorMsg.classList.remove('hidden');
    }
});

                        function userHasWritePermissionForCurrentAirport() {
                            if (!currentUser || !currentUserData) return false;
                            if (currentUserData.role === 'superadmin') return true;
                            const userAirport = currentUserData.airportId || 'lkst';
                            if (userAirport !== currentAirportId) return false;
                            return currentUserData.role === 'admin' || currentUserData.role === 'starter';
                        }

                        function userIsAdminForCurrentAirport() {
                            if (!currentUser || !currentUserData) return false;
                            if (currentUserData.role === 'superadmin') return true;
                            return currentUserData.role === 'admin' && (currentUserData.airportId === currentAirportId);
                        }

                        function updateUIForPermissions() {
                            const isSuperAdmin = currentUserData && currentUserData.role === 'superadmin';
                            const canWrite = userHasWritePermissionForCurrentAirport();
                            const isAdmin = userIsAdminForCurrentAirport();

                            if (currentUser && currentUserData) {
                                let roleLabel = "Host (Guest)";
                                if (currentUserData.role === 'superadmin') roleLabel = "SuperAdmin";
                                else if (currentUserData.role === 'admin') roleLabel = `Admin (${currentUserData.airportId?.toUpperCase() || ''})`;
                                else if (currentUserData.role === 'starter') roleLabel = `Startér / Pilot (${currentUserData.airportId?.toUpperCase() || ''})`;

                                userRoleBadge.className = "flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border bg-emerald-950 border-emerald-700 text-emerald-300";
                                setContent(userRoleBadge, html`<i data-lucide="shield-check" class="w-4 h-4 text-emerald-400"></i><span>${currentUserData.fullName || currentUser.email} (${roleLabel})</span>`);
                                authActionBtnText.textContent = "Odhlásit";

                                if (!canReadAirport(currentAirportId)) {
                                    viewerWarningBanner.classList.remove('hidden');
                                    viewerBannerText.textContent = 'Přístup k provozu vyžaduje schválené členství ve vlastním letišti.';
                                } else {
                                    viewerWarningBanner.classList.add('hidden');
                                }
                            } else {
                                userRoleBadge.className = "flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border bg-slate-800 border-slate-700 text-slate-300";
                                setContent(userRoleBadge, html`<i data-lucide="eye" class="w-4 h-4 text-amber-400"></i><span>Nepřihlášen</span>`);
                                authActionBtnText.textContent = "Přihlásit se";
                                viewerWarningBanner.classList.remove('hidden');
                                viewerBannerText.textContent = 'Provoz je přístupný pouze ověřeným a schváleným členům vlastního letiště.';
                            }

                            if (canWrite) {
                                formDisabledOverlay.classList.add('hidden');
                            } else {
                                formDisabledOverlay.classList.remove('hidden');
                                if (currentUser && currentUserData && currentUserData.airportId !== currentAirportId) {
                                    formDisabledText.textContent = `Nemáte oprávnění zapisovat na letišti ${currentAirportId?.toUpperCase()}. Vaše domovské letiště je ${currentUserData.airportId?.toUpperCase()}.`;
                                } else if (currentUser && currentUserData && currentUserData.role === 'guest') {
                                    formDisabledText.textContent = "Členství čeká na schválení. Požádejte správce svého letiště o přístup.";
                                } else {
                                    formDisabledText.textContent = "Zadávání nových letů vyžaduje přihlášení v roli Startér / Pilot nebo Admin pro toto letiště.";
                                }
                            }

                            if (isAdmin) openFleetModalBtn.classList.remove('hidden');
                            else openFleetModalBtn.classList.add('hidden');

                            if (isSuperAdmin) openSuperadminBtn.classList.remove('hidden');
                            else openSuperadminBtn.classList.add('hidden');

                            lucide.createIcons();
                            if (currentTab === 'today') renderTodayView();
                            else if (currentTab === 'history') applyHistoryFilters();
                            else if (currentTab === 'logs') applyLogFilters();
                        }

                        window.handleAuthButton = function() {
                            if (currentUser) {
                                auth.signOut().then(() => alert("Byli jste odhláseni."));
                            } else {
                                openAuthModal();
                            }
                        };

                        window.openAuthModal = function() {
                            airportSelectorModal.classList.add('hidden');
                            document.getElementById('membership-gate').classList.add('hidden');
                            authErrorMsg.classList.add('hidden');
                            authSuccessMsg.classList.add('hidden');
                            document.getElementById('auth-email').value = '';
                            document.getElementById('auth-password').value = '';
                            document.getElementById('auth-fullname').value = '';
                            isRegisterMode = false;
                            isPasswordResetMode = false;
                            updateAuthModalUI();
                            authModal.classList.remove('hidden');
                        };

                        window.closeAuthModal = function() {
                            if (!currentUser?.emailVerified || !currentUserData) return;
                            authModal.classList.add('hidden');
                            if (resendIntervalTimer) clearInterval(resendIntervalTimer);
                        };

                        window.toggleAuthMode = function() {
                            isRegisterMode = !isRegisterMode;
                            if (isRegisterMode) loadRegistrationAirports();
                            isPasswordResetMode = false;
                            authErrorMsg.classList.add('hidden');
                            authSuccessMsg.classList.add('hidden');
                            updateAuthModalUI();
                        };

                        window.togglePasswordResetMode = function() {
                            isPasswordResetMode = !isPasswordResetMode;
                            authErrorMsg.classList.add('hidden');
                            authSuccessMsg.classList.add('hidden');
                            updateAuthModalUI();
                        };

                        function populateAuthAirportSelect() {
                            const select = document.getElementById('auth-home-airport');
                            setContent(select, '');
                            const sorted = getSortedAirportsArray();
                            sorted.forEach(ap => {
                                const opt = document.createElement('option');
                                opt.value = ap.id;
                                opt.textContent = `${ap.name} (${ap.icao})`;
                                select.appendChild(opt);
                            });
                            if (currentAirportId) select.value = currentAirportId;
                        }

                        function updateAuthModalUI() {
                            const titleEl = document.getElementById('auth-modal-title');
                            const submitBtn = document.getElementById('auth-submit-btn');
                            const nameContainer = document.getElementById('auth-name-container');
                            const passwordGroup = document.getElementById('auth-password-group');
                            const toggleModeBtn = document.getElementById('auth-toggle-mode-btn');
                            const airportSelectContainer = document.getElementById('auth-airport-select-container');

                            if (isPasswordResetMode) {
                                titleEl.textContent = "Obnovení hesla";
                                submitBtn.textContent = "Odeslat odkaz";
                                nameContainer.classList.add('hidden');
                                passwordGroup.classList.add('hidden');
                                airportSelectContainer.classList.add('hidden');
                                resendContainer.classList.remove('hidden');
                                setContent(toggleModeBtn, html`<span>Zpět na přihlášení</span>`);
                            } else if (isRegisterMode) {
                                titleEl.textContent = "Registrace nového účtu";
                                submitBtn.textContent = "Zaregistrovat se";
                                nameContainer.classList.remove('hidden');
                                passwordGroup.classList.remove('hidden');
                                airportSelectContainer.classList.remove('hidden');
                                resendContainer.classList.remove('hidden');
                                setContent(toggleModeBtn, html`<span>Už máte účet? Přihlaste se</span>`);
                            } else {
                                titleEl.textContent = "Přihlášení uživatele";
                                submitBtn.textContent = "Přihlásit se";
                                nameContainer.classList.add('hidden');
                                passwordGroup.classList.remove('hidden');
                                airportSelectContainer.classList.add('hidden');
                                resendContainer.classList.add('hidden');
                                setContent(toggleModeBtn, html`<span>Nemáte účet? Zaregistrujte se</span>`);
                            }
                            updateResendButtonState();
                        }

                        function updateResendButtonState() {
                            if (resendIntervalTimer) clearInterval(resendIntervalTimer);
                            const now = Date.now();
                            const elapsed = (now - lastResendTimestamp) / 1000;
                            const cooldown = 30;

                            if (elapsed < cooldown) {
                                let remaining = Math.ceil(cooldown - elapsed);
                                resendBtn.disabled = true;
                                resendBtn.className = "w-full bg-slate-200 text-slate-400 font-bold text-xs py-2.5 px-4 rounded-xl cursor-not-allowed border border-slate-300";
                                resendBtn.textContent = `Znovu odeslat e-mail (${remaining}s)`;

                                resendIntervalTimer = setInterval(() => {
                                    const diff = Math.ceil(cooldown - ((Date.now() - lastResendTimestamp) / 1000));
                                    if (diff <= 0) {
                                        clearInterval(resendIntervalTimer);
                                        resendBtn.disabled = false;
                                        resendBtn.className = "w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2.5 px-4 rounded-xl transition border border-slate-300";
                                        resendBtn.textContent = "Znovu odeslat e-mail";
                                    } else {
                                        resendBtn.textContent = `Znovu odeslat e-mail (${diff}s)`;
                                    }
                                }, 1000);
                            } else {
                                resendBtn.disabled = false;
                                resendBtn.className = "w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2.5 px-4 rounded-xl transition border border-slate-300";
                                resendBtn.textContent = "Znovu odeslat e-mail";
                            }
                        }

                        window.resendVerificationOrResetEmail = async function() {
                            const email = document.getElementById('auth-email').value.trim();
                            authErrorMsg.classList.add('hidden');
                            authSuccessMsg.classList.add('hidden');

                            if (!email) {
                                authErrorMsg.textContent = "Zadejte prosím e-mailovou adresu do políčka výše.";
                                authErrorMsg.classList.remove('hidden');
                                return;
                            }

                            const now = Date.now();
                            if ((now - lastResendTimestamp) / 1000 < 30) return;

                            try {
                                if (isPasswordResetMode) {
                                    await auth.sendPasswordResetEmail(email);
                                    lastResendTimestamp = Date.now();
                                    authSuccessMsg.textContent = "Odkaz pro obnovení hesla byl znovu odeslán na " + email;
                                    authSuccessMsg.classList.remove('hidden');
                                } else if (isRegisterMode) {
                                    authErrorMsg.textContent = "Pro opětovné zaslání ověřovacího odkazu se prosím nejdříve pokuste přihlásit s vaším heslem.";
                                    authErrorMsg.classList.remove('hidden');
                                    return;
                                } else {
                                    const userCredential = await auth.signInWithEmailAndPassword(email, document.getElementById('auth-password').value);
                                    if (!userCredential.user.emailVerified) {
                                        await userCredential.user.sendEmailVerification();
                                        lastResendTimestamp = Date.now();
                                        authSuccessMsg.textContent = "Ověřovací e-mail byl úspěšně odeslán znovu.";
                                        authSuccessMsg.classList.remove('hidden');
                                    } else {
                                        authSuccessMsg.textContent = "Tento e-mail je již ověřený, můžete se přihlásit.";
                                        authSuccessMsg.classList.remove('hidden');
                                    }
                                    auth.signOut();
                                }
                                updateResendButtonState();
                            } catch (error) {
                                authErrorMsg.textContent = "Chyba: " + error.message;
                                authErrorMsg.classList.remove('hidden');
                            }
                        };

                        authForm.addEventListener('submit', async (e) => {
                            e.preventDefault();
                            authErrorMsg.classList.add('hidden');
                            authSuccessMsg.classList.add('hidden');

                            const email = document.getElementById('auth-email').value.trim();
                            const password = document.getElementById('auth-password').value;
                            const fullName = document.getElementById('auth-fullname').value.trim();
                            const selectedHomeAirport = document.getElementById('auth-home-airport').value;

                            try {
                                if (isPasswordResetMode) {
                                    if (!email) throw new Error("Zadejte e-mail.");
                                    await auth.sendPasswordResetEmail(email);
                                    lastResendTimestamp = Date.now();
                                    updateResendButtonState();
                                    authSuccessMsg.textContent = "Odkaz pro obnovení hesla byl odeslán na " + email;
                                    authSuccessMsg.classList.remove('hidden');
                                } else if (isRegisterMode) {
                                    if (!fullName) throw new Error("Vyplňte svoje jméno.");
                                    if (!selectedHomeAirport || !Object.prototype.hasOwnProperty.call(airportsList, selectedHomeAirport)) throw new Error('Vyberte domovské letiště.');
                                    const userCredential = await auth.createUserWithEmailAndPassword(email, password);

                                    await userCredential.user.updateProfile({ displayName: fullName });
                                    await userCredential.user.sendEmailVerification();
                                    lastResendTimestamp = Date.now();
                                    updateResendButtonState();

                                    await database.ref('users/' + userCredential.user.uid).set({
                                        email: email,
                                        fullName: fullName,
                                        role: 'guest',
                                        airportId: selectedHomeAirport
                                    });

                                    authSuccessMsg.textContent = "Registrace úspěšná! Na e-mail byl odeslán ověřovací odkaz.";
                                    authSuccessMsg.classList.remove('hidden');
                                    auth.signOut();
                                } else {
                                    const userCredential = await auth.signInWithEmailAndPassword(email, password);
                                    await userCredential.user.reload();

                                    if (!userCredential.user.emailVerified) {
                                        authErrorMsg.textContent = "E-mail nebyl ověřen. Zkontrolujte schránku nebo klikněte na 'Znovu odeslat e-mail'.";
                                        authErrorMsg.classList.remove('hidden');
                                        resendContainer.classList.remove('hidden');
                                        auth.signOut();
                                        return;
                                    }
                                    closeAuthModal();
                                }
                            } catch (error) {
                                authErrorMsg.textContent = "Chyba: " + error.message;
                                authErrorMsg.classList.remove('hidden');
                            }
                        });

                        // ==========================================
                        // 4. SUPERADMIN PANEL
                        // ==========================================
                        window.openSuperAdminModal = function() {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            renderSuperadminUsersList();
                            renderSuperadminAirportsList();
                            superAdminModal.classList.remove('hidden');
                        };

                        window.closeSuperAdminModal = function() { superAdminModal.classList.add('hidden'); };

                        createAirportForm.addEventListener('submit', (e) => {
                            e.preventDefault();
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;

                            const icao = document.getElementById('new-airport-icao').value.trim().toLowerCase();
                            const name = document.getElementById('new-airport-name').value.trim();
                            const rawLogo = document.getElementById('new-airport-logo').value.trim();
                            const logoUrl = rawLogo ? safeImageURL(rawLogo) : '';
                            if (rawLogo && !logoUrl) { alert('Použijte HTTPS odkaz nebo platný PNG obrázek do 256 KB (max. 2048 × 2048 px).'); return; }

                            if (!icao || !name) return;

                            const existingCount = Object.keys(airportsList).length;

                            database.ref(`airports/${icao}`).set({
                                name: name,
                                icao: icao.toUpperCase(),
                                order: existingCount,
                                logoUrl: logoUrl || ""
                            }).then(() => {
                                alert(`Letiště ${name} (${icao.toUpperCase()}) bylo vytvořeno!`);
                                document.getElementById('new-airport-icao').value = '';
                                document.getElementById('new-airport-name').value = '';
                                document.getElementById('new-airport-logo').value = '';
                            }).catch(err => alert("Chyba: " + err.message));
                        });

                        function renderSuperadminAirportsList() {
                            setContent(superadminAirportsList, '');
                            const sorted = getSortedAirportsArray();

                            sorted.forEach((ap, index) => {
                                const row = document.createElement('div');
                                row.className = "flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white p-3 rounded-xl border border-slate-200 text-xs gap-3";
                                setContent(row, html`
                                    <div class="flex items-center space-x-3 w-full sm:w-auto">
                                        <div class="w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                                            ${safeImageURL(ap.logoUrl) ? html`<img src="${safeImageURL(ap.logoUrl)}" class="w-full h-full object-contain">` : html`<i data-lucide="plane" class="w-4 h-4 text-slate-400"></i>`}
                                        </div>
                                        <div>
                                            <div class="flex items-center space-x-2">
                                                <span class="font-mono font-bold bg-purple-100 text-purple-900 px-2 py-0.5 rounded">${ap.icao}</span>
                                                <span class="font-semibold text-slate-800">${ap.name}</span>
                                            </div>
                                            <input type="text" value="${ap.logoUrl || ''}" placeholder="HTTPS odkaz nebo PNG data" data-action-change="updateAirportLogo" data-arg-0="${ap.id}" data-arg-0-type="string" data-arg-1-source="value" class="mt-1 w-full sm:w-64 bg-slate-50 border border-slate-300 rounded px-2 py-1 text-[11px] outline-none focus:ring-1 focus:ring-purple-500" title="URL adresa loga">
                                            <label class="mt-2 inline-flex cursor-pointer text-blue-600 font-bold">
                                                Nahrát PNG
                                                <input type="file" accept="image/png" class="sr-only" data-action-change="uploadAirportLogo" data-arg-0="${ap.id}" data-arg-0-type="string" data-arg-1-source="file">
                                            </label>
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-1 self-end sm:self-center">
                                        <button type="button" data-action-click="moveAirportOrder" data-arg-0="${ap.id}" data-arg-0-type="string" data-arg-1="-1" data-arg-1-type="number" ?disabled=${index === 0} class="p-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-30 rounded-lg text-slate-700 font-bold" title="Posunout nahoru">
                                            <i data-lucide="chevron-up" class="w-4 h-4"></i>
                                        </button>
                                        <button type="button" data-action-click="moveAirportOrder" data-arg-0="${ap.id}" data-arg-0-type="string" data-arg-1="1" data-arg-1-type="number" ?disabled=${index === sorted.length - 1} class="p-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-30 rounded-lg text-slate-700 font-bold" title="Posunout dolů">
                                            <i data-lucide="chevron-down" class="w-4 h-4"></i>
                                        </button>
                                        <button type="button" data-action-click="openDeleteAirportModal" data-arg-0="${ap.id}" data-arg-0-type="string" class="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg ml-2 font-bold" title="Smazat letiště">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </div>
                                `);
                                superadminAirportsList.appendChild(row);
                            });
                            lucide.createIcons();
                        }

                        window.updateAirportLogo = async function(id, newLogoUrl) {
    if (!currentUser?.emailVerified || currentUserData?.role !== 'superadmin') return;
    const raw = String(newLogoUrl || '').trim();
    const logo = raw ? safeImageURL(raw) : '';
    if (raw && !logo) {
        alert('Použijte HTTPS odkaz nebo platný PNG obrázek do 256 KB (max. 2048 × 2048 px).');
        return;
    }
    try {
        await database.ref(`airports/${id}/logoUrl`).set(logo);
    } catch (error) {
        alert('Logo se nepodařilo uložit. Zkontrolujte formát, velikost a oprávnění účtu. ' + error.message);
    }
};
window.uploadAirportLogo = async function(id, file) {
    if (!file || currentUserData?.role !== 'superadmin') return;
    if (file.size > MAX_LOGO_BYTES) { alert('PNG obrázek může mít nejvýše 256 KB.'); return; }
    const value = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Obrázek nelze přečíst.'));
        reader.readAsDataURL(file);
    });
    await updateAirportLogo(id, value);
};

                        window.moveAirportOrder = function(id, direction) {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            const sorted = getSortedAirportsArray();
                            const idx = sorted.findIndex(a => a.id === id);
                            if (idx === -1) return;

                            const targetIdx = idx + direction;
                            if (targetIdx < 0 || targetIdx >= sorted.length) return;

                            const temp = sorted[idx];
                            sorted[idx] = sorted[targetIdx];
                            sorted[targetIdx] = temp;

                            const updates = {};
                            sorted.forEach((item, i) => {
                                updates[`airports/${item.id}/order`] = i;
                            });

                            database.ref().update(updates).then(() => {
                                sorted.forEach((item, i) => {
                                    if (airportsList[item.id]) {
                                        airportsList[item.id].order = i;
                                    }
                                });
                                renderSuperadminAirportsList();
                                renderAirportGrid();
                            }).catch(err => alert("Chyba při změně pořadí: " + err.message));
                        };

                        window.openDeleteAirportModal = function(id) {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            airportToDeleteId = id;
                            currentAirportRandomCode = String(Math.floor(1000 + Math.random() * 9000));
                            document.getElementById('delete-airport-random-code').textContent = currentAirportRandomCode;
                            document.getElementById('delete-airport-confirm-input').value = '';
                            document.getElementById('delete-airport-error-msg').classList.add('hidden');
                            deleteAirportModal.classList.remove('hidden');
                        };

                        window.closeDeleteAirportModal = function() {
                            deleteAirportModal.classList.add('hidden');
                            airportToDeleteId = null;
                        };

                        window.executeDeleteAirport = function() {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            const inputVal = document.getElementById('delete-airport-confirm-input').value.trim();
                            if (inputVal !== currentAirportRandomCode) {
                                document.getElementById('delete-airport-error-msg').classList.remove('hidden');
                                return;
                            }

                            const targetId = airportToDeleteId;
                            deleteAirportCallable({airportId: targetId}).then(() => {
                                alert("Letiště bylo trvale smazáno.");
                                closeDeleteAirportModal();
                                if (currentAirportId === targetId) {
                                    currentAirportId = null;
                                    localStorage.removeItem('startovka_selected_airport');
                                    openAirportSelector();
                                }
                            }).catch(err => alert("Chyba při mazání: " + err.message));
                        };

                        function renderSuperadminUsersList() {
                            setContent(superadminUsersList, '');
                            if (!allUsersMap) { setContent(superadminUsersList, html`<div class="text-xs text-slate-400">Žádní uživatelé.</div>`); return; }

                            Object.keys(allUsersMap).forEach(uid => {
                                const u = allUsersMap[uid];
                                const row = document.createElement('div');
                                row.className = "flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-3 rounded-xl border border-slate-200 text-xs gap-2";

                                let airportsOptionsHtml = Object.keys(airportsList).map(apId =>
                                    html`<option value="${apId}" ?selected=${u.airportId === apId}>${airportsList[apId].icao}</option>`
                                );

                                const currentRole = u.role === 'pilot' ? 'guest' : u.role;

                                setContent(row, html`
                                    <div>
                                        <input type="text" value="${u.fullName || ''}" data-action-change="updateUserFullNameGlobal" data-arg-0="${uid}" data-arg-0-type="string" data-arg-1-source="value" class="bg-white border border-slate-300 font-bold p-1 rounded text-xs outline-none mb-0.5" title="Upravit jméno">
                                        <div class="text-slate-500 text-[11px]">${u.email}</div>
                                    </div>
                                    <div class="flex items-center space-x-2">
                                        <select data-action-change="updateUserAirport" data-arg-0="${uid}" data-arg-0-type="string" data-arg-1-source="value" class="bg-slate-100 border border-slate-300 font-semibold p-1.5 rounded-lg outline-none text-xs">
                                            ${airportsOptionsHtml}
                                        </select>
                                        <select data-action-change="updateUserRoleGlobal" data-arg-0="${uid}" data-arg-0-type="string" data-arg-1-source="value" class="bg-purple-50 border border-purple-300 font-bold p-1.5 rounded-lg outline-none text-xs text-purple-900">
                                            <option value="guest" ?selected=${currentRole === 'guest'}>Host (Guest)</option>
                                            <option value="starter" ?selected=${currentRole === 'starter'}>Startér / Pilot</option>
                                            <option value="admin" ?selected=${currentRole === 'admin'}>Admin Letiště</option>
                                            <option value="superadmin" ?selected=${currentRole === 'superadmin'}>★ SuperAdmin</option>
                                        </select>
                                    </div>
                                `);
                                superadminUsersList.appendChild(row);
                            });
                        }

                        window.updateUserRoleGlobal = function(uid, newRole) {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            database.ref('users/' + uid + '/role').set(newRole)
                                .then(() => alert("Role byla změněna."))
                                .catch(err => alert("Chyba: " + err.message));
                        };

                        window.updateUserFullNameGlobal = function(uid, newName) {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            const trimmed = newName.trim();
                            if (!trimmed) return;
                            database.ref('users/' + uid + '/fullName').set(trimmed)
                                .then(() => alert("Jméno bylo aktualizováno."))
                                .catch(err => alert("Chyba: " + err.message));
                        };

                        window.updateUserAirport = function(uid, newAirportId) {
                            if (!currentUserData || currentUserData.role !== 'superadmin') return;
                            database.ref('users/' + uid + '/airportId').set(newAirportId)
                                .then(() => alert("Domovské letiště bylo změněno."))
                                .catch(err => alert("Chyba: " + err.message));
                        };

                        // ==========================================
                        // 5. SPRÁVA FLOTILY LETIŠTĚ & ČLENŮ (ADMIN)
                        // ==========================================
                        window.openFleetModal = function() {
                            if (!userIsAdminForCurrentAirport()) { alert("Nemáte oprávnění správce pro toto letiště!"); return; }
                            document.getElementById('modal-airport-title').textContent = airportsList[currentAirportId]?.icao || currentAirportId;
                            renderFleetLists();
                            renderAdminUsersList();
                            importUI.renderSource(true);
                            fleetModal.classList.remove('hidden');
                        };

                        window.closeFleetModal = function() { fleetModal.classList.add('hidden'); };

                        function renderFleetLists() {
                            setContent(modalGlidersList, customGliders.length === 0
                                ? html`<div class="text-xs text-slate-400 italic">Žádné větroně.</div>`
                                : customGliders.map((g, i) => html`
                                    <div class="flex justify-between items-center bg-slate-100 p-2 rounded-lg text-xs font-semibold">
                                        <span>${g}</span>
                                        <button data-action-click="removeGlider" data-arg-0="${i}" data-arg-0-type="number" class="text-red-500 hover:text-red-700"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                    </div>`));

                            setContent(modalTowsList, customTows.length === 0
                                ? html`<div class="text-xs text-slate-400 italic">Žádné vlečné.</div>`
                                : customTows.map((t, i) => html`
                                    <div class="flex justify-between items-center bg-amber-50 border border-amber-200 p-2 rounded-lg text-xs font-semibold">
                                        <span>${t}</span>
                                        <button data-action-click="removeTow" data-arg-0="${i}" data-arg-0-type="number" class="text-red-500 hover:text-red-700"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                    </div>`));

                            setContent(modalTowPilotsList, customTowPilots.length === 0
                                ? html`<div class="text-xs text-slate-400 italic">Žádní vlekaři.</div>`
                                : customTowPilots.map((p, i) => html`
                                    <div class="flex justify-between items-center bg-amber-50 border border-amber-200 p-2 rounded-lg text-xs font-semibold">
                                        <span>${p}</span>
                                        <button data-action-click="removeTowPilot" data-arg-0="${i}" data-arg-0-type="number" class="text-red-500 hover:text-red-700"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                    </div>`));

                            lucide.createIcons();
                        }

                        function renderAdminUsersList() {
                            setContent(adminUsersList, '');
                            if (!allUsersMap) { setContent(adminUsersList, html`<div class="text-xs text-slate-400">Žádní členové.</div>`); return; }

                            Object.keys(allUsersMap).forEach(uid => {
                                const u = allUsersMap[uid];
                                if (u.airportId === currentAirportId && ['guest', 'starter'].includes(u.role)) {
                                    const row = document.createElement('div');
                                    row.className = "flex justify-between items-center bg-white p-2.5 rounded-lg border border-slate-200 text-xs gap-2";
                                    const currentRole = u.role === 'pilot' ? 'guest' : u.role;

                                    setContent(row, html`
                                        <div class="flex-grow">
                                            <input type="text" value="${u.fullName || ''}" placeholder="Celé jméno" data-action-change="updateUserFullNameLocal" data-arg-0="${uid}" data-arg-0-type="string" data-arg-1-source="value" class="w-full bg-slate-50 border border-slate-300 font-bold text-slate-900 p-1.5 rounded-lg outline-none text-xs mb-0.5" title="Klikněte pro úpravu jména">
                                            <div class="text-slate-500 text-[10px]">${u.email}</div>
                                        </div>
                                        <select data-action-change="changeUserRoleLocal" data-arg-0="${uid}" data-arg-0-type="string" data-arg-1-source="value" class="bg-slate-100 border border-slate-300 font-semibold p-1.5 rounded-lg outline-none shrink-0">
                                            <option value="guest" ?selected=${currentRole === 'guest'}>Host (Guest)</option>
                                            <option value="starter" ?selected=${currentRole === 'starter'}>Startér / Pilot</option>
                                        </select>
                                    `);
                                    adminUsersList.appendChild(row);
                                }
                            });
                        }

                        window.updateUserFullNameLocal = function(uid, newName) {
                            if (!userIsAdminForCurrentAirport()) return;
                            const trimmed = newName.trim();
                            if (!trimmed) {
                                alert("Jméno nemůže být prázdné.");
                                return;
                            }
                            database.ref('users/' + uid + '/fullName').set(trimmed)
                                .then(() => {
                                    logAction('Změna jména', `Admin upravil jméno uživatele ID ${uid} na "${trimmed}"`);
                                })
                                .catch(err => alert("Chyba při ukládání jména: " + err.message));
                        };

                        window.changeUserRoleLocal = function(uid, newRole) {
                            if (!userIsAdminForCurrentAirport()) return;
                            database.ref('users/' + uid + '/role').set(newRole)
                                .then(() => {
                                    alert("Role byla aktualizována.");
                                    logAction('Změna role', `Změněna role uživatele ID ${uid} na ${newRole}`);
                                })
                                .catch(err => alert("Chyba: " + err.message));
                        };

                        addAircraftForm.addEventListener('submit', (e) => {
                            e.preventDefault();
                            if (!userIsAdminForCurrentAirport()) return;

                            const category = document.getElementById('modal-aircraft-category').value;
                            const name = document.getElementById('modal-aircraft-name').value.trim();
                            if (!name) return;

                            if (category === 'gliders') {
                                if (!customGliders.includes(name)) {
                                    customGliders.push(name);
                                    logAction('Přidání větroně', `Přidán větroň/letadlo: ${name}`);
                                }
                            } else if (category === 'tows') {
                                if (!customTows.includes(name)) {
                                    customTows.push(name);
                                    logAction('Přidání vlečné', `Přidána vlečná: ${name}`);
                                }
                            } else if (category === 'towPilots') {
                                if (!customTowPilots.includes(name)) {
                                    customTowPilots.push(name);
                                    logAction('Přidání vlekaře', `Přidán vlekař: ${name}`);
                                }
                            }

                            document.getElementById('modal-aircraft-name').value = '';
                            saveData();
                            populateAircraftSelects();
                            populateTowPilotSelect();
                            renderFleetLists();
                        });

                        window.removeGlider = function(i) {
                            if (!userIsAdminForCurrentAirport()) return;
                            const removed = customGliders[i];
                            customGliders.splice(i, 1);
                            saveData();
                            populateAircraftSelects();
                            renderFleetLists();
                            logAction('Smazání větroně', `Odebrán větroň: ${removed}`);
                        };

                        window.removeTow = function(i) {
                            if (!userIsAdminForCurrentAirport()) return;
                            const removed = customTows[i];
                            customTows.splice(i, 1);
                            saveData();
                            populateAircraftSelects();
                            renderFleetLists();
                            logAction('Smazání vlečné', `Odebrána vlečná: ${removed}`);
                        };

                        window.removeTowPilot = function(i) {
                            if (!userIsAdminForCurrentAirport()) return;
                            const removed = customTowPilots[i];
                            customTowPilots.splice(i, 1);
                            saveData();
                            populateTowPilotSelect();
                            renderFleetLists();
                            logAction('Smazání vlekaře', `Odebrán vlekař: ${removed}`);
                        };

                        // ==========================================
                        // 6. LOGIKA LETŮ (BACKEND COMPATIBLE)
                        // ==========================================
                        function populateAircraftSelects() {
                            setContent(aircraftSelect, '');
                            customGliders.forEach(g => {
                                const opt = document.createElement('option');
                                opt.value = g;
                                opt.textContent = g;
                                aircraftSelect.appendChild(opt);
                            });

                            setContent(towAircraftSelect, '');
                            customTows.forEach(t => {
                                const opt = document.createElement('option');
                                opt.value = t;
                                opt.textContent = t;
                                towAircraftSelect.appendChild(opt);
                            });
                        }

                        function populateTowPilotSelect() {
                            if (!towPilotSelect) return;
                            const currentVal = towPilotSelect.value || lastTowPilot;
                            setContent(towPilotSelect, '');
                            customTowPilots.forEach(p => {
                                const opt = document.createElement('option');
                                opt.value = p;
                                opt.textContent = p;
                                towPilotSelect.appendChild(opt);
                            });
                            if (currentVal) towPilotSelect.value = currentVal;
                        }

                        launchTypeRadios.forEach(radio => {
                            radio.addEventListener('change', (e) => {
                                if (e.target.value === 'Aerovlek') {
                                    towDetailsSection.classList.remove('hidden');
                                    if (lastTowPilot && towPilotSelect) towPilotSelect.value = lastTowPilot;
                                } else {
                                    towDetailsSection.classList.add('hidden');
                                }
                            });
                        });

                        function getYYYYMMDD(dateObj) {
                            const d = new Date(dateObj);
                            const pad = (n) => String(n).padStart(2, '0');
                            return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
                        }

                        function formatCzechDate(dateStr) {
                            const d = new Date(dateStr);
                            return d.toLocaleDateString('cs-CZ', { timeZone: 'UTC', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                        }

                        function formatTime(dateIso) {
                            if (!dateIso) return '-';
                            const d = new Date(dateIso);
                            return d.toLocaleTimeString('cs-CZ', { timeZone: 'UTC', hour: '2-digit', minute: '2-digit', second: '2-digit' });
                        }

                        function formatTimeInput(dateIso) {
                            if (!dateIso) return '';
                            const d = new Date(dateIso);
                            const pad = (n) => String(n).padStart(2, '0');
                            return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
                        }

                        function createIsoFromTimeString(originalIso, timeStr) {
                            if (!timeStr) return null;
                            const baseDate = originalIso ? new Date(originalIso) : new Date();
                            const parts = timeStr.split(':');
                            const newDate = new Date(Date.UTC(baseDate.getUTCFullYear(), baseDate.getUTCMonth(), baseDate.getUTCDate(), parts[0], parts[1], parts[2] || 0));
                            return newDate.toISOString();
                        }

                        function getDurationFormatted(startTime, endTime = new Date()) {
                            if (!startTime) return '-';
                            const diffMs = new Date(endTime) - new Date(startTime);
                            const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
                            const hrs = Math.floor(totalSecs / 3600);
                            const mins = Math.floor((totalSecs % 3600) / 60);
                            const secs = totalSecs % 60;
                            const pad = (n) => String(n).padStart(2, '0');
                            return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
                        }

                        function getDurationFormattedHHMM(startTime, endTime) {
                            if (!startTime || !endTime) return '-';
                            const diffMs = new Date(endTime) - new Date(startTime);
                            let totalSecs = Math.max(0, Math.floor(diffMs / 1000));

                            const secs = totalSecs % 60;
                            if (secs >= 30) {
                                totalSecs += (60 - secs);
                            } else {
                                totalSecs -= secs;
                            }

                            const totalMins = Math.floor(totalSecs / 60);
                            const hrs = Math.floor(totalMins / 60);
                            const mins = totalMins % 60;
                            const pad = (n) => String(n).padStart(2, '0');
                            return `${pad(hrs)}:${pad(mins)}`;
                        }

                        function getDurationInSeconds(startTime, endTime) {
                            if (!startTime || !endTime) return 0;
                            const diff = new Date(endTime) - new Date(startTime);
                            return Math.max(0, Math.floor(diff / 1000));
                        }

                        function formatSecondsToHHMMSS(totalSecs) {
                            const hrs = Math.floor(totalSecs / 3600);
                            const mins = Math.floor((totalSecs % 3600) / 60);
                            const secs = totalSecs % 60;
                            const pad = (n) => String(n).padStart(2, '0');
                            return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
                        }

                        function recalculateDurations(flight) {
                            if (flight.gliderLandingTime) flight.gliderDuration = getDurationFormattedHHMM(flight.takeoffTime, flight.gliderLandingTime);
                            if (flight.towLandingTime) flight.towDuration = getDurationFormattedHHMM(flight.takeoffTime, flight.towLandingTime);
                        }

                        startForm.addEventListener('submit', async (e) => {
                            e.preventDefault();
                            if (!userHasWritePermissionForCurrentAirport()) {
                                openAuthModal();
                                return;
                            }

                            const aircraft = aircraftSelect.value;
                            const pilot = document.getElementById('pilot-name').value.trim();
                            const copilot = document.getElementById('copilot-name').value.trim();
                            const task = document.getElementById('task-name').value.trim();
                            const launchType = document.querySelector('input[name="launch-type"]:checked').value;

                            if (!aircraft || !pilot) {
                                alert("Vyplňte prosím větroň a jméno pilota!");
                                return;
                            }

                            const towPilotVal = towPilotSelect ? towPilotSelect.value : '';

                            if (launchType === 'Aerovlek' && !towPilotVal) {
                                alert("Pro aerovlek vyberte vlekaře!");
                                if (towPilotSelect) towPilotSelect.focus();
                                return;
                            }

                            if (launchType === 'Aerovlek' && towPilotVal) {
                                lastTowPilot = towPilotVal;
                                
                            }

                            const now = new Date();
                            const flightPayload = {
                                aircraft: aircraft,
                                pilot: pilot,
                                copilot: copilot || '-',
                                task: task || '-',
                                launchType: launchType,
                                takeoffTime: now.toISOString(),
                                towAircraft: launchType === 'Aerovlek' ? towAircraftSelect.value : null,
                                towPilot: launchType === 'Aerovlek' ? towPilotVal : null,
                                towLandingTime: null,
                                towDuration: '-',
                                gliderLandingTime: null,
                                gliderDuration: '-'
                            };

                            const submitBtn = document.getElementById('submit-start-btn');
                            submitBtn.disabled = true;

                            try {
                                await createFlightCallable({
                                    airportId: currentAirportId,
                                    flightData: flightPayload
                                });

                                logAction('Odstartování', `Letadlo ${aircraft}, pilot: ${pilot} (${launchType}), vzlet v ${formatTime(flightPayload.takeoffTime)}`);

                                document.getElementById('pilot-name').value = '';
                                document.getElementById('copilot-name').value = '';
                                document.getElementById('task-name').value = '';
                                if (towPilotSelect) towPilotSelect.value = lastTowPilot;
                            } catch (err) {
                                alert("Chyba při odstartování: " + err.message);
                            } finally {
                                submitBtn.disabled = false;
                            }
                        });

                        window.landTowFlight = async function(id) {
                            if (!userHasWritePermissionForCurrentAirport()) { openAuthModal(); return; }
                            const flight = activeFlights.find(f => f.id === id);
                            if (flight && !flight.towLandingTime) {
                                const landingTimeIso = new Date().toISOString();
                                const durationStr = getDurationFormattedHHMM(flight.takeoffTime, landingTimeIso);

                                try {
                                    await landFlightCallable({
                                        airportId: currentAirportId,
                                        flightId: id,
                                        landingType: 'tow',
                                        landingTime: landingTimeIso,
                                        duration: durationStr
                                    });

                                    logAction('Přistání vlečné', `Přistání vlečné ${flight.towAircraft} v ${formatTime(landingTimeIso)} (let ${flight.aircraft})`);
                                } catch (err) {
                                    alert("Chyba při přistání vlečné: " + err.message);
                                }
                            }
                        };

                        window.landGliderFlight = async function(id) {
                            if (!userHasWritePermissionForCurrentAirport()) { openAuthModal(); return; }
                            const flight = activeFlights.find(f => f.id === id);
                            if (flight && !flight.gliderLandingTime) {
                                const landingTimeIso = new Date().toISOString();
                                const durationStr = getDurationFormattedHHMM(flight.takeoffTime, landingTimeIso);

                                try {
                                    await landFlightCallable({
                                        airportId: currentAirportId,
                                        flightId: id,
                                        landingType: 'glider',
                                        landingTime: landingTimeIso,
                                        duration: durationStr
                                    });

                                    logAction('Přistání větroně', `Přistání větroně ${flight.aircraft} v ${formatTime(landingTimeIso)} (pilot: ${flight.pilot})`);
                                } catch (err) {
                                    alert("Chyba při přistání větroně: " + err.message);
                                }
                            }
                        };

                        function renderTodayView() {
                            renderActiveFlights();
                            renderTodayCompletedFlights();
                        }

                        function renderActiveFlights() {
                            setContent(activeFlightsContainer, '');
                            activeCountBadge.textContent = `${activeFlights.length} ve vzduchu`;

                            if (activeFlights.length === 0) {
                                activeFlightsContainer.appendChild(noActiveFlightsEl);
                                return;
                            }

                            const canWrite = userHasWritePermissionForCurrentAirport();
                            const isAdmin = userIsAdminForCurrentAirport();

                            activeFlights.forEach(flight => {
                                const isAero = flight.launchType === 'Aerovlek';
                                const card = document.createElement('div');
                                card.className = "bg-slate-50 border-2 border-slate-300 p-4 rounded-xl flex flex-col gap-3 shadow-sm";

                                let towHtml = '';
                                if (isAero) {
                                    towHtml = html`
                                        <div class="bg-amber-100/70 border border-amber-300 p-3 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mt-1">
                                            <div>
                                                <div class="text-xs font-bold text-amber-900 uppercase flex items-center gap-1">
                                                    <i data-lucide="plane" class="w-3.5 h-3.5 text-amber-700"></i>
                                                    Vlečná: <span class="text-slate-900">${flight.towAircraft || '-'}</span>
                                                </div>
                                                <div class="text-xs font-semibold text-amber-800">Vlekař: ${flight.towPilot || '-'}</div>
                                            </div>
                                            <div class="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                                                ${flight.towLandingTime ? html`
                                                    <div class="text-right">
                                                        <span class="text-xs font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded">Přistála v ${formatTime(flight.towLandingTime)}</span>
                                                        <div class="text-xs font-mono font-bold text-slate-700">Doba: ${flight.towDuration || '-'}</div>
                                                    </div>
                                                ` : html`
                                                    <div class="text-right">
                                                        <div class="text-[10px] font-bold text-amber-800 uppercase">Čas vlečné</div>
                                                        <div class="font-mono font-bold text-sm text-amber-900 timer" data-start="${flight.takeoffTime}">
                                                            ${getDurationFormatted(flight.takeoffTime)}
                                                        </div>
                                                    </div>
                                                    ${canWrite && !flight.imported ? html`
                                                        <button data-action-click="landTowFlight" data-arg-0="${flight.id}" data-arg-0-type="number" class="btn-touch bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-3 py-2 rounded-lg shadow flex items-center space-x-1 transition">
                                                            <i data-lucide="plane-landing" class="w-4 h-4"></i>
                                                            <span>Přistání vlečné</span>
                                                        </button>
                                                    ` : ``}
                                                `}
                                            </div>
                                        </div>
                                    `;
                                }

                                setContent(card, html`
                                    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                                        <div class="space-y-1">
                                            <div class="flex items-center space-x-2">
                                                <span class="font-black text-lg text-slate-900">${flight.aircraft || '-'}</span>${importUI.badge(flight)}
                                                <span class="text-xs ${isAero ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-blue-100 text-blue-800'} font-bold px-2 py-0.5 rounded">${flight.launchType || '-'}</span>
                                                <button data-action-click="exportSingleFlight" data-arg-0="${flight.id}" data-arg-0-type="number" class="text-slate-400 hover:text-blue-600 p-1" title="Exportovat tento let (CSV)">
                                                    <i data-lucide="download" class="w-4 h-4"></i>
                                                </button>
                                                ${isAdmin ? html`
                                                    <button data-action-click="openEditModal" data-arg-0="${flight.id}" data-arg-0-type="number" class="text-slate-400 hover:text-blue-600 p-1" title="Upravit let">
                                                        <i data-lucide="edit-3" class="w-4 h-4"></i>
                                                    </button>
                                                    <button data-action-click="openDeleteModal" data-arg-0="${flight.id}" data-arg-0-type="number" class="text-slate-400 hover:text-red-600 p-1" title="Smazat let">
                                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                    </button>
                                                ` : ''}
                                            </div>
                                            <div class="text-sm font-semibold text-slate-700">
                                                <span>${flight.pilot || '-'}</span>
                                                ${flight.copilot && flight.copilot !== '-' ? html`<span class="text-slate-500"> / ${flight.copilot}</span>` : ''}
                                            </div>
                                            ${flight.task && flight.task !== '-' ? html`<div class="text-xs font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded inline-block">Úloha: ${flight.task}</div>` : ''}
                                            <div class="text-xs text-slate-500">
                                                Vzlet: <strong class="text-slate-800">${formatTime(flight.takeoffTime)}</strong>
                                                <span class="ml-1 text-[11px] text-slate-400 font-medium">(Odstartoval: ${flight.createdBy || 'Neznámý'})</span>
                                            </div>
                                        </div>

                                        <div class="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                                            ${flight.gliderLandingTime ? html`
                                                <div class="text-right">
                                                    <span class="text-xs font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-lg block">Větroň přistál v ${formatTime(flight.gliderLandingTime)}</span>
                                                    <div class="text-xs font-mono font-bold text-slate-700 mt-1">Doba: ${flight.gliderDuration || '-'}</div>
                                                </div>
                                            ` : html`
                                                <div class="text-right">
                                                    <div class="text-xs font-bold text-slate-400 uppercase">Doba letu větroně</div>
                                                    <div class="font-mono font-black text-xl text-blue-600 timer" data-start="${flight.takeoffTime}">
                                                        ${getDurationFormatted(flight.takeoffTime)}
                                                    </div>
                                                </div>
                                                ${canWrite && !flight.imported ? html`
                                                    <button data-action-click="landGliderFlight" data-arg-0="${flight.id}" data-arg-0-type="number" class="btn-touch bg-red-600 hover:bg-red-500 text-white font-black text-xs sm:text-sm px-4 py-3 rounded-xl shadow-md shadow-red-600/30 flex items-center space-x-1 transition active:bg-red-700">
                                                        <i data-lucide="plane-landing" class="w-5 h-5"></i>
                                                        <span>${isAero ? 'PŘISTÁNÍ VĚTRONĚ' : 'PŘISTÁNÍ'}</span>
                                                    </button>
                                                ` : ``}
                                            `}
                                        </div>
                                    </div>
                                    ${towHtml}
                                `);
                                activeFlightsContainer.appendChild(card);
                            });

                            lucide.createIcons();
                        }

                        function renderTodayCompletedFlights() {
                            setContent(todayTableBody, '');
                            const todayStr = getYYYYMMDD(new Date());
                            const todaysFlights = completedFlights.filter(f => getYYYYMMDD(f.takeoffTime) === todayStr);

                            if (todaysFlights.length === 0) {
                                noTodayCompletedEl.classList.remove('hidden');
                                return;
                            } else {
                                noTodayCompletedEl.classList.add('hidden');
                            }

                            todaysFlights.forEach(flight => {
                                const row = createFlightRow(flight);
                                todayTableBody.appendChild(row);
                            });
                            lucide.createIcons();
                        }

                        function getRegistration(fullAircraftString) {
                            if (!fullAircraftString) return '';
                            return fullAircraftString.replace(/\s*\(.*\)/, '').trim();
                        }

                        function createFlightRow(flight) {
                            const row = document.createElement('tr');
                            row.className = "hover:bg-slate-50 transition border-b border-slate-100 text-slate-800";
                            const isAero = flight.launchType === 'Aerovlek';
                            const isAdmin = userIsAdminForCurrentAirport();

                            setContent(row, html`
                                <td class="p-2.5">
                                    <div class="font-bold text-xs">${getRegistration(flight.aircraft)}</div>${importUI.badge(flight)}
                                    ${isAero ? html`<div class="text-[11px] text-amber-800 font-semibold">Vlečná: ${getRegistration(flight.towAircraft)}</div>` : ''}
                                </td>
                                <td class="p-2.5">
                                    <div class="text-xs font-semibold">${flight.pilot || '-'}${flight.copilot && flight.copilot !== '-' ? ` / ${flight.copilot}` : ''}</div>
                                    ${isAero ? html`<div class="text-[11px] text-amber-800 font-medium">Vlekař: ${flight.towPilot || '-'}</div>` : ''}
                                </td>
                                <td class="p-2.5 text-xs">
                                    <div class="font-semibold text-blue-700">${flight.task || '-'}</div>
                                    <div class="text-[10px] text-slate-500">Start: <strong>${flight.createdBy || 'Neznámý'}</strong></div>
                                    <div class="text-[10px] text-emerald-700">Přistání: <strong>${flight.endedBy || 'Neznámý'}</strong></div>
                                </td>
                                <td class="p-2.5 text-[11px] font-semibold text-slate-600">${flight.launchType || '-'}</td>
                                <td class="p-2.5 font-mono text-xs font-bold">${formatTime(flight.takeoffTime)}</td>
                                <td class="p-2.5 font-mono text-[11px]">
                                    ${isAero ? html`<div>Vlečná: ${formatTime(flight.towLandingTime)}</div>` : ''}
                                    <div>Větroň: ${formatTime(flight.gliderLandingTime)}</div>
                                </td>
                                <td class="p-2.5 font-mono font-bold text-xs">
                                    ${isAero ? html`<div class="text-amber-800">Vlečná: ${flight.towDuration || '-'}</div>` : ''}
                                    <div class="text-blue-600">Větroň: ${flight.gliderDuration || '-'}</div>
                                </td>
                                <td class="p-2.5 text-center">
                                    <div class="flex items-center justify-center space-x-1">
                                        <button data-action-click="exportSingleFlight" data-arg-0="${flight.id}" data-arg-0-type="number" class="text-slate-400 hover:text-blue-600 p-1" title="Exportovat tento let (CSV)">
                                            <i data-lucide="download" class="w-4 h-4"></i>
                                        </button>
                                        ${isAdmin ? html`
                                            <button data-action-click="openEditModal" data-arg-0="${flight.id}" data-arg-0-type="number" class="text-slate-400 hover:text-blue-600 p-1" title="Upravit let">
                                                <i data-lucide="edit-3" class="w-4 h-4"></i>
                                            </button>
                                            <button data-action-click="openDeleteModal" data-arg-0="${flight.id}" data-arg-0-type="number" class="text-slate-400 hover:text-red-600 p-1" title="Smazat let">
                                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                                            </button>
                                        ` : ''}
                                    </div>
                                </td>
                            `);
                            return row;
                        }

                        // ==========================================
                        // 7. HISTORIE & FILTRY & LOGY
                        // ==========================================
                        window.openDeleteModal = function(id) {
                            if (!userIsAdminForCurrentAirport()) return;
                            flightToDeleteId = id;
                            currentRandomCode = String(Math.floor(1000 + Math.random() * 9000));
                            document.getElementById('delete-random-number-display').textContent = currentRandomCode;
                            document.getElementById('delete-confirm-input').value = '';
                            document.getElementById('delete-error-msg').classList.add('hidden');
                            document.getElementById('delete-modal').classList.remove('hidden');
                        };

                        window.closeDeleteModal = function() { document.getElementById('delete-modal').classList.add('hidden'); flightToDeleteId = null; };

                        window.executeDeleteFlight = async function() {
                            if (!userIsAdminForCurrentAirport()) return;
                            const inputVal = document.getElementById('delete-confirm-input').value.trim();
                            if (inputVal !== currentRandomCode) {
                                document.getElementById('delete-error-msg').classList.remove('hidden');
                                return;
                            }

                            const targetFlight = activeFlights.find(f => f.id === flightToDeleteId) || completedFlights.find(f => f.id === flightToDeleteId);

                            try {
                                await deleteFlightCallable({
                                    airportId: currentAirportId,
                                    flightId: flightToDeleteId
                                });

                                if (targetFlight) {
                                    const isAero = targetFlight.launchType === 'Aerovlek';
                                    logAction('Smazání letu', `Smazán let letadla ${targetFlight.aircraft}, pilot: ${targetFlight.pilot} | Vzlet: ${formatTime(targetFlight.takeoffTime)}, Přistání větroně: ${formatTime(targetFlight.gliderLandingTime)}${isAero ? `, Přistání vlečné: ${formatTime(targetFlight.towLandingTime)}` : ''}`);
                                }

                                closeDeleteModal();
                            } catch (err) {
                                alert("Chyba při mazání letu: " + err.message);
                            }
                        };

                        window.openEditModal = function(id) {
                            let flight = activeFlights.find(f => f.id === id) || completedFlights.find(f => f.id === id);
                            if (flight?.imported) { window.openFlightDetails(id); return; }
                            if (!userIsAdminForCurrentAirport()) { openAuthModal(); return; }
                            if (!flight) return;
                            flight = {...flight};

                            document.getElementById('edit-flight-id').value = flight.id;
                            document.getElementById('edit-task-name').value = flight.task && flight.task !== '-' ? flight.task : '';
                            document.getElementById('edit-takeoff-time').value = formatTimeInput(flight.takeoffTime);

                            const towContainer = document.getElementById('edit-tow-landing-container');
                            if (flight.launchType === 'Aerovlek') {
                                towContainer.classList.remove('hidden');
                                document.getElementById('edit-tow-landing-time').value = formatTimeInput(flight.towLandingTime);
                            } else {
                                towContainer.classList.add('hidden');
                            }

                            document.getElementById('edit-glider-landing-time').value = formatTimeInput(flight.gliderLandingTime);
                            editModal.classList.remove('hidden');
                        };

                        window.closeEditModal = function() { editModal.classList.add('hidden'); };

                        editFlightForm.addEventListener('submit', async (e) => {
                            e.preventDefault();
                            if (!userIsAdminForCurrentAirport()) return;

                            const id = Number(document.getElementById('edit-flight-id').value);
                            let flight = activeFlights.find(f => f.id === id) || completedFlights.find(f => f.id === id);
                            if (!flight) return;
                            flight = {...flight};

                            const isCurrentlyActive = activeFlights.some(f => f.id === id);
                            const statusKey = isCurrentlyActive ? 'activeFlights' : 'completedFlights';

                            const oldTakeoff = formatTime(flight.takeoffTime);
                            const oldGliderLand = formatTime(flight.gliderLandingTime);
                            const oldTowLand = flight.launchType === 'Aerovlek' ? formatTime(flight.towLandingTime) : null;

                            const taskStr = document.getElementById('edit-task-name').value.trim();
                            const takeoffStr = document.getElementById('edit-takeoff-time').value;
                            const towLandingStr = document.getElementById('edit-tow-landing-time').value;
                            const gliderLandingStr = document.getElementById('edit-glider-landing-time').value;

                            flight.task = taskStr || '-';
                            if (takeoffStr) flight.takeoffTime = createIsoFromTimeString(flight.takeoffTime, takeoffStr);

                            if (flight.launchType === 'Aerovlek') {
                                if (towLandingStr) flight.towLandingTime = createIsoFromTimeString(flight.towLandingTime || flight.takeoffTime, towLandingStr);
                                else { flight.towLandingTime = null; flight.towDuration = '-'; }
                            }

                            if (gliderLandingStr) flight.gliderLandingTime = createIsoFromTimeString(flight.gliderLandingTime || flight.takeoffTime, gliderLandingStr);
                            else { flight.gliderLandingTime = null; flight.gliderDuration = '-'; }

                            recalculateDurations(flight);

                            const isAero = flight.launchType === 'Aerovlek';
                            const isFinished = isAero ? (Boolean(flight.towLandingTime) && Boolean(flight.gliderLandingTime)) : Boolean(flight.gliderLandingTime);

                            try {
                                await editFlightCallable({airportId: currentAirportId, flightId: id, edits: {
                                    task: flight.task, takeoffTime: flight.takeoffTime,
                                    towLandingTime: flight.towLandingTime || null,
                                    gliderLandingTime: flight.gliderLandingTime || null
                                }});
                            } catch (error) {
                                alert('Úpravu se nepodařilo uložit: ' + error.message);
                                return;
                            }

                            let editDetails = `Upraven let ${flight.aircraft} (pilot: ${flight.pilot}) | Vzlet: ${oldTakeoff} -> ${formatTime(flight.takeoffTime)}, Přistání větroně: ${oldGliderLand} -> ${formatTime(flight.gliderLandingTime)}`;
                            if (isAero) {
                                editDetails += `, Přistání vlečné: ${oldTowLand} -> ${formatTime(flight.towLandingTime)}`;
                            }

                            logAction('Úprava letu', editDetails);
                            closeEditModal();
                        });

                        window.switchTab = function(tabName) {
                            currentTab = tabName;
                            const todayContent = document.getElementById('tab-today-content');
                            const historyContent = document.getElementById('tab-history-content');
                            const logsContent = document.getElementById('tab-logs-content');

                            const todayBtn = document.getElementById('tab-today-btn');
                            const historyBtn = document.getElementById('tab-history-btn');
                            const logsBtn = document.getElementById('tab-logs-btn');

                            todayContent.classList.add('hidden');
                            historyContent.classList.add('hidden');
                            logsContent.classList.add('hidden');

                            todayBtn.className = "btn-touch flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold transition text-slate-400 hover:text-white";
                            historyBtn.className = "btn-touch flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold transition text-slate-400 hover:text-white";
                            logsBtn.className = "btn-touch flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold transition text-slate-400 hover:text-white";

                            if (tabName === 'today') {
                                todayContent.classList.remove('hidden');
                                todayBtn.className = "btn-touch flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold transition bg-blue-600 text-white shadow";
                                renderTodayView();
                            } else if (tabName === 'history') {
                                historyContent.classList.remove('hidden');
                                historyBtn.className = "btn-touch flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold transition bg-blue-600 text-white shadow";
                                populateFilterAircraftOptions();
                                applyHistoryFilters();
                            } else if (tabName === 'logs') {
                                logsContent.classList.remove('hidden');
                                logsBtn.className = "btn-touch flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold transition bg-blue-600 text-white shadow";
                                applyLogFilters();
                            }
                        };

                        window.resetLogFilters = function() {
                            document.getElementById('filter-log-search').value = '';
                            document.getElementById('filter-log-type').value = '';
                            document.getElementById('filter-log-date-from').value = '';
                            document.getElementById('filter-log-date-to').value = '';
                            applyLogFilters();
                        };

                        window.applyLogFilters = function() {
                            const search = document.getElementById('filter-log-search').value.toLowerCase().trim();
                            const typeFilter = document.getElementById('filter-log-type').value;
                            const dateFrom = document.getElementById('filter-log-date-from').value;
                            const dateTo = document.getElementById('filter-log-date-to').value;

                            const filtered = auditLogs.filter(log => {
                                if (search) {
                                    const userStr = (log.user || '').toLowerCase();
                                    const detailsStr = (log.details || '').toLowerCase();
                                    const typeStr = (log.type || '').toLowerCase();
                                    if (!userStr.includes(search) && !detailsStr.includes(search) && !typeStr.includes(search)) return false;
                                }
                                if (typeFilter) {
                                    if (!log.type.toLowerCase().includes(typeFilter.toLowerCase())) return false;
                                }

                                const logDateStr = getYYYYMMDD(log.timestamp);
                                if (dateFrom && logDateStr < dateFrom) return false;
                                if (dateTo && logDateStr > dateTo) return false;

                                return true;
                            });

                            renderAuditLogsTable(filtered);
                        };

                        function renderAuditLogsTable(logsToRender) {
                            const tbody = document.getElementById('logs-table-body');
                            const noMsg = document.getElementById('no-logs-msg');
                            setContent(tbody, '');

                            if (!logsToRender || logsToRender.length === 0) {
                                noMsg.classList.remove('hidden');
                                return;
                            } else {
                                noMsg.classList.add('hidden');
                            }

                            logsToRender.forEach(log => {
                                const row = document.createElement('tr');
                                row.className = "hover:bg-slate-50 transition border-b border-slate-100 text-slate-800 text-xs";

                                let badgeColor = "bg-blue-100 text-blue-800 border-blue-200";
                                if (log.type.includes('Smazání')) badgeColor = "bg-red-100 text-red-800 border-red-200";
                                else if (log.type.includes('Ukončení') || log.type.includes('Přistání')) badgeColor = "bg-emerald-100 text-emerald-800 border-emerald-200";
                                else if (log.type.includes('Úprava')) badgeColor = "bg-amber-100 text-amber-800 border-amber-200";

                                setContent(row, html`
                                    <td class="p-2.5 font-mono text-[11px] text-slate-500">${formatTime(log.timestamp)} <span class="text-[10px] text-slate-400">(${getYYYYMMDD(log.timestamp)})</span></td>
                                    <td class="p-2.5 font-bold text-slate-900">${log.user || 'Neznámý'}</td>
                                    <td class="p-2.5"><span class="px-2 py-0.5 rounded border font-bold text-[11px] ${badgeColor}">${log.type}</span></td>
                                    <td class="p-2.5 font-medium text-slate-700">${log.details || '-'}</td>
                                `);
                                tbody.appendChild(row);
                            });
                            lucide.createIcons();
                        }

                        function populateFilterAircraftOptions() {
                            const select = document.getElementById('filter-aircraft');
                            const currentVal = select.value;
                            setContent(select, html`<option value="">Všechna letadla</option>`);

                            const allAircrafts = new Set();
                            completedFlights.forEach(f => {
                                if (f.aircraft) allAircrafts.add(f.aircraft);
                                if (f.towAircraft) allAircrafts.add(f.towAircraft);
                            });

                            Array.from(allAircrafts).sort().forEach(ac => {
                                const opt = document.createElement('option');
                                opt.value = ac;
                                opt.textContent = ac;
                                select.appendChild(opt);
                            });
                            select.value = currentVal;
                        }

                        window.resetFilters = function() {
                            document.getElementById('filter-search').value = '';
                            document.getElementById('filter-aircraft').value = '';
                            document.getElementById('filter-launch').value = '';
                            document.getElementById('filter-date-from').value = '';
                            document.getElementById('filter-date-to').value = '';
                            applyHistoryFilters();
                        };

                        window.applyHistoryFilters = function() {
                            const search = document.getElementById('filter-search').value.toLowerCase().trim();
                            const aircraft = document.getElementById('filter-aircraft').value;
                            const launch = document.getElementById('filter-launch').value;
                            const dateFrom = document.getElementById('filter-date-from').value;
                            const dateTo = document.getElementById('filter-date-to').value;

                            const filtered = completedFlights.filter(flight => {
                                if (search) {
                                    const p = (flight.pilot || '').toLowerCase();
                                    const cp = (flight.copilot || '').toLowerCase();
                                    const tp = (flight.towPilot || '').toLowerCase();
                                    const t = (flight.task || '').toLowerCase();
                                    const starter = (flight.createdBy || '').toLowerCase();
                                    const ended = (flight.endedBy || '').toLowerCase();
                                    if (!p.includes(search) && !cp.includes(search) && !tp.includes(search) && !t.includes(search) && !starter.includes(search) && !ended.includes(search)) return false;
                                }
                                if (aircraft && flight.aircraft !== aircraft && flight.towAircraft !== aircraft) return false;
                                if (launch && flight.launchType !== launch) return false;

                                const flightDateStr = getYYYYMMDD(flight.takeoffTime);
                                if (dateFrom && flightDateStr < dateFrom) return false;
                                if (dateTo && flightDateStr > dateTo) return false;

                                return true;
                            });

                            renderHistoryDays(filtered);
                        };

                        function renderHistoryDays(flights) {
                            const container = document.getElementById('history-days-container');
                            const noMsg = document.getElementById('no-history-msg');
                            setContent(container, '');

                            if (flights.length === 0) {
                                noMsg.classList.remove('hidden');
                                return;
                            } else {
                                noMsg.classList.add('hidden');
                            }

                            const grouped = {};
                            flights.forEach(f => {
                                const dateKey = getYYYYMMDD(f.takeoffTime);
                                if (!grouped[dateKey]) grouped[dateKey] = [];
                                grouped[dateKey].push(f);
                            });

                            const sortedDates = Object.keys(grouped).sort().reverse();
                            const isAdmin = userIsAdminForCurrentAirport();

                            sortedDates.forEach(dateStr => {
                                const dayFlights = grouped[dateStr];
                                let totalGliderSecs = 0;
                                let totalTowSecs = 0;

                                dayFlights.forEach(f => {
                                    totalGliderSecs += getDurationInSeconds(f.takeoffTime, f.gliderLandingTime);
                                    if (f.towLandingTime) totalTowSecs += getDurationInSeconds(f.takeoffTime, f.towLandingTime);
                                });

                                const dayCard = document.createElement('section');
                                dayCard.className = "bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden";

                                setContent(dayCard, html`
                                    <div class="bg-slate-900 text-white p-4 flex flex-wrap justify-between items-center gap-3">
                                        <div class="flex items-center space-x-2">
                                            <i data-lucide="calendar" class="w-5 h-5 text-blue-400"></i>
                                            <h3 class="font-bold text-sm sm:text-base capitalize">${formatCzechDate(dateStr)}</h3>
                                            <span class="text-xs bg-slate-800 text-slate-300 px-2.5 py-1 rounded-full border border-slate-700 font-bold">${dayFlights.length} letů</span>
                                        </div>
                                        <div class="flex items-center space-x-4 text-xs font-mono">
                                            <div class="text-blue-300">Větroně: <strong class="text-white">${formatSecondsToHHMMSS(totalGliderSecs)}</strong></div>
                                            ${totalTowSecs > 0 ? html`<div class="text-amber-300">Vlečné: <strong class="text-white">${formatSecondsToHHMMSS(totalTowSecs)}</strong></div>` : ''}
                                        </div>
                                    </div>

                                    <div class="p-4 overflow-x-auto">
                                        <table class="w-full text-left text-xs">
                                            <thead class="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200">
                                                <tr>
                                                    <th class="p-2.5">Letadlo / Vlečná</th>
                                                    <th class="p-2.5">Posádka / Vlekař</th>
                                                    <th class="p-2.5">Úloha / Zapsal</th>
                                                    <th class="p-2.5">Start</th>
                                                    <th class="p-2.5">Vzlet</th>
                                                    <th class="p-2.5">Přistání Vlečná / Větroň</th>
                                                    <th class="p-2.5">Doba letu</th>
                                                    <th class="p-2.5 text-center">Akce</th>
                                                </tr>
                                            </thead>
                                            <tbody class="divide-y divide-slate-100">
                                                ${dayFlights.map(f => {
                                                    const isAero = f.launchType === 'Aerovlek';
                                                    return html`
                                                        <tr class="hover:bg-slate-50 transition border-b border-slate-100 text-slate-800">
                                                            <td class="p-2.5">
                                                                <div class="font-bold text-xs">${getRegistration(f.aircraft)}</div>${importUI.badge(f)}
                                                                ${isAero ? html`<div class="text-[11px] text-amber-800 font-semibold">Vlečná: ${getRegistration(f.towAircraft)}</div>` : ''}
                                                            </td>
                                                            <td class="p-2.5">
                                                                <div class="text-xs font-semibold">${f.pilot || '-'}${f.copilot && f.copilot !== '-' ? ` / ${f.copilot}` : ''}</div>
                                                                ${isAero ? html`<div class="text-[11px] text-amber-800 font-medium">Vlekař: ${f.towPilot || '-'}</div>` : ''}
                                                            </td>
                                                            <td class="p-2.5 text-xs">
                                                                <div class="font-semibold text-blue-700">${f.task || '-'}</div>
                                                                <div class="text-[10px] text-slate-500">Start: <strong>${f.createdBy || 'Neznámý'}</strong></div>
                                                                <div class="text-[10px] text-emerald-700">Přistání: <strong>${f.endedBy || 'Neznámý'}</strong></div>
                                                            </td>
                                                            <td class="p-2.5 text-[11px] font-semibold text-slate-600">${f.launchType || '-'}</td>
                                                            <td class="p-2.5 font-mono text-xs font-bold">${formatTime(f.takeoffTime)}</td>
                                                            <td class="p-2.5 font-mono text-[11px]">
                                                                ${isAero ? html`<div>Vlečná: ${formatTime(f.towLandingTime)}</div>` : ''}
                                                                <div>Větroň: ${formatTime(f.gliderLandingTime)}</div>
                                                            </td>
                                                            <td class="p-2.5 font-mono font-bold text-xs">
                                                                ${isAero ? html`<div class="text-amber-800">Vlečná: ${f.towDuration || '-'}</div>` : ''}
                                                                <div class="text-blue-600">Větroň: ${f.gliderDuration || '-'}</div>
                                                            </td>
                                                            <td class="p-2.5 text-center">
                                                                <div class="flex items-center justify-center space-x-1">
                                                                    <button data-action-click="exportSingleFlight" data-arg-0="${f.id}" data-arg-0-type="number" class="text-slate-400 hover:text-blue-600 p-1" title="Exportovat tento let (CSV)">
                                                                        <i data-lucide="download" class="w-4 h-4"></i>
                                                                    </button>
                                                                    ${isAdmin ? html`
                                                                        <button data-action-click="openEditModal" data-arg-0="${f.id}" data-arg-0-type="number" class="text-slate-400 hover:text-blue-600 p-1" title="Upravit let">
                                                                            <i data-lucide="edit-3" class="w-4 h-4"></i>
                                                                        </button>
                                                                        <button data-action-click="openDeleteModal" data-arg-0="${f.id}" data-arg-0-type="number" class="text-slate-400 hover:text-red-600 p-1" title="Smazat let">
                                                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                                        </button>
                                                                    ` : ''}
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    `;
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                `);
                                container.appendChild(dayCard);
                            });

                            lucide.createIcons();
                        }

                        setInterval(() => {
                            document.querySelectorAll('.timer').forEach(timerEl => {
                                const startTime = timerEl.getAttribute('data-start');
                                if (startTime) timerEl.textContent = getDurationFormatted(startTime);
                            });
                        }, 1000);

                        function generateCSV(flightList, filename) {
                            if (flightList.length === 0) { alert('Žádné lety k exportu.'); return; }
                            let csv = "\uFEFF";
                            csv += "Datum;Imatrikulace Vetron;Pilot Vetron;Druhy pilot;Uloha;Zapsal Start;Ukoncil Pristani;Typ startu;Vzlet;Pristani Vetron;Doba letu Vetron;Imatrikulace Vlecne;Vlekar;Pristani Vlecne;Doba letu Vlecne\n";

                            flightList.forEach(f => {
                                const dStr = getYYYYMMDD(f.takeoffTime);
                                const row = [
                                    csvCell(dStr), csvCell(getRegistration(f.aircraft)), csvCell(f.pilot || '-'), csvCell(f.copilot || '-'),
                                    csvCell(f.task || '-'), csvCell(f.createdBy || 'Neznamy'), csvCell(f.endedBy || 'Neznamy'), csvCell(f.launchType || '-'), csvCell(formatTime(f.takeoffTime)),
                                    csvCell(formatTime(f.gliderLandingTime)), csvCell(f.gliderDuration || '-'),
                                    csvCell(getRegistration(f.towAircraft) || '-'), csvCell(f.towPilot || '-'), csvCell(formatTime(f.towLandingTime)),
                                    csvCell(f.towDuration || '-')
                                ].join(";");
                                csv += row + "\n";
                            });

                            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                            const url = URL.createObjectURL(blob);
                            const link = document.createElement("a");
                            link.setAttribute("href", url);
                            link.setAttribute("download", filename);
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            URL.revokeObjectURL(url);
                        }

                        window.exportTodayCSV = function() {
                            const todayStr = getYYYYMMDD(new Date());
                            const todaysFlights = completedFlights.filter(f => getYYYYMMDD(f.takeoffTime) === todayStr);
                            generateCSV(todaysFlights, `startovka_${currentAirportId}_dnesek_${todayStr}.csv`);
                        };

                        window.exportFilteredCSV = function() {
                            const search = document.getElementById('filter-search').value.toLowerCase().trim();
                            const aircraft = document.getElementById('filter-aircraft').value;
                            const launch = document.getElementById('filter-launch').value;
                            const dateFrom = document.getElementById('filter-date-from').value;
                            const dateTo = document.getElementById('filter-date-to').value;

                            const filtered = completedFlights.filter(flight => {
                                if (search) {
                                    const p = (flight.pilot || '').toLowerCase();
                                    const cp = (flight.copilot || '').toLowerCase();
                                    const tp = (flight.towPilot || '').toLowerCase();
                                    const t = (flight.task || '').toLowerCase();
                                    const starter = (flight.createdBy || '').toLowerCase();
                                    const ended = (flight.endedBy || '').toLowerCase();
                                    if (!p.includes(search) && !cp.includes(search) && !tp.includes(search) && !t.includes(search) && !starter.includes(search) && !ended.includes(search)) return false;
                                }
                                if (aircraft && flight.aircraft !== aircraft && flight.towAircraft !== aircraft) return false;
                                if (launch && flight.launchType !== launch) return false;
                                const flightDateStr = getYYYYMMDD(flight.takeoffTime);
                                if (dateFrom && flightDateStr < dateFrom) return false;
                                if (dateTo && flightDateStr > dateTo) return false;
                                return true;
                            });

                            generateCSV(filtered, `startovka_${currentAirportId}_historie.csv`);
                        };

                        window.exportSingleFlight = function(flightId) {
                            let flight = activeFlights.find(f => f.id === flightId) || completedFlights.find(f => f.id === flightId);
                            if (!flight) {
                                alert("Let nebyl nalezen.");
                                return;
                            }
                            const dateStr = getYYYYMMDD(flight.takeoffTime);
                            const reg = getRegistration(flight.aircraft);
                            generateCSV([flight], `startovka_${currentAirportId}_let_${reg}_${dateStr}.csv`);
                        };

                        populateAircraftSelects();
                        populateTowPilotSelect();
                        updateUIForPermissions();
    
function showLoginGate() {
    document.getElementById('app-shell').hidden = true;
    document.getElementById('auth-close-btn').hidden = true;
    document.getElementById('membership-gate').classList.add('hidden');
    airportSelectorModal.classList.add('hidden');
    setContent(document.getElementById('airports-grid'), '');
    authModal.classList.remove('hidden');
}
function showMembershipGate(message = 'Členství čeká na schválení. Požádejte správce svého letiště o přístup.') {
    document.getElementById('app-shell').hidden = true;
    authModal.classList.add('hidden'); airportSelectorModal.classList.add('hidden');
    setContent(document.getElementById('airports-grid'), '');
    document.getElementById('membership-message').textContent = message;
    document.getElementById('membership-gate').classList.remove('hidden');
}
function routeAfterLogin() {
    if (!currentUser?.emailVerified) { showLoginGate(); return; }
    if (!currentUserData) { showMembershipGate(); return; }
    if (!airportsReady) {
        showMembershipGate('Načítám seznam letišť…'); return;
    }
    if (currentAirportId && canReadAirport(currentAirportId) && airportsList[currentAirportId]) return;
    currentAirportId = null; updateCurrentAirportLabel();
    openAirportSelector();
}
function detachCatalog() {
    catalogGeneration++;
    if (catalogSubscription) catalogSubscription.ref.off('value', catalogSubscription.callback);
    catalogSubscription = null; airportsReady = false; airportsList = {};
    setContent(document.getElementById('airports-grid'), '');
}
function startAirportCatalog(epoch) {
    detachCatalog();
    const generation = catalogGeneration;
    const ref = database.ref('airports');
    const callback = snapshot => {
        if (epoch !== authEpoch || generation !== catalogGeneration || !currentUser?.emailVerified) return;
        airportsList = snapshot.val() || {}; airportsReady = true;
        renderAirportGrid(); populateAuthAirportSelect(); updateCurrentAirportLabel();
        if (!superAdminModal.classList.contains('hidden')) renderSuperadminAirportsList();
        if (currentAirportId && !airportsList[currentAirportId]) {
            detachAirportListeners(); clearPrivateData(); currentAirportId = null;
        }
        routeAfterLogin();
    };
    catalogSubscription = {ref, callback};
    ref.on('value', callback, error => {
        if (epoch !== authEpoch || generation !== catalogGeneration) return;
        showMembershipGate('Seznam letišť nelze načíst. Zkuste se přihlásit znovu.');
    });
}
async function loadRegistrationAirports() {
    const epoch = authEpoch;
    try {
        const snapshot = await database.ref('airports').once('value');
        if (epoch !== authEpoch || !isRegisterMode) return;
        airportsList = snapshot.val() || {}; populateAuthAirportSelect();
    } catch (error) {
        if (epoch !== authEpoch) return;
        authErrorMsg.textContent = 'Domovská letiště nelze načíst: ' + error.message;
        authErrorMsg.classList.remove('hidden');
    }
}

function canReadAirport(id) {
    return !!(id && currentUser?.emailVerified && currentUserData && (
        currentUserData.role === 'superadmin' ||
        (currentUserData.airportId === id && ['starter', 'admin'].includes(currentUserData.role))
    ));
}
function detachAirportListeners() {
    airportGeneration++;
    for (const {ref, callback} of airportSubscriptions) ref.off('value', callback);
    airportSubscriptions = [];
}
function privateListen(id, child, callback) {
    if (!canReadAirport(id)) return;
    const generation = airportGeneration;
    const ref = database.ref(`airportData/${id}/${child}`);
    const guarded = snapshot => {
        if (generation === airportGeneration && currentAirportId === id && canReadAirport(id)) callback(snapshot);
    };
    airportSubscriptions.push({ref, callback: guarded});
    ref.on('value', guarded, error => {
        if (generation !== airportGeneration) return;
        detachAirportListeners(); clearPrivateData();
        alert('Provoz není dostupný: ' + error.message);
    });
}
function detachDirectory() {
    if (directorySubscription) directorySubscription.ref.off('value', directorySubscription.callback);
    directorySubscription = null;
    allUsersMap = {};
}
function detachIdentity() {
    detachDirectory();
    detachCatalog();
    if (profileSubscription) profileSubscription.ref.off('value', profileSubscription.callback);
    profileSubscription = null;
}
function subscribeDirectory(epoch) {
    detachDirectory();
    if (!currentUserData) return;
    if (!['admin', 'superadmin'].includes(currentUserData.role)) {
        allUsersMap = {[currentUser.uid]: currentUserData};
        updatePilotsDatalist();
        return;
    }
    const ref = currentUserData.role === 'superadmin' ? database.ref('users') :
        database.ref('users').orderByChild('airportId').equalTo(currentUserData.airportId);
    const callback = snapshot => {
        if (epoch !== authEpoch || directorySubscription?.ref !== ref) return;
        allUsersMap = snapshot.val() || {};
        updatePilotsDatalist();
        if (!fleetModal.classList.contains('hidden')) renderAdminUsersList();
        if (!superAdminModal.classList.contains('hidden')) renderSuperadminUsersList();
    };
    directorySubscription = {ref, callback};
    ref.on('value', callback, error => {
        if (directorySubscription?.ref !== ref) return;
        detachDirectory();
        setContent(adminUsersList, ''); setContent(superadminUsersList, '');
        updatePilotsDatalist();
        alert('Členy nelze načíst: ' + error.message);
    });
}
function clearPrivateData() {
    activeFlights = []; completedFlights = []; auditLogs = []; flightSource = null;
    importUI.clear();
    customGliders = []; customTows = []; customTowPilots = [];
    allUsersMap = {}; lastTowPilot = '';
    flightToDeleteId = null;
    for (const id of ['pilot-name', 'copilot-name', 'task-name', 'filter-search', 'log-search']) {
        const element = document.getElementById(id);
        if (element) element.value = '';
    }
    document.querySelectorAll('#edit-modal input, #fleet-modal input').forEach(element => { element.value = ''; });
    for (const modal of [fleetModal, superAdminModal, editModal, deleteAirportModal, document.getElementById('delete-modal')]) modal.classList.add('hidden');
    for (const element of [adminUsersList, superadminUsersList, modalGlidersList, modalTowsList, modalTowPilotsList]) setContent(element, '');
    updatePilotsDatalist(); populateAircraftSelects(); populateTowPilotSelect();
    populateFilterAircraftOptions(); renderTodayView(); renderHistoryDays([]); renderAuditLogsTable([]);
}

const allowedActions = new Set(["syncFlightSourceNow", "importFlightHTMLFile", "openFlightDetails", "closeFlightDetails", "applyHistoryFilters", "applyLogFilters", "changeUserRoleLocal", "closeAuthModal", "closeDeleteAirportModal", "closeDeleteModal", "closeEditModal", "closeFleetModal", "closeSuperAdminModal", "executeDeleteAirport", "executeDeleteFlight", "exportFilteredCSV", "exportSingleFlight", "exportTodayCSV", "handleAuthButton", "landGliderFlight", "landTowFlight", "moveAirportOrder", "openAirportSelector", "openAuthModal", "openDeleteAirportModal", "openDeleteModal", "openEditModal", "openFleetModal", "openSuperAdminModal", "removeGlider", "removeTow", "removeTowPilot", "resendVerificationOrResetEmail", "resetFilters", "resetLogFilters", "switchTab", "toggleAuthMode", "togglePasswordResetMode", "updateAirportLogo", "uploadAirportLogo", "updateUserAirport", "updateUserFullNameGlobal", "updateUserFullNameLocal", "updateUserRoleGlobal"]);
for (const eventName of ['click', 'change', 'input']) {
    document.addEventListener(eventName, async event => {
        const element = event.target.closest('[data-action-' + eventName + ']');
        if (!element || element.disabled) return;
        const action = element.getAttribute('data-action-' + eventName);
        if (!allowedActions.has(action) || typeof window[action] !== 'function') return;
        const args = [];
        for (let index = 0; index < 5; index++) {
            const key = 'data-arg-' + index;
            if (element.getAttribute(key + '-source') === 'file') { args.push(element.files?.[0]); continue; }
            if (element.getAttribute(key + '-source') === 'value') { args.push(element.value); continue; }
            if (!element.hasAttribute(key)) break;
            const value = element.getAttribute(key);
            if (element.getAttribute(key + '-type') === 'number') {
                const number = Number(value);
                if (!Number.isSafeInteger(number)) { alert('Neplatný identifikátor.'); return; }
                args.push(number);
            } else args.push(value);
        }
        try { await window[action](...args); } catch (error) { alert('Akce se nezdařila: ' + error.message); }
    });
}
