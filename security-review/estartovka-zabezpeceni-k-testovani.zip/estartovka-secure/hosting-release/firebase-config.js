// Public Web app configuration; no service account or private credentials.
window.ESTARTOVKA_CONFIG = {
  "useEmulators": false,
  "firebase": {
    "apiKey": "AIzaSyBJ7aqYbSC1zP87mV9LmCF6IhhNjG1KLss",
    "authDomain": "e-startovka-2.firebaseapp.com",
    "databaseURL": "https://e-startovka-2-default-rtdb.europe-west1.firebasedatabase.app",
    "projectId": "e-startovka-2",
    "storageBucket": "e-startovka-2.firebasestorage.app",
    "messagingSenderId": "95471421411",
    "appId": "1:95471421411:web:e497a6521879587d3202d6",
    "measurementId": "G-MJ1T3VZ3DZ"
  }
};
