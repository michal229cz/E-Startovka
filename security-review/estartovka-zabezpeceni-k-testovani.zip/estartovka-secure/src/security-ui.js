export const MAX_LOGO_BYTES = 256 * 1024;
export const MAX_LOGO_DATA_URL_LENGTH = 22 + Math.ceil(MAX_LOGO_BYTES / 3) * 4;
function isPNGDataURL(value) {
    const prefix = 'data:image/png;base64,';
    if (!value.startsWith(prefix) || value.length > MAX_LOGO_DATA_URL_LENGTH) return false;
    const encoded = value.slice(prefix.length);
    if (!encoded || encoded.length % 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) return false;
    try {
        const bytes = Uint8Array.from(atob(encoded), char => char.charCodeAt(0));
        if (bytes.length < 45 || bytes.length > MAX_LOGO_BYTES) return false;
        const signature = [137, 80, 78, 71, 13, 10, 26, 10];
        if (!signature.every((byte, index) => bytes[index] === byte)) return false;
        if (String.fromCharCode(...bytes.slice(12, 16)) !== 'IHDR') return false;
        const view = new DataView(bytes.buffer);
        const width = view.getUint32(16), height = view.getUint32(20);
        if (!width || !height || width > 2048 || height > 2048) return false;
        const end = [0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130];
        return end.every((byte, index) => bytes[bytes.length - end.length + index] === byte);
    } catch { return false; }
}
export function safeImageURL(value) {
    if (typeof value !== 'string') return '';
    value = value.trim();
    if (value.startsWith('data:')) return isPNGDataURL(value) ? value : '';
    if (value.length > 2048) return '';
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
}
export function csvCell(value) {
    let text = String(value ?? '-');
    if (/^[\s\uFEFF]*[=+@-]/u.test(text) || /^[\t\r\n]/u.test(text)) text = "'" + text;
    return '"' + text.replaceAll('"', '""') + '"';
}
