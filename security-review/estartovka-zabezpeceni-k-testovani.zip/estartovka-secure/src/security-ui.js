export function safeImageURL(value) {
    if (typeof value !== 'string' || value.length > 2048) return '';
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
}
export function csvCell(value) {
    let text = String(value ?? '-');
    // Quoting alone does not prevent spreadsheet formulas from being evaluated.
    if (/^[\s\uFEFF]*[=+@-]/u.test(text) || /^[\t\r\n]/u.test(text)) text = "'" + text;
    return '"' + text.replaceAll('"', '""') + '"';
}
