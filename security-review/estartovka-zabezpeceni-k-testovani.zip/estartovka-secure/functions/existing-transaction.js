'use strict';
/**
 * A first RTDB transaction callback can see a cold local cache (null), even when
 * the server has data. An immediate abort would never consult the server.
 * Submit the unchanged value for a missing record so RTDB can compare hashes
 * and retry with the authoritative state. Report success only if the final
 * committed attempt actually found and changed the requested record.
 */
async function updateExisting(ref, mutate) {
  let changed = false;
  let failure;
  const result = await ref.transaction(current => {
    try {
      const updated = mutate(current);
      changed = updated !== undefined;
      return changed ? updated : current;
    } catch (error) {
      // A retry runs in the SDK's asynchronous listener. Do not throw into that
      // listener: explicitly abort, await completion, then reject the caller.
      failure = error;
      changed = false;
      return undefined;
    }
  });
  if (failure) throw failure;
  return result.committed && changed;
}
module.exports = {updateExisting};
