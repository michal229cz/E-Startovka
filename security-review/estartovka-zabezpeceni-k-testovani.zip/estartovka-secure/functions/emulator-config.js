'use strict';
/**
 * Firebase CLI 15 derives the demo Functions databaseURL from projectId, while
 * its Database Emulator loads default rules into projectId-default-rtdb.
 * The browser and seed already use that default-rtdb namespace. Align Admin SDK
 * only in the isolated demo runtime; real project configuration stays untouched.
 */
function runtimeOptions(env) {
  if (env.FUNCTIONS_EMULATOR !== 'true') return undefined;
  const config = JSON.parse(env.FIREBASE_CONFIG || '{}');
  if (typeof config.projectId !== 'string' || !config.projectId.startsWith('demo-')) return undefined;
  if (!env.FIREBASE_DATABASE_EMULATOR_HOST) {
    throw new Error('Demo Functions require a running local Database Emulator.');
  }
  return {...config, databaseURL: `https://${config.projectId}-default-rtdb.firebaseio.com`};
}
module.exports = {runtimeOptions};
