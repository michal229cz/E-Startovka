# E-Startovka — opravený balíček k integračnímu ověření

Tento balíček navazuje na vaše nahrané index.html, functions/index.js, database.rules.json, firebase.json a functions/package.json. Obsahuje upravený frontend, server, pravidla i sestavené veřejné soubory. Původní repozitář a živý Firebase projekt zůstaly beze změn.

**Stav: lokální testy prošly; integrační ověření Firebase zatím blokuje stažení emulátoru. Do produkce ještě nenasazovat.** Balíček nahrazuje předchozí částečný návrh navrh-zabezpeceni.zip.

## Co je opravené

- Provoz a jména pilotů čtou jen ověření, schválení členové vlastního letiště (starter/admin) a superadmin. Guest znamená čekání na schválení, nikoli přístup k provozu. Veřejný zůstává pouze katalog letišť.
- Uživatel si nemůže měnit vlastní roli ani příslušnost k letišti. Admin spravuje jen guest/starter členy svého letiště; adminy a superadminy spravuje jen superadmin.
- Všechny dynamické HTML šablony vykresluje lokálně sestavená knihovna Lit. Data se vkládají jako text/hodnoty atributů, nikoli jako kód. Inline handlery jsou nahrazené delegovanými událostmi s pevně daným seznamem akcí. Obrázky přijímají pouze HTTPS URL bez vložených přihlašovacích údajů.
- Soukromé listenery vznikají až po ověření členství, při změně letiště se odpojují. Odhlášení nebo odebrání role odstraňuje data i ze skrytých tabulek, formulářů a modalů; opožděné callbacky starých listenerů se ignorují. Jména vlekařů se již neukládají do localStorage.
- Běžný člen nečte celý adresář uživatelů. Admin jej načítá pouze dotazem na vlastní letiště; superadmin má úplný přístup. Našeptávač běžnému členovi nabízí jeho vlastní profil; pro nabídku všech pilotů by bylo potřeba navrhnout oddělený minimalizovaný adresář bez e-mailů.
- Start, přistání, smazání a úprava letu procházejí autorizovanými callable funkcemi. Backend kontroluje ověření e-mailu, letiště, roli, typy a délky vstupů. Klient nemůže určit ID/identitu zapisovatele nebo podvrhnout počáteční stav letu. Časy běžného startu a přistání a délky letu určuje server. Admin může přes samostatný validovaný endpoint opravit chronologicky platné časy.
- Přesun aktivního letu do historie i audit letových operací používají jednu transakci. Audit letových operací se již nezapisuje z prohlížeče. Správa profilů a flotily se řídí pravidly; tyto administrativní změny zatím nemají samostatný serverový audit.
- Smazání letiště je serverové a atomické; nejprve vyžaduje přesunutí všech členů tohoto letiště.
- CSV escapuje uvozovky a neutralizuje hodnoty, které by tabulkový editor mohl vyhodnotit jako vzorce.
- Firebase, Lit, Lucide i Tailwind se servírují lokálně. Hosting dostal CSP bez inline JavaScriptu/unsafe-eval, ochranu proti vložení do rámce, nosniff, omezení refererů a HTTPS hlavičku. Inline CSS zůstává povolené kvůli stávajícím stylům.
- Aktualizované Firebase Admin 14.5.0 a Functions 7.4.0 používají podporované modulární API; Node runtime zůstává 24. Opravený Auth trigger používá v1 API a nepřebírá privilegované role do custom claims. Bezpečnost přístupu se opírá o chráněné profily v RTDB.

## Co je skutečně ověřené

- Instalace z obou lockfilů (`npm ci` a `npm --prefix functions ci`): prošla. Build veřejných souborů: prošel.
- 18 jednotkových testů: prošlo. Obsahují autorizaci callable funkcí, validaci vstupů, změny stavu letů, pravidla serverové editace, oprávnění mazání, CSV a URL. Backendové testy používají izolovanou paměťovou náhradu Firebase, nikoli skutečný emulátor.
- 9 scénářů v Chromium s produkční CSP a simulovaným Firebase: prošlo. Zahrnují XSS v názvu letiště/jménu/úloze, vnořené tabulky historie, odhlášení, opožděné callbacky, guest, schválení/odebrání role, admin adresář, serverovou editaci a superadmina. Nebyly zjištěny JS výjimky, neočekávané dialogy nebo spustitelné HTML atributy.
- Start skutečného sestaveného SDK v Chromium: prošel s produkční CSP, bez JS výjimek a bez požadavků na produkční služby. Backend při této kontrole nebyl dostupný; jde pouze o ověření načtení aplikace.
- Skutečné Firebase Functions exporty se podařilo načíst s nainstalovaným Admin 14.5.0 a Functions 7.4.0 a demo konfigurací. To ověřuje kompatibilitu importů, nikoli vzdálené funkce.
- `npm audit --omit=dev` v kořeni i functions: 0 známých zranitelností. Override @grpc/grpc-js 1.14.6 řeší nahlášenou tranzitivní závislost SDK. Tento výsledek se týká produkčních balíčků a okamžiku kontroly, nikoli absolutní bezpečnosti aplikace.
- 15 integračních testů RTDB pravidel: připraveno, **NEPROBĚHLO**. Server vrací CONNECT 403 při stahování Firebase Database Emulatoru ze storage.googleapis.com. Pravidla proto zatím nemají ověřenou syntaxi a chování ve skutečném RTDB enginu.
- Reálná registrace, ověřovací e-maily, propojení Auth → Rules → Functions, první naplnění demo dat a skutečný souběh transakcí: zatím **NEOVĚŘENO v emulátorech**. Bootstrap skript má ověřenou syntaxi, nebyl spuštěn proti běžícím emulátorům.

## Co udělat nyní v tomto chatu

V nastavení **cloudového prostředí Codex** zkontrolujte a uložte návrh přidávající `storage.googleapis.com`, potom prostředí publikujte. Jde o přístup ke stažení oficiálního testovacího emulátoru; není to publikace webu na Firebase Hosting. Po aplikování změny lze v chatu dokončit integrační testy. Předchozí povolené domény zůstaly zachované.

## Spuštění lokálně

Rozbalte balíček do samostatné složky. Je potřeba Node.js 24 a pro Firebase emulátory Java 21 nebo novější. Build ani běh nevyžadují servisní klíč.

```sh
npm ci
npm --prefix functions ci
npm run build
npm test
npm run test:rules
```

Pro plnou lokální aplikaci spusťte v jednom terminálu:

```sh
npm run emulators
```

Ve druhém terminálu spusťte:

```sh
npm run seed:emulator
```

Seed používá pevně jen demo-estartovka-security a loopback emulátory. Vytvoří dvě testovací letiště a účty demo-superadmin@example.test, demo-admin@example.test, demo-starter@example.test, demo-guest@example.test a demo-other@example.test. Heslo všech těchto **pouze lokálních demo účtů** je `DemoOnly-2026!`. Nezakládejte je v reálném projektu. Veřejnou stránku podává Hosting Emulator na portu 5000.

Volitelné opakování testů Chromium (Python Playwright a Chromium musí být nainstalované; v tomto cloudovém prostředí jsou):

```sh
npm run test:browser
npm run test:startup
```

## Konfigurace projektu

Dodaný firebaseConfig odpovídá původnímu projektu **e-startovka-2**, nikoli prokazatelně oddělenému testovacímu projektu. Uložen je v `firebase-config.live.example.js`. Výchozí `public/firebase-config.js` a `.firebaserc` záměrně používají jen lokální demo emulátory; při spuštění se nesmějí omylem připojit k živým datům.

Až po úspěšném integračním ověření a potvrzení cílového projektu lze pro skutečný Hosting nahradit public/firebase-config.js veřejnou konfigurací cílové webové aplikace a nastavit useEmulators na false. Účinné změny projektu nikdy neprovádějte jen podle názvu složky. Functions získávají projekt a databaseURL ze standardní konfigurace Firebase při nasazení; neobsahují natvrdo zadaný produkční projekt. Analytics se pro funkci aplikace nevyžaduje.

Celý obsah `public/` patří k sobě: samotný index.html už nestačí. Úpravy aplikace dělejte v `src/` a potom spusťte build. Neměňte ručně minifikované public/app.js.

## Před skutečným nasazením

- Zálohovat aktuální databázi, Auth účty, pravidla a původní release. Zkontrolovat existující superadminy/adminy a členství podle důvěryhodného seznamu; nová pravidla neodeberou roli dříve získanou zneužitím. Nezasílejte export osobních dat do chatu.
- U starých profilů s rolí pilot ručně rozhodnout o schválené roli; frontend je už nebude automaticky přepisovat. Ověřit tvar starých záznamů a případná duplicitní ID letů. Nová validace může odhalit staré neplatné časy nebo profily.
- Prvního důvěryhodného superadmina nastavit přes důvěryhodnou správu Firebase, nikoli otevíráním rules. Guest může být schválen pouze adminem vlastního letiště nebo superadminem.
- Ověřit Email/Password Auth, autorizované domény a odesílání ověřovacích e-mailů; tyto živé konzolové konfigurace nebyly měněny ani ověřeny.
- V odděleném testovacím prostředí ověřit registraci, schválení člena, start/přistání/editaci/smazání, souběh, změnu role a odhlášení. Testovat i zamítnuté přímé REST/SDK zápisy. V tuto chvíli je tato fáze zablokovaná dostupností emulátoru v cloudu.
- Teprve potom nasazovat **koordinovaně** rules, functions a celý Hosting na výslovně určený projekt. Nasazení zatím nebylo provedeno ani autorizováno. Pokud existuje onUserCreatedRole jiné generace, ověřit jeho typ a naplánovat migraci triggeru; nenahrazovat jej slepě.
- Podle provozu doplnit monitorování, limity nákladů a App Check. App Check nyní není vynucený a nenahrazuje pravidla oprávnění. Transakce nad celými daty letiště je vhodná pro současný jednoduchý model; při velkém množství historie je potřeba data rozdělit a měřit zatížení.

Balíček je konkrétní oprava k dokončení integrace, nikoli prohlášení, že živý web je již zabezpečený.
