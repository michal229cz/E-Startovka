# E-Startovka — opravená revize v5.2.8

Tento balíček navazuje na vaše nahrané index.html, functions/index.js, database.rules.json, firebase.json a functions/package.json. Obsahuje upravený frontend, server, pravidla i sestavené veřejné soubory. Původní repozitář a živý Firebase projekt zůstaly beze změn.

**Stav: jednotkové testy, pravidla i integrační testy ve skutečných Firebase emulátorech prošly.** Živý projekt nebyl změněn ani ověřen. Před produkčním nasazením je nutná kontrola existujících rolí a konfigurace cílového projektu. Tato revize nahrazuje předchozí balíček.

## Nasazení na Firebase Hosting

Postup s konkrétními příkazy je v **NASAZENI.md**. Příkaz `npm run prepare:hosting` vytvoří samostatnou složku `hosting-release/` pro projekt e-startovka-2 a `firebase.production.json`; běžná místní konfigurace nadále zůstává demo. Hosting, Functions a pravidla se potom nasazují společně explicitním příkazem uvedeným v návodu. V této relaci nic do Firebase nasazeno nebylo.

Modré pozadí přihlášení používá stejnou barvu jako logo (#2563eb); samotný bílý přihlašovací formulář je zachovaný. Příprava vydání i oddělení živé a demo konfigurace byly místně ověřeny dvěma testy.

## Nové v této revizi

- Nejprve se zobrazí původní přihlašovací formulář se stejným vzhledem. Provozní stránka i výběr letiště zůstávají do přihlášení skryté. Při registraci se seznam domovských klubů načte uvnitř formuláře; nejde o vstup do provozu letiště.
- Po přihlášení se zobrazí všechna letiště. Ta, kam účet nesmí, mají zámek, text „Bez oprávnění“ a zakázané tlačítko. Guest vidí celý seznam zamčený do schválení členství. Superadmin má přístup na všechna letiště. Volba letiště zachovává přihlášení; uložená Firebase relace se po obnově použije znovu bez dalšího zadávání hesla.
- Logo nově přijímá HTTPS odkaz nebo PNG data URL. Lze jej také vybrat tlačítkem **Nahrát PNG** ve správě letišť. Limit je 256 KB a klient kontroluje PNG hlavičku, rozměry do 2048 × 2048 px a ukončovací chunk. Pravidla omezují datová loga na PNG prefix, povolené znaky a délku; neumožňují datové SVG/HTML ani větší hodnoty. Oprávnění k úpravě zůstává pouze superadminovi.
- Při aktualizaci metadat letiště se nezavírá správa a nevymaže se rozepsaný let.

## Dřívější oprava chyby 403 v demo prostředí

Předchozí balíček používal ve frontendu a seedu namespace `demo-estartovka-security-default-rtdb`, ale Functions Emulator odvozoval Admin SDK databázi jako `demo-estartovka-security`. Skutečný demo-superadmin proto při startu dostával HTTP 403, přestože rozhraní jeho roli správně zobrazovalo. Chyba byla zopakována se skutečnými Auth/Database/Functions emulátory.

Nový `functions/emulator-config.js` sjednocuje namespace pouze pro izolované demo emulátory. Konfiguraci skutečných projektů ani kontroly oprávnění nemění. Nový `functions/existing-transaction.js` navíc opravuje práci se studenou cache transakcí a správně vrací validační chyby místo timeoutu. `functions/index.js` oba soubory vyžaduje, proto přenášejte celou složku functions, ne jen samotný index.js.

## Co je opravené

- Provoz a jména pilotů čtou jen ověření, schválení členové vlastního letiště (starter/admin) a superadmin. Guest znamená čekání na schválení, nikoli přístup k provozu. Veřejný zůstává pouze katalog letišť.
- Uživatel si nemůže měnit vlastní roli ani příslušnost k letišti. Admin spravuje jen guest/starter členy svého letiště; adminy a superadminy spravuje jen superadmin.
- Všechny dynamické HTML šablony vykresluje lokálně sestavená knihovna Lit. Data se vkládají jako text/hodnoty atributů, nikoli jako kód. Inline handlery jsou nahrazené delegovanými událostmi s pevně daným seznamem akcí. Obrázky přijímají HTTPS URL bez vložených přihlašovacích údajů a omezené PNG data URL.
- Soukromé listenery vznikají až po ověření členství, při změně letiště se odpojují. Odhlášení nebo odebrání role odstraňuje data i ze skrytých tabulek, formulářů a modalů; opožděné callbacky starých listenerů se ignorují. Jména vlekařů se již neukládají do localStorage.
- Běžný člen nečte celý adresář uživatelů. Admin jej načítá pouze dotazem na vlastní letiště; superadmin má úplný přístup. Našeptávač běžnému členovi nabízí jeho vlastní profil; pro nabídku všech pilotů by bylo potřeba navrhnout oddělený minimalizovaný adresář bez e-mailů.
- Start, přistání, smazání a úprava letu procházejí autorizovanými callable funkcemi. Backend kontroluje ověření e-mailu, letiště, roli, typy a délky vstupů. Klient nemůže určit ID/identitu zapisovatele nebo podvrhnout počáteční stav letu. Časy běžného startu a přistání a délky letu určuje server. Admin může přes samostatný validovaný endpoint opravit chronologicky platné časy.
- Přesun aktivního letu do historie i audit letových operací používají jednu transakci. Prázdná místní cache při prvním pokusu transakci předčasně neukončí; neplatné operace se po abortu vrátí jako chyba, bez zablokování SDK callbacku. Audit letových operací se již nezapisuje z prohlížeče. Správa profilů a flotily se řídí pravidly; tyto administrativní změny zatím nemají samostatný serverový audit.
- Smazání letiště je serverové a atomické; nejprve vyžaduje přesunutí všech členů tohoto letiště.
- CSV escapuje uvozovky a neutralizuje hodnoty, které by tabulkový editor mohl vyhodnotit jako vzorce.
- Firebase, Lit, Lucide i Tailwind se servírují lokálně. Hosting dostal CSP bez inline JavaScriptu/unsafe-eval, ochranu proti vložení do rámce, nosniff, omezení refererů a HTTPS hlavičku. Inline CSS zůstává povolené kvůli stávajícím stylům.
- Aktualizované Firebase Admin 14.5.0 a Functions 7.4.0 používají podporované modulární API; Node runtime zůstává 24. Opravený Auth trigger používá v1 API a nepřebírá privilegované role do custom claims. Bezpečnost přístupu se opírá o chráněné profily v RTDB.

## Co je skutečně ověřené

- Instalace z obou lockfilů (`npm ci` a `npm --prefix functions ci`): prošla. Build veřejných souborů: prošel.
- 26 jednotkových testů: prošlo. Obsahují autorizaci callable funkcí, validaci vstupů, změny stavu letů, pravidla serverové editace, oprávnění mazání, CSV a URL. Backendové testy používají izolovanou paměťovou náhradu Firebase, nikoli skutečný emulátor.
- 10 scénářů v Chromium s produkční CSP a simulovaným Firebase: prošlo. Zahrnují úvodní přihlašovací bránu, zamčená letiště, XSS v názvu letiště/jménu/úloze, vnořené tabulky historie, odhlášení, opožděné callbacky, guest, schválení/odebrání role, admin adresář, serverovou editaci, superadmina a PNG upload. Nebyly zjištěny JS výjimky, neočekávané dialogy nebo spustitelné HTML atributy.
- Start skutečného sestaveného SDK v Chromium: prošel s produkční CSP, bez JS výjimek a bez požadavků na produkční služby. Backend při této kontrole nebyl dostupný; jde pouze o ověření načtení aplikace.
- Skutečné Firebase Functions exporty se podařilo načíst s nainstalovaným Admin 14.5.0 a Functions 7.4.0 a demo konfigurací. To ověřuje kompatibilitu importů, nikoli vzdálené funkce.
- `npm audit --omit=dev` v kořeni i functions: 0 známých zranitelností. Override @grpc/grpc-js 1.14.6 řeší nahlášenou tranzitivní závislost SDK. Tento výsledek se týká produkčních balíčků a okamžiku kontroly, nikoli absolutní bezpečnosti aplikace.
- 18 integračních testů RTDB pravidel: **prošlo proti skutečnému Database Emulatoru**. Byly ověřeny i zamítnuté zápisy, pokusy o povýšení role a přístup k cizímu letišti. Varování permission_denied jsou u těchto negativních testů očekávaná.
- Skutečná integrace Auth → Functions → RTDB: **prošla**. Ověřeno odmítnutí neautorizovaného/guest/cizího člena, start demo-superadmina i startera, admin-only mazání, dvě současná přistání, serverová editace, serverový audit a zákaz smazání letiště s přiřazenými členy.
- Skutečný Chromium + Firebase SDK + běžící emulátory: **prošlo**. Přihlášení demo-superadmina přes původní formulář před výběrem letiště, odstartování bez 403, přistání, konkrétní nový let v historii a odstranění dat po odhlášení. Navíc ověřeno skutečné ukládání PNG vložením datové URL i nahráním souboru, zachování rozepsaného formuláře, změna letiště bez nového přihlášení a zamčené cizí letiště u běžného člena. Bez JS výjimek a požadavků na produkci.
- Skutečná registrace přes formulář v emulátoru: **prošla**. Domovské letiště se načetlo do registrace, vznikl profil guest, přihlašovací brána zůstala uzavřená; po simulovaném ověření e-mailu v Auth Emulatoru se nový účet přihlásil do seznamu zamčených letišť. Doručování skutečných ověřovacích e-mailů mimo emulátor, produkční nastavení Auth a nasazení zůstávají mimo tento test.

## Aktualizace předchozí lokální verze

1. Zastavte staré emulátory pomocí Ctrl+C v jejich terminálu.
2. Nový ZIP rozbalte do nové složky. Nejde o aktualizaci živé Firebase databáze; výchozí konfigurace stále používá pouze demo emulátory.
3. V nové složce spusťte `npm ci` a `npm --prefix functions ci`.
4. Spusťte `npm run emulators`. Ve druhém terminálu v téže složce spusťte `npm run seed:emulator`.
5. V prohlížeči znovu otevřete lokální Hosting a obnovte stránku pomocí Ctrl+F5. V záhlaví uvidíte v5.2.8. Přihlaste se demo-superadmin@example.test a zkuste start.

Při cíleném přenosu opravy je nutné nahradit functions/index.js a přidat **oba** soubory functions/emulator-config.js a functions/existing-transaction.js. Ostatní změny balíčku z původní bezpečnostní revize musí být přítomné; spolehlivější je použití nové kompletní složky. Stará demo data ze souborových exportů se automaticky nemažou ani nemigrují.

## Spuštění lokálně

Rozbalte balíček do samostatné složky. Je potřeba Node.js 24 a pro Firebase emulátory Java 21 nebo novější. Build ani běh nevyžadují servisní klíč.

```sh
npm ci
npm --prefix functions ci
npm run build
npm test
npm run test:rules
```

Pro plnou lokální aplikaci spusťte v jednom terminálu:

```sh
npm run emulators
```

Ve druhém terminálu spusťte:

```sh
npm run seed:emulator
```

Seed používá pevně jen demo-estartovka-security a loopback emulátory. Vytvoří dvě testovací letiště a účty demo-superadmin@example.test, demo-admin@example.test, demo-starter@example.test, demo-guest@example.test a demo-other@example.test. Heslo všech těchto **pouze lokálních demo účtů** je `DemoOnly-2026!`. Nezakládejte je v reálném projektu. Veřejnou stránku podává Hosting Emulator na portu 5000.

Při běžících emulátorech a po seedu lze zopakovat skutečnou integraci:

```sh
npm run test:integration
npm run test:browser:emulator
```

Testy používají pouze loopback adresy a demo projekt, nevytvářejí záznamy v produkci.

Volitelné opakování testů Chromium (Python Playwright a Chromium musí být nainstalované; v tomto cloudovém prostředí jsou):

```sh
npm run test:browser
npm run test:startup
```

## Konfigurace projektu

Dodaný firebaseConfig odpovídá původnímu projektu **e-startovka-2**, nikoli prokazatelně oddělenému testovacímu projektu. Uložen je v `firebase-config.live.example.js`. Výchozí `public/firebase-config.js` a `.firebaserc` záměrně používají jen lokální demo emulátory; při spuštění se nesmějí omylem připojit k živým datům.

Pro skutečný Hosting použijte `npm run prepare:hosting` a postup v NASAZENI.md. Příkaz vytvoří oddělené veřejné soubory s vypnutými emulátory; místní public/firebase-config.js ponechá beze změn. Účinné změny projektu nikdy neprovádějte jen podle názvu složky. Functions získávají projekt a databaseURL ze standardní konfigurace Firebase při nasazení; neobsahují natvrdo zadaný produkční projekt. Pouze v izolovaném demo emulátoru helper sjednocuje namespace s frontendem a seedem. Analytics se pro funkci aplikace nevyžaduje.

Celý obsah `public/` patří k sobě: samotný index.html už nestačí. Úpravy aplikace dělejte v `src/` a potom spusťte build. Neměňte ručně minifikované public/app.js.

## Před skutečným nasazením

- Zálohovat aktuální databázi, Auth účty, pravidla a původní release. Zkontrolovat existující superadminy/adminy a členství podle důvěryhodného seznamu; nová pravidla neodeberou roli dříve získanou zneužitím. Nezasílejte export osobních dat do chatu.
- U starých profilů s rolí pilot ručně rozhodnout o schválené roli; frontend je už nebude automaticky přepisovat. Ověřit tvar starých záznamů a případná duplicitní ID letů. Nová validace může odhalit staré neplatné časy nebo profily.
- Prvního důvěryhodného superadmina nastavit přes důvěryhodnou správu Firebase, nikoli otevíráním rules. Guest může být schválen pouze adminem vlastního letiště nebo superadminem.
- Ověřit Email/Password Auth, autorizované domény a odesílání ověřovacích e-mailů; tyto živé konzolové konfigurace nebyly měněny ani ověřeny.
- V odděleném testovacím prostředí ověřit registraci, schválení člena, start/přistání/editaci/smazání, souběh, změnu role a odhlášení. Testovat i zamítnuté přímé REST/SDK zápisy. Základní emulátorové testy této revize prošly; ověření skutečného cílového prostředí a jeho starých dat je stále nutné.
- Teprve potom nasazovat **koordinovaně** rules, functions a celý Hosting na výslovně určený projekt. Nasazení zatím nebylo provedeno ani autorizováno. Pokud existuje onUserCreatedRole jiné generace, ověřit jeho typ a naplánovat migraci triggeru; nenahrazovat jej slepě.
- Podle provozu doplnit monitorování, limity nákladů a App Check. App Check nyní není vynucený a nenahrazuje pravidla oprávnění. Transakce nad celými daty letiště je vhodná pro současný jednoduchý model; při velkém množství historie je potřeba data rozdělit a měřit zatížení.

Balíček prošel popsanými emulátorovými testy. Tento výsledek není prohlášení, že živý web je již aktualizovaný nebo zabezpečený.
