// Default: local emulators only. This configuration contains no private credentials.
// For a reviewed real deployment set useEmulators=false and replace firebase with
// the target project's public Web app configuration. Never put service account keys here.
window.ESTARTOVKA_CONFIG = Object.freeze({
  useEmulators: true,
  firebase: {
    apiKey: 'demo-api-key', projectId: 'demo-estartovka-security',
    authDomain: 'demo-estartovka-security.firebaseapp.com',
    databaseURL: 'https://demo-estartovka-security-default-rtdb.firebaseio.com',
    appId: '1:000000000000:web:0000000000000000000000'
  }
});
