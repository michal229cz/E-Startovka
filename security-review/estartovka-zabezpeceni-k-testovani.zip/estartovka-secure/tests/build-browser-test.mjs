import {build} from 'esbuild';
import {resolve} from 'node:path';
await build({entryPoints:['src/app.js'],bundle:true,format:'iife',outfile:'tests/app-mock.js',plugins:[{name:'mock-firebase',setup(build){build.onResolve({filter:/^firebase\/compat\//},args=>({path:resolve('tests/firebase-mock.js')}));}}]});
