"""Real Auth + Database + Functions integration. Loopback demo project only."""
import concurrent.futures,datetime,json,urllib.request,urllib.error
PROJECT='demo-estartovka-security'
BASE='http://127.0.0.1'
def request(url,data=None,token=None,method=None):
 assert url.startswith(BASE+':'), 'Only local emulators are permitted'
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request(url,data=None if data is None else json.dumps(data).encode(),headers=headers,method=method)
 try:
  with urllib.request.urlopen(req,timeout=60) as response:return response.status,json.load(response)
 except urllib.error.HTTPError as error:return error.code,json.loads(error.read())
def sign_in(name):
 status,result=request(BASE+':9099/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=demo-api-key',{'email':'demo-'+name+'@example.test','password':'DemoOnly-2026!','returnSecureToken':True})
 assert status==200,(name,status)
 return result['idToken']
def call(name,data,token=None):return request(BASE+':5001/'+PROJECT+'/europe-west1/'+name,{'data':data},token)
def state(path=''):
 status,result=request(BASE+':9000/'+path+'.json?ns='+PROJECT+'-default-rtdb',token='owner')
 assert status==200,status
 return result
FLIGHT={'aircraft':'OK-TEST','pilot':'Demo pilot','launchType':'Naviják'}
def success(name,data,token):
 status,result=call(name,data,token)
 assert status==200,(name,status,result)
 return result['result']
def denied(name,data,token=None):
 status,result=call(name,data,token)
 assert status in (401,403),(name,status,result)
 return result

def main():
 superadmin,admin,starter,guest,other=[sign_in(role) for role in ['superadmin','admin','starter','guest','other']]
 payload={'airportId':'lkst','flightData':FLIGHT}
 denied('createFlight',payload)
 for token in [guest,other]:denied('createFlight',payload,token)
 print('PASS unauthorized, guest and foreign airport creation denied')
 created=success('createFlight',payload,superadmin)
 flight_id=created['id']
 active=state('airportData/lkst/activeFlights')
 assert any(f['id']==flight_id and f['createdBy']=='demo-superadmin' for f in active.values())
 print('PASS screenshot regression: real demo-superadmin creates flight in the same database')
 created2=success('createFlight',payload,starter)
 denied('deleteFlight',{'airportId':'lkst','flightId':created2['id']},starter)
 success('deleteFlight',{'airportId':'lkst','flightId':created2['id']},admin)
 print('PASS starter creation and admin-only deletion')
 # Simultaneous real Functions invocations, persisted through real RTDB transactions.
 aero=success('createFlight',{'airportId':'lkst','flightData':{**FLIGHT,'launchType':'Aerovlek','towAircraft':'OK-TOW','towPilot':'Demo tow'}},starter)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  results=list(pool.map(lambda kind:success('landFlight',{'airportId':'lkst','flightId':aero['id'],'landingType':kind},starter),['tow','glider']))
 assert all(r['success'] for r in results)
 completed=state('airportData/lkst/completedFlights') or {}
 matches=[f for f in completed.values() if f['id']==aero['id']]
 assert len(matches)==1 and matches[0]['towLandingTime'] and matches[0]['gliderLandingTime']
 assert not any(f['id']==aero['id'] for f in (state('airportData/lkst/activeFlights') or {}).values())
 print('PASS concurrent real tow/glider landing completes exactly once and preserves both times')
 old=matches[0]
 edit={'airportId':'lkst','flightId':aero['id'],'edits':{'task':'Correction','takeoffTime':old['takeoffTime'],'towLandingTime':None,'gliderLandingTime':None}}
 denied('editFlight',edit,starter)
 success('editFlight',edit,admin)
 assert any(f['id']==aero['id'] and f['task']=='Correction' for f in state('airportData/lkst/activeFlights').values())
 print('PASS admin edit can reopen flight through validated server endpoint')
 invalid={**edit,'edits':{**edit['edits'],'createdBy':'spoofed'}}
 status,result=call('editFlight',invalid,admin)
 assert status==400,(status,result)
 print('PASS unknown edit fields rejected')
 logs=state('airportData/lkst/auditLogs') or {}
 assert any(log.get('flightId')==flight_id for log in logs.values())
 print('PASS server audit persisted with flight identifiers')
 status,result=call('deleteAirport',{'airportId':'lkst'},superadmin)
 assert status==400 and result['error']['status']=='FAILED_PRECONDITION',(status,result)
 print('PASS airport with assigned members cannot be deleted')
 print('All real emulator integration scenarios passed; no production service contacted.')
if __name__=='__main__':main()
