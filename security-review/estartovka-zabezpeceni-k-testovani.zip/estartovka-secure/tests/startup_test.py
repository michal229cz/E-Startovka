# Smoke test of the actual bundled SDK, without a live backend or production access.
import asyncio,functools,threading
from urllib.parse import urlparse
from http.server import ThreadingHTTPServer
from playwright.async_api import async_playwright
from browser_test import ROOT,Handler
async def main():
 server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'public')))
 threading.Thread(target=server.serve_forever,daemon=True).start()
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium')
  page=await browser.new_page()
  errors=[];external=[]
  page.on('pageerror',lambda error:errors.append(str(error)))
  async def route(request):
   if urlparse(request.request.url).hostname!='127.0.0.1':
    external.append(request.request.url.split('?')[0]);await request.abort()
   else:await request.continue_()
  await page.route('**/*',route)
  response=await page.goto(f'http://127.0.0.1:{server.server_port}',wait_until='load')
  await page.wait_for_timeout(1000)
  assert response.status==200
  assert await page.title()=='E-Startovka - Multi-Airport Letištní Provoz'
  assert await page.locator('#header-logo-container svg').count()==1
  assert not errors,errors
  assert not external,external
  print('PASS actual SDK bundle initializes under CSP, icons render, no JS exceptions or production requests; backend availability not tested')
  await browser.close()
 server.shutdown()
asyncio.run(main())
