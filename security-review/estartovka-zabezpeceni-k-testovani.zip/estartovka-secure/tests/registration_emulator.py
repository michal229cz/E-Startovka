"""Actual signup UI and verified-guest gate; local demo emulators only."""
import asyncio,time
from urllib.parse import urlparse
from playwright.async_api import async_playwright
from integration_emulator import request,state,BASE
async def main():
 email='demo-registration-'+str(time.time_ns())+'@example.test'
 name='Registration test'
 password='DemoOnly-2026!'
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium')
  page=await browser.new_page()
  errors=[];dialogs=[];external=[]
  page.on('pageerror',lambda error:errors.append(str(error)))
  page.on('dialog',lambda dialog:(dialogs.append(dialog.message),asyncio.create_task(dialog.dismiss())))
  async def route(request):
   if urlparse(request.request.url).hostname!='127.0.0.1':external.append(request.request.url.split('?')[0]);await request.abort()
   else:await request.continue_()
  await page.route('**/*',route)
  await page.goto(BASE+':5000',wait_until='load')
  await page.locator('#auth-toggle-mode-btn').click()
  await page.wait_for_function('() => document.getElementById("auth-home-airport").options.length===2')
  await page.locator('#auth-fullname').fill(name)
  await page.locator('#auth-email').fill(email)
  await page.locator('#auth-password').fill(password)
  await page.locator('#auth-home-airport').select_option('lkst')
  await page.locator('#auth-submit-btn').click()
  await page.wait_for_function('() => !document.getElementById("auth-success-msg").classList.contains("hidden") && document.getElementById("auth-success-msg").textContent.includes("Registrace úspěšná")')
  assert await page.locator('#auth-error-msg').is_hidden()
  assert await page.locator('#airport-selector-modal').is_hidden()
  assert await page.locator('#app-shell').is_hidden()
  print('PASS actual signup: home club loads inside registration form; guest profile created without opening airports')
  status,login=request(BASE+':9099/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=demo-api-key',{'email':email,'password':password,'returnSecureToken':True})
  assert status==200,status
  profile=state('users/'+login['localId'])
  assert profile['role']=='guest' and profile['airportId']=='lkst' and profile['fullName']==name
  # Emulate verification locally; no real email service is contacted.
  status,result=request(BASE+':9099/identitytoolkit.googleapis.com/v1/accounts:update?key=demo-api-key',{'localId':login['localId'],'emailVerified':True},token='owner')
  assert status==200,status
  await page.locator('#auth-toggle-mode-btn').click()
  await page.locator('#auth-email').fill(email)
  await page.locator('#auth-password').fill(password)
  await page.locator('#auth-submit-btn').click()
  await page.wait_for_function('() => document.querySelectorAll("#airports-grid button:disabled").length===2')
  assert await page.locator('#app-shell').is_hidden()
  assert await page.locator('#auth-modal').is_hidden()
  assert not errors,errors
  assert not dialogs,dialogs
  assert not external,external
  print('PASS verified guest: same login form leads to all airports locked until membership approval')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
