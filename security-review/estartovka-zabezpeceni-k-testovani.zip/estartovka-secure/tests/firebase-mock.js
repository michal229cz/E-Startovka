const subscriptions = [], writes = [], calls = [], errors = [], reads = [];
const payload = '<img src=x onerror="window.__xss=true">';
let authCallback = null, signedIn = null;
const fixture = {
  airports: {lkst: {name: 'Airport ' + payload, icao:'LKST', logoUrl:'javascript:window.__xss=true'},other:{name:'Other',icao:'OTHER'}},
  users: {starter: {fullName:'Pilot '+payload,email:'pilot@example.test',role:'starter',airportId:'lkst'},admin:{fullName:'Admin',email:'admin@example.test',role:'admin',airportId:'lkst'},guest:{fullName:'Guest',email:'guest@example.test',role:'guest',airportId:'lkst'},superadmin:{fullName:'Super',email:'super@example.test',role:'superadmin',airportId:'lkst'},other:{fullName:'Other secret',email:'other@example.test',role:'starter',airportId:'other'}},
  airportData: {lkst:{activeFlights:{one:{id:101,aircraft:'OK-X',pilot:'Pilot '+payload,copilot:"O'Neil",task:payload,launchType:'Naviják',takeoffTime:new Date().toISOString(),gliderDuration:'-'}},completedFlights:{one:{id:102,aircraft:'OK-C',pilot:'Completed '+payload,task:'task '+payload,launchType:'Naviják',takeoffTime:new Date(Date.now()-60000).toISOString(),gliderLandingTime:new Date().toISOString(),gliderDuration:'00:01'}},auditLogs:{one:{type:'Odstartování '+payload,user:'User '+payload,details:'Details '+payload,timestamp:new Date().toISOString()}},customGliders:['OK-X',payload],customTows:['OK-T'],customTowPilots:['Tow '+payload]},other:{activeFlights:{one:{id:103,aircraft:'OTHER',pilot:'Other airport private',launchType:'Naviják',takeoffTime:new Date().toISOString()}}}}
};
function valueAt(path){return path.split('/').filter(Boolean).reduce((value,key)=>value?.[key],fixture) ?? null;}
function snapshot(ref){let val=valueAt(ref.path);if(ref.queryAirport)val=Object.fromEntries(Object.entries(val || {}).filter(([,v])=>v.airportId===ref.queryAirport));return {val:()=>structuredClone(val),exists:()=>val!==null};}
function emit(path){for(const subscription of subscriptions)if(subscription.active && (subscription.ref.path===path || path.startsWith(subscription.ref.path+'/')))subscription.callback(snapshot(subscription.ref));}
function ref(path='') {return {
 path,queryAirport:null,
 on(event,callback){const sub={ref:this,callback,active:true};subscriptions.push(sub);setTimeout(()=>{if(sub.active)callback(snapshot(this))},0);},
 off(event,callback){for(const sub of subscriptions)if(sub.ref===this && (!callback || sub.callback===callback))sub.active=false;},
 once(){reads.push(this.path);return Promise.resolve(snapshot(this));},
 orderByChild(){return this;},equalTo(value){this.queryAirport=value;return this;},
 set(value){writes.push({path:this.path,value});const keys=this.path.split('/'),last=keys.pop();let node=fixture;for(const key of keys)node=node[key]??={};node[last]=value;emit(this.path);return Promise.resolve();},
 update(value){writes.push({path:this.path,value});return Promise.resolve();},
 remove(){writes.push({path:this.path,value:null});return Promise.resolve();}
};}
const auth={useEmulator(){},onAuthStateChanged(callback){authCallback=callback;queueMicrotask(()=>callback(null));},signOut(){signedIn=null;auth.currentUser=null;authCallback(null);return Promise.resolve();}};
const functions={useEmulator(){},httpsCallable:name=>async data=>{calls.push({name,data});return {data:{success:true}};}};
const database={ref,useEmulator(){}};
const firebase={initializeApp(){},database:()=>database,auth:()=>auth,app:()=>({functions:()=>functions})};
window.__mock={subscriptions,writes,calls,fixture,payload,errors,reads,emit,
 login(uid,verified=true){signedIn={uid,email:uid+'@example.test',emailVerified:verified,reload:async()=>{},getIdToken:async()=>{},displayName:uid};auth.currentUser=signedIn;return authCallback(signedIn);},
 logout:()=>auth.signOut(),
 profile(uid,changes){Object.assign(fixture.users[uid],changes);emit('users/'+uid);},
 stale(){for(const sub of subscriptions)if(sub.ref.path.startsWith('airportData/lkst'))sub.callback(snapshot(sub.ref));}
};
export default firebase;
