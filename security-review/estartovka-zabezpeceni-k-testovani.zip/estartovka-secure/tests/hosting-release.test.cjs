const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
function settings(file){const context={window:{}};vm.runInNewContext(fs.readFileSync(file,'utf8'),context);return context.window.ESTARTOVKA_CONFIG;}
test('prepared Hosting release uses the reviewed real project and leaves local config isolated',()=>{
 const local=settings('public/firebase-config.js'),production=settings('hosting-release/firebase-config.js');
 assert.equal(local.useEmulators,true);assert.equal(local.firebase.projectId,'demo-estartovka-security');
 assert.equal(production.useEmulators,false);assert.equal(production.firebase.projectId,'e-startovka-2');
 assert.equal(JSON.parse(fs.readFileSync('.firebaserc','utf8')).projects.default,'demo-estartovka-security');
});
test('production deployment config selects all components and removes emulator endpoints from CSP',()=>{
 const c=JSON.parse(fs.readFileSync('firebase.production.json','utf8'));
 assert.equal(c.hosting.public,'hosting-release');assert.equal(c.database.rules,'database.rules.json');assert.equal(c.functions[0].source,'functions');assert.equal(c.emulators,undefined);
 const csp=c.hosting.headers.flatMap(entry=>entry.headers).find(header=>header.key==='Content-Security-Policy').value;
 assert.ok(!csp.includes('127.0.0.1') && !csp.includes('localhost'));
 assert.ok(csp.includes("script-src 'self'"));
 for(const name of ['index.html','app.js','styles.css'])assert.equal(fs.readFileSync('hosting-release/'+name).compare(fs.readFileSync('public/'+name)),0);
});
