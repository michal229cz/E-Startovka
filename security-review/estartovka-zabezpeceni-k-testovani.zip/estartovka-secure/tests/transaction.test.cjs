const {test}=require('node:test');const assert=require('node:assert/strict');
const {updateExisting}=require('../functions/existing-transaction');
test('cold transaction cache triggers a server comparison instead of aborting',async()=>{
 let updated;
 const ref={transaction:async callback=>{
   assert.equal(callback(null),null,'Unknown local state must not abort');
   updated=callback({record:{id:1}});return {committed:true};
 }};
 const changed=await updateExisting(ref,state=>{if(!state?.record)return;state.record.updated=true;return state;});
 assert.equal(changed,true);assert.equal(updated.record.updated,true);
});
test('missing records do not report successful modification after a no-op commit',async()=>{
 const ref={transaction:async callback=>{assert.equal(callback(null),null);return {committed:true};}};
 assert.equal(await updateExisting(ref,state=>{if(!state)return;return state;}),false);
});
test('a server retry can revoke an earlier tentative match safely',async()=>{
 const ref={transaction:async callback=>{callback({record:{id:1}});assert.deepEqual(callback({record:null}),{record:null});return {committed:true};}};
 assert.equal(await updateExisting(ref,state=>{if(!state?.record)return;state.record=null;return state;}),false);
});

test('validation errors abort the transaction and reject after SDK completion',async()=>{
 const expected=new Error('invalid state');
 const ref={transaction:async callback=>{
   assert.equal(callback(null),null);
   assert.doesNotThrow(()=>assert.equal(callback({record:{id:1}}),undefined));
   return {committed:false};
 }};
 await assert.rejects(updateExisting(ref,state=>{if(!state)return;throw expected;}),error=>error===expected);
});
