const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const {runtimeOptions}=require('../functions/emulator-config');
const browser={window:{}};
vm.runInNewContext(fs.readFileSync(__dirname+'/../public/firebase-config.js','utf8'),browser);
const config=browser.window.ESTARTOVKA_CONFIG;
test('demo Admin SDK uses exactly the same namespace as the browser',()=>{
 const options=runtimeOptions({FUNCTIONS_EMULATOR:'true',FIREBASE_DATABASE_EMULATOR_HOST:'127.0.0.1:9000',FIREBASE_CONFIG:JSON.stringify({projectId:config.firebase.projectId,databaseURL:'http://127.0.0.1:9000/?ns='+config.firebase.projectId})});
 assert.equal(options.databaseURL,config.firebase.databaseURL);
 assert.equal(options.projectId,config.firebase.projectId);
});
test('production and non-demo runtime configuration remain unchanged',()=>{
 assert.equal(runtimeOptions({}),undefined);
 assert.equal(runtimeOptions({FIREBASE_CONFIG:'invalid JSON ignored outside emulator'}),undefined);
 assert.equal(runtimeOptions({FUNCTIONS_EMULATOR:'true',FIREBASE_CONFIG:JSON.stringify({projectId:'e-startovka-2',databaseURL:'https://e-startovka-2-default-rtdb.europe-west1.firebasedatabase.app'})}),undefined);
});
test('demo runtime fails closed without Database Emulator',()=>{
 assert.throws(()=>runtimeOptions({FUNCTIONS_EMULATOR:'true',FIREBASE_CONFIG:JSON.stringify({projectId:'demo-estartovka-security'})}),/Database Emulator/);
});
