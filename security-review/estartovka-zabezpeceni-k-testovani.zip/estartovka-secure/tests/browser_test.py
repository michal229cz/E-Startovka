import asyncio,json,threading,functools
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
CSP=json.loads((ROOT/'firebase.json').read_text())['hosting']['headers'][0]['headers'][0]['value']
class Handler(SimpleHTTPRequestHandler):
 def end_headers(self):
  self.send_header('Content-Security-Policy',CSP)
  super().end_headers()
 def log_message(self,*args): pass
async def main():
 server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'public')))
 threading.Thread(target=server.serve_forever,daemon=True).start()
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium')
  page=await browser.new_page(accept_downloads=True)
  errors=[];dialogs=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('dialog',lambda d:(dialogs.append(d.message),asyncio.create_task(d.dismiss())))
  await page.route('**/app.js',lambda route:route.fulfill(path=str(ROOT/'tests/app-mock.js'),content_type='text/javascript'))
  await page.goto(f'http://127.0.0.1:{server.server_port}',wait_until='load')
  await page.wait_for_function('() => window.__mock && document.querySelectorAll("#airports-grid button").length === 2')
  assert await page.locator('#airports-grid').inner_text(), 'Airport catalog missing'
  assert not await page.locator('#airports-grid img').count(), 'Unsafe image URL should not render executable markup'
  assert not await page.evaluate('!!window.__xss')
  assert await page.evaluate('window.__mock.subscriptions.filter(s=>s.ref.path.startsWith("airportData/")).length')==0
  print('PASS anonymous: catalog rendered as text; no private subscriptions, no XSS')
  await page.evaluate('window.__mock.login("starter")')
  await page.wait_for_function('() => document.getElementById("active-flights-list").textContent.includes("Pilot <img")')
  assert not await page.evaluate('!!window.__xss')
  assert not await page.locator('#active-flights-list img').count()
  assert await page.evaluate('window.__mock.subscriptions.filter(s=>s.active && s.ref.path==="users").length')==0
  assert await page.evaluate('window.__mock.subscriptions.filter(s=>s.active && s.ref.path.startsWith("airportData/other/")).length')==0
  assert await page.evaluate('window.__mock.writes.length')==0,'Reads should not initialize missing data or overwrite roles'
  await page.locator('#tab-history-btn').click()
  await page.wait_for_function('() => document.getElementById("history-days-container").textContent.includes("Completed <img")')
  assert not await page.locator('#history-days-container img').count()
  print('PASS starter: own airport only; nested history templates render; XSS in pilot/task stays text')
  await page.locator('#tab-today-btn').click()
  await page.locator('[data-action-click="landGliderFlight"]').first.click()
  assert await page.evaluate('window.__mock.calls.some(c=>c.name==="landFlight" && c.data.flightId===101)')
  await page.evaluate('window.__mock.logout()')
  await page.wait_for_function('() => !document.getElementById("active-flights-list").textContent.includes("Pilot <img")')
  await page.evaluate('window.__mock.stale()')
  assert 'Completed <img' not in await page.locator('body').inner_text()
  assert 'Pilot <img' not in await page.locator('#active-flights-list').inner_text()
  assert await page.evaluate('window.__mock.subscriptions.filter(s=>s.active && (s.ref.path.startsWith("airportData/") || s.ref.path.startsWith("users/"))).length')==0
  print('PASS signout: data cleared, listeners detached, stale callbacks ignored')
  await page.evaluate('window.__mock.login("guest")')
  await page.wait_for_function('() => document.getElementById("user-role-badge").textContent.includes("Guest")')
  assert await page.evaluate('window.__mock.subscriptions.filter(s=>s.active && s.ref.path.startsWith("airportData/")).length')==0
  print('PASS guest: no operational data before membership approval')
  await page.evaluate('window.__mock.profile("guest",{role:"starter"})')
  await page.wait_for_function('() => document.getElementById("active-flights-list").textContent.includes("Pilot <img")')
  await page.evaluate('window.__mock.profile("guest",{role:"guest"})')
  assert 'Pilot <img' not in await page.locator('#active-flights-list').inner_text()
  print('PASS role changes: approval enables access, revocation removes cached data')
  await page.evaluate('window.__mock.logout();window.__mock.login("admin")')
  await page.wait_for_function('() => window.__mock.subscriptions.some(s=>s.active && s.ref.path==="users" && s.ref.queryAirport==="lkst")')
  await page.wait_for_timeout(50)
  await page.locator('#open-fleet-modal-btn').click()
  assert 'Guest' in await page.locator('#admin-users-list').inner_text() or await page.locator('#admin-users-list input').count()>0
  assert not await page.locator('#admin-users-list option[value="admin"]').count()
  assert not await page.locator('#admin-users-list img').count()
  assert 'Other secret' not in await page.locator('#admin-users-list').inner_text()
  print('PASS admin: scoped directory and safe editable names; no admin promotion option')
  await page.locator('[data-action-click="closeFleetModal"]').first.click()
  await page.locator('[data-action-click="openEditModal"]').first.click()
  await page.locator('#edit-task-name').fill('Changed task')
  await page.locator('#edit-flight-form button[type="submit"]').click()
  assert await page.evaluate('window.__mock.calls.some(c=>c.name==="editFlight" && c.data.edits.task==="Changed task")')
  assert not await page.evaluate('window.__mock.writes.some(w=>w.path.includes("Flights"))')
  print('PASS admin edit: form calls server; no direct flight writes')

  await page.evaluate('window.__mock.logout();window.__mock.login("superadmin")')
  await page.wait_for_function('() => window.__mock.subscriptions.some(s=>s.active && s.ref.path==="users" && s.ref.queryAirport===null)')
  await page.wait_for_timeout(50)
  await page.locator('#open-superadmin-btn').click()
  assert await page.locator('#superadmin-users-list select').count()>0
  assert await page.locator('#superadmin-users-list option[value="superadmin"]').count()>0
  print('PASS superadmin: global management remains available with escaped templates')
  assert not await page.evaluate('!!window.__xss')
  assert not await page.locator('[onclick],[onchange],[oninput],[onerror]').count()
  assert not errors, errors
  assert not dialogs, dialogs
  print('PASS no JavaScript exceptions, unexpected dialogs or executable HTML attributes')
  await browser.close()
 server.shutdown()
if __name__ == '__main__':
 asyncio.run(main())
