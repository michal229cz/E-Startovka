import {test} from 'node:test';import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {safeImageURL,csvCell} from '../src/security-ui.js';
test('images accept only HTTPS URLs without embedded credentials',()=>{for(const x of ['javascript:alert(1)','data:text/html,x','//evil.test/x','http://evil.test/x','https://u:p@evil.test/x',null,{}])assert.equal(safeImageURL(x),'');assert.equal(safeImageURL('https://example.test/a.png'),'https://example.test/a.png')});
test('CSV quoting and formula injection protection',()=>{assert.equal(csvCell('A"B;C'),'"A""B;C"');for(const x of ['=1+1','+CMD','-1','@SUM(A1)','  =1','\t=1'])assert.ok(csvCell(x).startsWith('"\''));assert.equal(csvCell("O'Neil"),'"O\'Neil"')});
test('application has no raw HTML sinks or executable HTML attributes',()=>{const app=readFileSync(new URL('../src/app.js',import.meta.url),'utf8');const html=readFileSync(new URL('../public/index.html',import.meta.url),'utf8');assert.doesNotMatch(app,/\.innerHTML\s*=|insertAdjacentHTML|eval\(|new Function\(/);assert.doesNotMatch(app+html,/\bon(?:click|input|change)\s*=\s*["\x27]/i);assert.doesNotMatch(html,/<script[^>]+src="https:\/\//)});
test('local configuration and CLI default cannot accidentally target the live project',()=>{const c=readFileSync(new URL('../public/firebase-config.js',import.meta.url),'utf8');assert.match(c,/useEmulators:\s*true/);assert.match(c,/demo-estartovka-security/);const rc=JSON.parse(readFileSync(new URL('../.firebaserc',import.meta.url)));assert.equal(rc.projects.default,'demo-estartovka-security')});
test('PNG data logos are accepted and active/non-image/oversized data URLs are rejected',()=>{
 const png=JSON.parse(readFileSync(new URL('./logo-data.json',import.meta.url),'utf8'));
 assert.ok(png.length>2048, 'Fixture must exercise a data logo exceeding the old URL limit');
 assert.equal(safeImageURL(png),png);
 for(const value of ['data:image/svg+xml;base64,PHN2ZyBvbmxvYWQ9YWxlcnQoMSk+','data:image/png;base64,PHNjcmlwdD4=','data:image/png;base64,'+'A'.repeat(350000),png.replace('iVBOR','aVBOR')])assert.equal(safeImageURL(value),'');
});
