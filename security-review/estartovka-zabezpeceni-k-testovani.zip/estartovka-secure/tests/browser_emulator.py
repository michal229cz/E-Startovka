"""Actual browser + SDK + Auth/Functions/Database emulators, no mocks."""
import asyncio,time,json
from pathlib import Path
from urllib.parse import urlparse
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium')
  page=await browser.new_page()
  errors=[];dialogs=[];external=[]
  pilot="Actual browser regression "+str(time.time_ns())
  signins=[]
  page.on("request", lambda request: signins.append(1) if "accounts:signInWithPassword" in request.url else None)
  page.on('pageerror',lambda error:errors.append(str(error)))
  page.on('dialog',lambda dialog:(dialogs.append(dialog.message),asyncio.create_task(dialog.dismiss())))
  async def route(request):
   if urlparse(request.request.url).hostname!='127.0.0.1':
    external.append(request.request.url.split('?')[0]);await request.abort()
   else:await request.continue_()
  await page.route('**/*',route)
  await page.goto('http://127.0.0.1:5000',wait_until='load')
  await page.wait_for_function('() => !document.getElementById("auth-modal").classList.contains("hidden")')
  assert await page.locator('#airport-selector-modal').is_hidden()
  assert await page.locator('#app-shell').is_hidden()
  await page.locator('#auth-email').fill('demo-superadmin@example.test')
  await page.locator('#auth-password').fill('DemoOnly-2026!')
  await page.locator('#auth-form button[type="submit"]').click()
  await page.wait_for_function('() => document.getElementById("user-role-badge").textContent.includes("SuperAdmin")')
  await page.wait_for_function('() => document.querySelectorAll("#airports-grid button:enabled").length === 2')
  await page.locator('#airports-grid button:enabled').first.click()
  await page.wait_for_function('() => document.getElementById("aircraft-select").options.length > 0')
  await page.locator('label:has(input[value="Naviják"])').click()
  await page.locator('#pilot-name').fill(pilot)
  await page.locator('#submit-start-btn').click()
  await page.wait_for_function('(pilot) => document.getElementById("active-flights-list").textContent.includes(pilot)',arg=pilot)
  assert not dialogs,dialogs
  print('PASS screenshot regression: real browser demo-superadmin starts a flight without 403')
  card=page.locator('#active-flights-list > div').filter(has_text=pilot).last
  await card.locator('[data-action-click="landGliderFlight"]').click()
  await page.wait_for_function('(pilot) => !document.getElementById("active-flights-list").textContent.includes(pilot)',arg=pilot)
  await page.locator('#tab-history-btn').click()
  await page.wait_for_function('(pilot) => document.getElementById("history-days-container").textContent.includes(pilot)',arg=pilot)
  assert not dialogs,dialogs
  print('PASS actual SDK landing and history rendering')
  await page.locator('#tab-today-btn').click()
  await page.locator('#pilot-name').fill('Draft retained during logo save')
  await page.locator('#open-superadmin-btn').click()
  png=json.loads((Path(__file__).parent/'logo-data.json').read_text())
  logo=page.locator('input[data-action-change="updateAirportLogo"][data-arg-0="lkst"]')
  await logo.fill(png)
  await logo.press('Tab')
  await page.wait_for_function('(png) => Array.from(document.querySelectorAll("#superadmin-airports-list img")).some(img=>img.getAttribute("src")===png)',arg=png)
  assert await page.locator('#superadmin-modal').is_visible()
  assert await page.locator('#pilot-name').input_value()=='Draft retained during logo save'
  assert not dialogs,dialogs
  await page.locator('input[type="file"][data-arg-0="other"]').set_input_files(str(Path(__file__).parent/'logo.png'))
  await page.wait_for_function('() => document.querySelectorAll("#superadmin-airports-list img").length === 2')
  print('PASS actual PNG data paste and file upload persist with previews; form and management stay open')
  # Clear only the synthetic test logos before checking forbidden writes.
  for airport in ['lkst','other']:
   logo=page.locator('input[data-action-change="updateAirportLogo"][data-arg-0="'+airport+'"]')
   await logo.fill('');await logo.press('Tab')
  await page.wait_for_function('() => document.querySelectorAll("#superadmin-airports-list img").length === 0')
  await page.locator('[data-action-click="closeSuperAdminModal"]').first.click()
  await page.locator('[data-action-click="openAirportSelector"]').first.click()
  await page.locator('#airports-grid button').filter(has_text='OTHER').click()
  await page.locator('[data-action-click="openAirportSelector"]').first.click()
  await page.locator('#airports-grid button').filter(has_text='LKST').click()
  assert len(signins)==1, 'Airport changes must not require another login'
  print('PASS airport switching retains the authenticated session')
  await page.locator('#auth-action-btn').click()
  await page.wait_for_function('(pilot) => !document.getElementById("history-days-container").textContent.includes(pilot)',arg=pilot)
  assert dialogs==['Byli jste odhláseni.'],dialogs
  assert await page.locator('#auth-modal').is_visible()
  assert await page.locator('#airport-selector-modal').is_hidden()
  await page.locator('#auth-email').fill('demo-starter@example.test')
  await page.locator('#auth-password').fill('DemoOnly-2026!')
  await page.locator('#auth-form button[type="submit"]').click()
  await page.wait_for_function('() => document.querySelectorAll("#airports-grid button").length === 2 && document.querySelectorAll("#airports-grid button:disabled").length === 1')
  locked=page.locator('#airports-grid button:disabled')
  assert 'OTHER' in await locked.inner_text()
  await locked.evaluate('(button) => button.click()')
  assert await page.locator('#app-shell').is_hidden()
  await page.locator('#airports-grid button:enabled').click()
  assert await page.locator('#app-shell').is_visible()
  print('PASS member: login comes first; all airports shown, foreign airport locked, own airport opens')
  assert not errors,errors
  assert not external,external
  print('PASS real signout clears private DOM, no JS exceptions or production requests')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
