"""Actual browser + SDK + Auth/Functions/Database emulators, no mocks."""
import asyncio,time
from urllib.parse import urlparse
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium')
  page=await browser.new_page()
  errors=[];dialogs=[];external=[]
  pilot="Actual browser regression "+str(time.time_ns())
  page.on('pageerror',lambda error:errors.append(str(error)))
  page.on('dialog',lambda dialog:(dialogs.append(dialog.message),asyncio.create_task(dialog.dismiss())))
  async def route(request):
   if urlparse(request.request.url).hostname!='127.0.0.1':
    external.append(request.request.url.split('?')[0]);await request.abort()
   else:await request.continue_()
  await page.route('**/*',route)
  await page.goto('http://127.0.0.1:5000',wait_until='load')
  await page.wait_for_function('() => document.querySelectorAll("#airports-grid button").length === 2')
  await page.locator('#airports-grid button').first.click()
  await page.locator('#auth-action-btn').click()
  await page.locator('#auth-email').fill('demo-superadmin@example.test')
  await page.locator('#auth-password').fill('DemoOnly-2026!')
  await page.locator('#auth-form button[type="submit"]').click()
  await page.wait_for_function('() => document.getElementById("user-role-badge").textContent.includes("SuperAdmin")')
  await page.wait_for_function('() => document.getElementById("aircraft-select").options.length > 0')
  await page.locator('label:has(input[value="Naviják"])').click()
  await page.locator('#pilot-name').fill(pilot)
  await page.locator('#submit-start-btn').click()
  await page.wait_for_function('(pilot) => document.getElementById("active-flights-list").textContent.includes(pilot)',arg=pilot)
  assert not dialogs,dialogs
  print('PASS screenshot regression: real browser demo-superadmin starts a flight without 403')
  card=page.locator('#active-flights-list > div').filter(has_text=pilot).last
  await card.locator('[data-action-click="landGliderFlight"]').click()
  await page.wait_for_function('(pilot) => !document.getElementById("active-flights-list").textContent.includes(pilot)',arg=pilot)
  await page.locator('#tab-history-btn').click()
  await page.wait_for_function('(pilot) => document.getElementById("history-days-container").textContent.includes(pilot)',arg=pilot)
  assert not dialogs,dialogs
  print('PASS actual SDK landing and history rendering')
  await page.locator('#auth-action-btn').click()
  await page.wait_for_function('(pilot) => !document.getElementById("history-days-container").textContent.includes(pilot)',arg=pilot)
  assert dialogs==['Byli jste odhláseni.'],dialogs
  assert not errors,errors
  assert not external,external
  print('PASS real signout clears private DOM, no JS exceptions or production requests')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
