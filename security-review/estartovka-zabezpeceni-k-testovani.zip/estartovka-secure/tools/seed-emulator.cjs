// Synthetic accounts and airport data for LOCAL DEMO emulators only.
// No application-default credentials or production project IDs are accepted.
process.env.FIREBASE_AUTH_EMULATOR_HOST='127.0.0.1:9099';
process.env.FIREBASE_DATABASE_EMULATOR_HOST='127.0.0.1:9000';
const requireFunctions=require('node:module').createRequire(__dirname+'/../functions/package.json');
const {initializeApp}=requireFunctions('firebase-admin/app');
const {getAuth}=requireFunctions('firebase-admin/auth');
const {getDatabase}=requireFunctions('firebase-admin/database');
const projectId='demo-estartovka-security';
const app=initializeApp({projectId,databaseURL:`https://${projectId}-default-rtdb.firebaseio.com`});
async function main(){
 const auth=getAuth(app),db=getDatabase(app);
 const accounts=[['demo-superadmin','superadmin','lkst'],['demo-admin','admin','lkst'],['demo-starter','starter','lkst'],['demo-guest','guest','lkst'],['demo-other','starter','other']];
 await db.ref('airports').update({lkst:{icao:'LKST',name:'Testovací letiště A',order:0,logoUrl:''},other:{icao:'OTHER',name:'Testovací letiště B',order:1,logoUrl:''}});
 for(const [uid,role,airportId] of accounts){
  const email=uid+'@example.test',password='DemoOnly-2026!';
  try {await auth.createUser({uid,email,password,emailVerified:true,displayName:uid});}
  catch(error){if(error.code!=='auth/uid-already-exists' && error.code!=='auth/email-already-exists')throw error;}
  await db.ref('users/'+uid).set({fullName:uid,email,role,airportId});
  console.log('LOCAL DEMO ONLY:',email,'password:',password,'role:',role);
 }
 console.log('Local demo seeded. No production service was contacted.');
}
main().then(()=>process.exit(0)).catch(error=>{console.error(error.message);process.exit(1)});
