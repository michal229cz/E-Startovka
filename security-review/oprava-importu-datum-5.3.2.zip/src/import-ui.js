import {html} from 'lit-html';

export function installImportUI({getAirport,getFlights,canWrite,isAdmin,getSource,saveSource,saveDetails,syncSource,importHTML,setContent,formatTime}) {
    const el=id=>document.getElementById(id);
    const sourceForm=el('flight-source-form'),detailsForm=el('flight-details-form');
    const modal=el('flight-details-modal');
    let editingAirport=null,sourceDirty=false,sourceBusy=false,detailsBusy=false,generation=0;
    const clean=value=>value && value!=='-' ? value : '';
    const find=id=>getFlights().find(f=>f.id===id);
    function badge(f) {
        if (!f.imported) return '';
        return html`<span class="inline-block text-xs font-bold px-2 py-1 rounded-lg ${f.detailsComplete ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'}">${f.detailsComplete ? 'Doplněno' : 'K doplnění'}</span>
            ${canWrite() ? html`<button type="button" data-action-click="openFlightDetails" data-arg-0="${f.id}" data-arg-0-type="number" class="text-xs font-bold text-blue-700 underline p-1">${f.detailsComplete ? 'Upravit údaje' : 'Doplnit let'}</button>` : ''}`;
    }
    function renderQueue() {
        const pending=getFlights().filter(f=>f.imported && !f.detailsComplete).sort((a,b)=>b.takeoffTime.localeCompare(a.takeoffTime));
        const panel=el('flight-details-queue');panel.hidden=!pending.length;
        setContent(panel, pending.length ? html`<details><summary class="cursor-pointer font-bold text-sm text-amber-900">K doplnění: ${pending.length} letů</summary>
          <p class="text-xs text-slate-500 my-2">Všechny převzaté lety bez pilota a úlohy, včetně starších dní.</p>
          <div class="space-y-2 max-h-64 overflow-y-auto">${pending.map(f=>html`<div class="flex flex-wrap items-center gap-2 border-t border-slate-100 pt-2 text-sm"><strong>${f.aircraft}</strong><span>${f.takeoffTime.slice(0,10)} ${formatTime(f.takeoffTime)} UTC</span>${badge(f)}</div>`)}</div>
        </details>` : '');
    }
    function renderSource(reset=false) {
        const source=getSource();
        if (reset || !sourceDirty) {el('flight-source-url').value=source?.url || '';el('flight-source-enabled').checked=source?.enabled===true;sourceDirty=false;}

        const parts=[];
        if(source) {
            parts.push(source.enabled ? 'Automatické načítání je zapnuté (interval 5 minut).' : 'Automatické načítání je vypnuté.');
            if(source.lastSuccessAt)parts.push(`Poslední úspěšný import: ${new Date(source.lastSuccessAt).toLocaleString('cs-CZ')} (${source.lastImportMode==='file'?'HTML soubor':'online'}, ${source.lastImportCount || 0} záznamů).`);
            else parts.push('Dosud neproběhl úspěšný import.');
            if(source.lastError)parts.push('Chyba: '+source.lastError);
            if(source.lease)parts.push('Probíhá import.');
        } else parts.push('Zdroj není nastaven. Lety zatím zadávejte ručně.');
        el('flight-source-status').textContent=parts.join(' ');
    }
    sourceForm.addEventListener('input',event=>{if(['flight-source-url','flight-source-enabled'].includes(event.target.id))sourceDirty=true;});
    sourceForm.addEventListener('submit',async event=>{
        event.preventDefault();if (!isAdmin() || sourceBusy) return;
        const airportId=getAirport(),epoch=generation;
        const submit=sourceForm.querySelector('button[type="submit"]');
        sourceBusy=true;submit.disabled=true;
        try {
            const result=await saveSource({airportId,url:el('flight-source-url').value.trim(),enabled:el('flight-source-enabled').checked});
            if (epoch!==generation || getAirport()!==airportId) return;
            sourceDirty=false;
            if(typeof result.data?.url==='string')el('flight-source-url').value=result.data.url;
            el('flight-source-status').textContent=el('flight-source-url').value.trim() ? 'Zdroj uložen. Stav a výsledek importu se zobrazí zde.' : 'Zdroj odpojen.';
        } catch(error) {if(epoch===generation)el('flight-source-status').textContent='Zdroj se nepodařilo uložit: '+error.message;}
        finally {if(epoch===generation){sourceBusy=false;submit.disabled=false;}}
    });
    async function runSourceAction(mode) {
        if(!isAdmin() || sourceBusy)return;
        if(!getSource()?.url || sourceDirty){el('flight-source-status').textContent='Nejprve uložte nastavení zdroje.';return;}
        const airportId=getAirport(),epoch=generation;
        const controls=[el('flight-source-sync'),el('flight-source-upload'),sourceForm.querySelector('button[type="submit"]')];
        sourceBusy=true;controls.forEach(b=>b.disabled=true);
        try {
            let result;
            if(mode==='file') {
                const file=el('flight-import-file').files[0];
                if(!file)throw Error('Vyberte HTML soubor stránky.');
                if(file.size>512*1024)throw Error('Soubor překračuje limit 512 KB.');
                const text=await file.text();
                if(epoch!==generation || getAirport()!==airportId)return;
                result=await importHTML({airportId,html:text});
            } else result=await syncSource({airportId});
            if(epoch!==generation)return;
            const data=result.data || {};
            if(mode==='file' && data.dates?.length===1)el('flight-import-date').value=data.dates[0];
            el('flight-source-status').textContent=data.skipped ? 'Další online pokus je možný nejdříve 5 minut po předchozím. Probíhající automatický import vyčkejte.' : `Import dokončen${data.dates?.length ? ' ('+data.dates.join(', ')+')' : ''}: zpracováno ${data.count || 0} záznamů. Posádku a úlohu doplňte u jednotlivých letů.`;
        } catch(error) {if(epoch===generation)el('flight-source-status').textContent='Import se nezdařil: '+error.message;}
        finally {if(epoch===generation){sourceBusy=false;controls.forEach(b=>b.disabled=false);}}
    }
    el('flight-import-file').addEventListener('change',async()=>{
        const file=el('flight-import-file').files[0],epoch=generation;
        el('flight-import-date').value='';
        if(!file || file.size>512*1024)return;
        try {
            const text=await file.text();
            if(epoch!==generation || el('flight-import-file').files[0]!==file)return;
            const dates=[...new Set([...text.matchAll(/href=[\"'](?:https:\/\/logbook\.ibisek\.com)?\/csv\/loc\/[A-Z0-9]{4}\/(\d{4}-\d{2}-\d{2})(?:\/)?[\"']/g)].map(match=>match[1]))];
            if(dates.length===1)el('flight-import-date').value=dates[0];
        } catch { /* The backend returns the actionable validation error on import. */ }
    });
    window.syncFlightSourceNow=()=>runSourceAction('online');
    window.importFlightHTMLFile=()=>runSourceAction('file');
    function toggleTow() {
        const aero=el('details-launch').value==='Aerovlek';
        el('details-tow-fields').hidden=!aero;
        el('details-tow-aircraft').required=aero;el('details-tow-pilot').required=aero;
    }
    el('details-launch').addEventListener('change',toggleTow);
    window.openFlightDetails=function(id) {
        if (!canWrite()) return;
        const f=find(id);if(!f?.imported) return;
        editingAirport=getAirport();detailsForm.reset();
        el('details-flight-id').value=f.id;
        el('details-flight-label').textContent=`${f.aircraft} · ${f.takeoffTime.slice(0,10)} · ${formatTime(f.takeoffTime)} UTC`;
        for (const [name,field] of Object.entries({pilot:'pilot',copilot:'copilot',task:'task',launch:'launchType','tow-aircraft':'towAircraft','tow-pilot':'towPilot'})) el('details-'+name).value=clean(f[field]);
        toggleTow();el('details-error').textContent='';modal.classList.remove('hidden');el('details-pilot').focus();
    };
    window.closeFlightDetails=function() {modal.classList.add('hidden');detailsForm.reset();editingAirport=null;};
    detailsForm.addEventListener('submit',async event=>{
        event.preventDefault();if(!canWrite() || editingAirport!==getAirport() || detailsBusy) return;
        const flightId=Number(el('details-flight-id').value),f=find(flightId);if(!f?.imported) return;
        const airportId=editingAirport,epoch=generation,submit=detailsForm.querySelector('button[type="submit"]');
        detailsBusy=true;submit.disabled=true;
        try {
            await saveDetails({airportId,flightId,details:{pilot:el('details-pilot').value.trim(),copilot:el('details-copilot').value.trim(),task:el('details-task').value.trim(),launchType:el('details-launch').value,towAircraft:el('details-tow-aircraft').value.trim(),towPilot:el('details-tow-pilot').value.trim()}});
            if(epoch===generation && editingAirport===airportId && Number(el('details-flight-id').value)===flightId)window.closeFlightDetails();
        } catch(error) {if(epoch===generation)el('details-error').textContent='Údaje se nepodařilo uložit: '+error.message;}
        finally {if(epoch===generation){detailsBusy=false;submit.disabled=false;}}
    });
    function clear() {
        generation++;sourceDirty=false;sourceBusy=false;detailsBusy=false;
        window.closeFlightDetails();sourceForm.reset();
        el('flight-source-status').textContent='';el('details-flight-label').textContent='';el('details-error').textContent='';
        el('flight-source-sync').disabled=false;el('flight-source-upload').disabled=false;
        sourceForm.querySelector('button[type="submit"]').disabled=false;detailsForm.querySelector('button[type="submit"]').disabled=false;
        el('flight-details-queue').hidden=true;setContent(el('flight-details-queue'),'');
    }
    return {badge,renderQueue,renderSource,clear};
}
