'use strict';
const cheerio=require('cheerio');
const {Temporal}=require('@js-temporal/polyfill');
const {ValidationError}=require('./security');
const imports=require('./imports');
const MAX_BYTES=512*1024;
const error=message=>{throw new ValidationError(message);};
const clean=value=>value.replace(/\s+/g,' ').trim();
function day(value) {
  if(typeof value!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(value))error('Neplatné datum importu.');
  try {return Temporal.PlainDate.from(value);} catch {error('Neplatné datum importu.');}
}
function localDate(value,date) {
  const match=/^(\d{1,2})\.(\d{1,2})\.$/.exec(value);if(!match)error('Zdroj změnil formát data.');
  const candidates=[date.year-1,date.year,date.year+1].flatMap(year=>{try{return [Temporal.PlainDate.from({year,month:+match[2],day:+match[1]},{overflow:'reject'})];}catch{return [];}});
  const result=candidates.sort((a,b)=>Math.abs(date.until(a).days)-Math.abs(date.until(b).days))[0];
  if(!result || Math.abs(date.until(result).days)>2)error('Datum řádku neodpovídá zvolenému dni.');
  return result;
}
function instant(date,value,zone) {
  if(!/^\d{2}:\d{2}$/.test(value))error('Zdroj změnil formát času.');
  try {return Temporal.ZonedDateTime.from(`${date}T${value}:00[${zone}]`,{disambiguation:'reject'}).toInstant().toString({smallestUnit:'millisecond'});} catch {error('Čas zdroje je neplatný nebo nejednoznačný při změně letního času.');}
}
function pageDate($,location) {
  const raw=clean($('#datepicker').attr('value') || '');
  const local=/^(\d{1,2})\s*\.\s*(\d{1,2})\s*\.\s*(\d{4})$/.exec(raw);
  const iso=/^\d{4}-\d{2}-\d{2}$/.test(raw);
  let picker=null;
  if(local) {
    try {picker=Temporal.PlainDate.from({year:+local[3],month:+local[2],day:+local[1]},{overflow:'reject'}).toString();}
    catch {error('Stránka obsahuje neplatné datum: '+raw.slice(0,40));}
  } else if(iso)picker=day(raw).toString();
  const exports=$('a').toArray().flatMap(a=>{
    try {
      const u=new URL($(a).attr('href'),'https://logbook.ibisek.com');
      const match=/^\/csv\/loc\/([A-Z0-9]{4})\/(\d{4}-\d{2}-\d{2})\/?$/.exec(u.pathname);
      return u.origin==='https://logbook.ibisek.com' && match?[{location:match[1],date:day(match[2]).toString()}]:[];
    }catch{return [];}
  });
  if(!exports.length || exports.some(value=>value.location!==location))error('Stránka neobsahuje jednoznačný export pro nastavené letiště '+location+'.');
  const dates=[...new Set(exports.map(value=>value.date))];
  if(dates.length!==1)error('Stránka uvádí více různých dat exportu.');
  if(picker && picker!==dates[0])error(`Datum pole ${picker} nesouhlasí s datem exportu ${dates[0]}.`);
  return {date:dates[0],raw};
}
function parseHTML(input,{location,date,now=Date.now(),requireUTC=false,sessionTimezone=null}) {
  if(typeof input!=='string' || Buffer.byteLength(input,'utf8')>MAX_BYTES)error('HTML soubor překračuje limit 512 KB.');
  if(!/^[A-Z0-9]{4}$/.test(location))error('Neplatná lokace zdroje.');
  const $=cheerio.load(input); // Parsing only; no scripts or linked resources run.
  const actual=pageDate($,location);
  if(date!==undefined && date!==null && day(date).toString()!==actual.date)error(`Zdroj vrátil jiné datum: požadováno ${date}, stránka ${actual.date} (pole: ${actual.raw.slice(0,40) || 'prázdné'}).`);
  date=actual.date;
  const requested=day(date);
  const footer=clean($('.footer').text());
  const zoneMatch=/Vaše časová zóna je zřejmě ([A-Za-z0-9_+\-/]+)\./.exec(footer);
  // The default UTC view need not include the browser-local timezone sentence.
  // Accept UTC only when the time banner explicitly declares it, never merely
  // because UTC was requested by cookie or appears on a switch/button/link.
  const banners=$('.footer .footerInfo').toArray().map(element=>{
    const block=$(element),words=block.find('.wip').toArray().map(span=>clean($(span).text()));
    return words.length ? words.join(' ') : clean(block.text()).split('@')[0].trim();
  });
  const utcBanner=banners.some(text=>/^ALL TIMES (?:(?:ARE IN|ARE|IN) )?UTC[.!]?$/i.test(text));
  if(utcBanner && zoneMatch && !['UTC','Etc/UTC','Etc/GMT'].includes(zoneMatch[1]))error('Zdroj uvádí rozporná časová pásma. Import byl zastaven.');
  const localBanner=banners.some(text=>/^ALL TIMES ARE (?:YOURS|YOUR) LOCAL[.!]?$/i.test(text));
  const sessionUTC=sessionTimezone==='UTC' && localBanner;
  if(sessionTimezone==='UTC' && zoneMatch && !['UTC','Etc/UTC','Etc/GMT'].includes(zoneMatch[1]))error('Zdroj nepoužil požadované časové pásmo UTC.');
  if(!zoneMatch && !utcBanner && !sessionUTC)error('Zdroj nepotvrzuje časové pásmo; časy nelze bezpečně převést. Označení ve zdroji: '+(banners.filter(Boolean).join(' / ').slice(0,100) || 'nenalezeno'));
  const zone=zoneMatch ? zoneMatch[1] : 'UTC';
  try {Temporal.Now.zonedDateTimeISO(zone);}catch {error('Neznámé časové pásmo zdroje.');}
  if(requireUTC && !['UTC','Etc/UTC','Etc/GMT'].includes(zone))error('Zdroj nepotvrdil požadované UTC. Automatický import byl zastaven.');
  const tables=$('.sitebody .table').toArray();
  const headers=table=>$(table).children('.row.header').first().children('.cell').toArray().map(c=>clean($(c).text()));
  if(tables.length!==3 || headers(tables[0]).join('|')!=='Datum|Čas|Místo|Registrace|SZ' || headers(tables[1]).join('|')!=='Datum|Čas|Místo|Registrace|SZ' || headers(tables[2]).slice(0,9).join('|')!=='Datum|Registrace|SZ|Typ|Odlet||Přílet||Doba letu')error('Zdroj změnil strukturu tabulek. Import byl zastaven.');
  const rows=table=>$(table).children('.row').not('.header').toArray().map(row=>$(row).children('.cell').toArray().map(c=>clean($(c).text())));
  const records=new Map(),paired=new Set();
  const make=(registration,dateValue,time)=>{
    if(!/^[A-Z0-9][A-Z0-9 -]{0,39}$/.test(registration))error('Neplatná registrace ve zdroji.');
    const takeoffTime=instant(localDate(dateValue,requested),time,zone);
    return {externalId:registration+'|'+takeoffTime,aircraft:registration,takeoffTime,landingTime:null};
  };
  for(const cells of rows(tables[0])) {
    if(cells.length!==5)error('Neplatný řádek odletu.');
    if(cells[2]!==location)continue;
    const r=make(cells[3],cells[0],cells[1]);
    if(records.has(r.externalId))error('Zdroj obsahuje nerozlišitelné odlety.');
    records.set(r.externalId,r);
  }
  for(const cells of rows(tables[2])) {
    if(cells.length!==11)error('Neplatný řádek letu.');
    if(cells[4]!==location)continue; // An arrival from another airport is not a local launch.
    const r=make(cells[1],cells[0],cells[5]);
    if(paired.has(r.externalId))error('Zdroj obsahuje nerozlišitelné lety.');paired.add(r.externalId);
    if(!records.has(r.externalId))error('Tabulky odletů a letů nesouhlasí. Import byl zastaven, aby nevznikla duplicita.');
    if(cells[7] && cells[7]!=='-') {
      let endDate=localDate(cells[0],requested);
      if(cells[7]<cells[5])endDate=endDate.add({days:1});
      r.landingTime=instant(endDate,cells[7],zone);
      if(Date.parse(r.landingTime)-Date.parse(r.takeoffTime)>86400000)error('Zdroj nejednoznačně určuje den přistání.');
    }
    records.set(r.externalId,r);
  }
  return {date,zone,records:imports.normalize([...records.values()],now).map(r=>({externalId:r.externalId,aircraft:r.aircraft,takeoffTime:r.takeoffTime,landingTime:r.gliderLandingTime}))};
}
async function fetchHTML(location,date,fetchImpl=fetch) {
  day(date);if(!/^[A-Z0-9]{4}$/.test(location))error('Neplatná lokace zdroje.');
  const baseHeaders={'Accept-Language':'cs-CZ,cs;q=0.9','User-Agent':'E-Startovka/5.3 flight-sync'};
  // Match the site's supplied switchTimezone(): POST sets the server session;
  // browser_timezone by itself is only the browser's switch-state cookie.
  const preference=await fetchImpl('https://logbook.ibisek.com/set_timezone',{method:'POST',body:'UTC',redirect:'error',signal:AbortSignal.timeout(15000),headers:{...baseHeaders,'Content-Type':'text/plain;charset=UTF-8',Cookie:'browser_timezone=UTC'}});
  if(!preference.ok)throw Error(`Nastavení časového pásma zdroje selhalo: HTTP ${preference.status}.`);
  const cookies=preference.headers.getSetCookie().map(value=>value.split(';')[0].trim());
  const session=cookies.find(value=>/^session=.+/.test(value));
  if(preference.body)await preference.body.cancel();
  if(!session)error('Zdroj nepotvrdil relaci pro časové pásmo UTC.');
  const response=await fetchImpl(`https://logbook.ibisek.com/loc/${location}/${date}`,{redirect:'error',signal:AbortSignal.timeout(15000),headers:{...baseHeaders,Accept:'text/html',Cookie:'browser_timezone=UTC; '+session}});
  if(!response.ok)throw Error(`Zdroj odpověděl HTTP ${response.status}.`);
  if(!/text\/html/i.test(response.headers.get('content-type') || ''))error('Zdroj nevrátil HTML stránku.');
  if(Number(response.headers.get('content-length'))>MAX_BYTES)error('Odpověď zdroje je příliš velká.');
  const reader=response.body.getReader(),chunks=[];let total=0;
  try {while(true){const {value,done}=await reader.read();if(done)break;total+=value.byteLength;if(total>MAX_BYTES)error('Odpověď zdroje je příliš velká.');chunks.push(Buffer.from(value));}}
  finally {await reader.cancel();}
  return {html:Buffer.concat(chunks).toString('utf8'),sessionTimezone:'UTC'};
}
function applyBatch(state,config,batches,now=Date.now()) {
  // The HTML has no immutable flight ID. Changes of takeoff time must not be
  // guessed: stop the whole batch if an old departure disappears while a new
  // one for that aircraft appears on the same date. Crew remains untouched.
  for(const batch of batches) {
    const old=state?.importSnapshots?.[`${config.location}_${batch.date}`] || {};
    const current=Object.fromEntries(batch.records.map(r=>[imports.keyFor(config,r.externalId),r.aircraft]));
    const removed=new Set(Object.entries(old).filter(([key])=>!current[key]).map(([,aircraft])=>aircraft));
    if(Object.entries(current).some(([key,aircraft])=>!old[key] && removed.has(aircraft)))error('Zdroj změnil čas odletu nebo odstranil dřívější let. Je potřeba ruční kontrola, aby nevznikla duplicita.');
  }
  for(const batch of batches) {
    const records=batch.records.map(record=>{
      const old=state?.completedFlights?.[imports.keyFor(config,record.externalId)];
      // A departure-only row does not explicitly revoke an earlier landing.
      return !record.landingTime && old?.gliderLandingTime ? {...record,landingTime:old.gliderLandingTime} : record;
    });
    state=imports.reconcile(state,config,records,now);
    state.importSnapshots=state.importSnapshots || {};
    const key=`${config.location}_${batch.date}`;
    state.importSnapshots[key]={...(state.importSnapshots[key] || {}),...Object.fromEntries(batch.records.map(r=>[imports.keyFor(config,r.externalId),r.aircraft]))};
  }
  return state;
}
module.exports={parseHTML,fetchHTML,applyBatch,day,MAX_BYTES};
